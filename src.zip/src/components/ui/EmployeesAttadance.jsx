import React, { useEffect, useState } from 'react';
import axios from 'axios';
import CheckInOutButton from './attendance/CheckInOutButton';
import { useSelector } from 'react-redux';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
  RadialBarChart,
  RadialBar
} from 'recharts';
import { 
  
  FaCalendarAlt, 
  FaClock, 
  FaUsers,
  FaUserTie,
  FaRegCalendarCheck,
  FaRegChartBar
} from 'react-icons/fa';
import { FiActivity, FiUserCheck, FiUserX } from 'react-icons/fi';

// Custom radial chart component
const AttendanceRadialChart = ({ percentage }) => {
  const data = [
    {
      name: 'Attendance',
      value: percentage,
      fill: '#3B82F6'
    }
  ];

  return (
    <div className="relative w-24 h-24">
      <RadialBarChart
        width={96}
        height={96}
        innerRadius="70%"
        outerRadius="100%"
        data={data}
        startAngle={90}
        endAngle={-270}
      >
        <RadialBar
          background
          dataKey="value"
          cornerRadius={10}
        />
        <text
          x={48}
          y={48}
          textAnchor="middle"
          dominantBaseline="middle"
          className="text-lg font-bold fill-blue-600"
        >
          {percentage}%
        </text>
      </RadialBarChart>
    </div>
  );
};

export default function EmployeesAttendance() {
  const [employeeData, setEmployeeData] = useState(null);
  const [teamData, setTeamData] = useState([]);
  const [todayAttendance, setTodayAttendance] = useState(null);
  // const [isLoading, setIsLoading] = useState(true);
  const user = useSelector((state) => state.auth.user);
  const Myid = user?.employee?.id;
  const teamName = user?.employee?.team_name;

  useEffect(() => {
    const fetchData = async () => {
      
      try {
        const [employeeRes, teamRes, todayRes] = await Promise.all([
          Myid ? axios.get(`http://localhost:5000/api/attendance/employee/${Myid}`) : Promise.resolve(null),
          teamName ? axios.get(`http://localhost:5000/api/attendance/team/${teamName}`) : Promise.resolve(null),
          axios.get('http://localhost:5000/api/attendance/today-present-by-team')
        ]);
        
        if (employeeRes) setEmployeeData(employeeRes.data);
        if (teamRes) setTeamData(teamRes.data.summary);
        if (todayRes) setTodayAttendance(todayRes.data);
      } catch (err) {
        console.error('Error fetching data:', err);
      } finally {
        console.log(false);
      }
    };
    
    fetchData();
  }, [Myid, teamName]);

  const COLORS = ['#3B82F6', '#F59E0B', '#EF4444', '#10B981'];

  const attendanceData = employeeData
    ? [
        { name: 'Present', value: employeeData.summary.monthly.presentDays, icon: <FiUserCheck className="text-blue-500" /> },
        { name: 'Leave', value: employeeData.summary.monthly.leaveDays, icon: <FaRegCalendarCheck className="text-yellow-500" /> },
        { name: 'Absent', value: employeeData.summary.monthly.absentDays, icon: <FiUserX className="text-red-500" /> },
      ]
    : [];

  const overtimeData = employeeData
    ? [
        { name: 'Overtime', value: employeeData.summary.monthly.totalOvertimeHours },
        {
          name: 'Regular',
          value:
            employeeData.summary.monthly.totalWorkingDays * 8 -
            employeeData.summary.monthly.totalOvertimeHours,
        },
      ]
    : [];

  const stats = employeeData ? [
    {
      title: "Total Hours",
      value: (employeeData.summary.monthly.totalWorkingDays * 8).toFixed(1),
      change: "+2.5%",
      icon: <FaClock className="text-blue-500" />,
      trend: 'up'
    },
    {
      title: "Overtime",
      value: employeeData.summary.monthly.totalOvertimeHours.toFixed(1),
      change: "+1.2%",
      icon: <FiActivity className="text-yellow-500" />,
      trend: 'up'
    },
    {
      title: "Attendance Rate",
      value: employeeData.summary.monthly.attendancePercentage,
      change: "+3.1%",
      icon: <FaRegChartBar className="text-green-500" />,
      trend: 'up'
    },
    {
      title: "Work Days",
      value: employeeData.summary.monthly.totalWorkingDays,
      change: "0%",
      icon: <FaCalendarAlt className="text-purple-500" />,
      trend: 'neutral'
    }
  ] : [];

  const TodayAttendanceSection = () => {
    if (!todayAttendance) return null;

    return (
      <div className="bg-white border border-gray-100 rounded-2xl p-6 shadow-sm">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-semibold text-gray-800 flex items-center">
            <FaCalendarAlt className="mr-2 text-blue-500" /> Today's Attendance
          </h2>
          <span className="text-sm text-gray-500">
            {todayAttendance.date}
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
          <div className="bg-blue-50 border border-blue-100 rounded-xl p-4">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm font-medium text-blue-600">Total Employees</p>
                <h3 className="text-2xl font-bold text-blue-800 mt-1">
                  {todayAttendance.overall_summary.total_employees}
                </h3>
              </div>
              <FaUsers className="text-blue-400 text-xl" />
            </div>
          </div>
          
          <div className="bg-green-50 border border-green-100 rounded-xl p-4">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm font-medium text-green-600">Present Today</p>
                <h3 className="text-2xl font-bold text-green-800 mt-1">
                  {todayAttendance.overall_summary.total_present}
                </h3>
              </div>
              <FiUserCheck className="text-green-400 text-xl" />
            </div>
          </div>
          
          <div className="bg-yellow-50 border border-yellow-100 rounded-xl p-4">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm font-medium text-yellow-600">On Leave</p>
                <h3 className="text-2xl font-bold text-yellow-800 mt-1">
                  {todayAttendance.overall_summary.total_on_leave}
                </h3>
              </div>
              <FaRegCalendarCheck className="text-yellow-400 text-xl" />
            </div>
          </div>
        </div>

        <div className="space-y-6">
          {todayAttendance.by_team.summary.map((team) => (
            <div key={team.team_name} className="border border-gray-100 rounded-lg p-4">
              <div className="flex justify-between items-center mb-3">
                <h3 className="font-medium text-gray-800">{team.team_name}</h3>
                <div className="flex space-x-4">
                  <span className="text-sm text-gray-500">
                    {team.present_count} present
                  </span>
                  <span className="text-sm text-gray-500">
                    {team.leave_count} on leave
                  </span>
                </div>
              </div>
              
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="h-2 rounded-full bg-blue-500" 
                  style={{ 
                    width: `${team.present_percentage.replace('%', '')}%`,
                    background: `linear-gradient(90deg, #3B82F6 ${team.present_percentage.replace('%', '')}%, #F59E0B ${team.leave_percentage.replace('%', '')}%, transparent 0%)`
                  }}
                ></div>
              </div>
              
              <div className="flex justify-between mt-2 text-xs text-gray-500">
                <span>Present: {team.present_percentage}</span>
                <span>Leave: {team.leave_percentage}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50 p-4 md:p-8">
      <div className="max-w-7xl mx-auto space-y-6">

        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold text-gray-800">
              Welcome back, <span className="text-blue-600">{user?.employee?.name}</span>
            </h1>
            <p className="text-sm text-gray-500 flex items-center mt-1">
              <FaCalendarAlt className="mr-2" /> 
              {new Date().toLocaleDateString('en-US', { 
                weekday: 'long', 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric' 
              })}
            </p>
          </div>
          <div className="bg-white/80 backdrop-blur-sm border border-blue-100 rounded-xl p-3 shadow-sm w-full md:w-auto">
            <CheckInOutButton />
          </div>
        </div>

        {/* Today's Attendance Section */}
        <TodayAttendanceSection />

        {/* Stats Cards */}
        {employeeData && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {stats.map((stat, index) => (
              <div 
                key={index}
                className="bg-white border border-gray-100 rounded-xl p-5 shadow-sm hover:shadow-md transition-all duration-200"
              >
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-sm font-medium text-gray-500">{stat.title}</p>
                    <h3 className="text-2xl font-bold text-gray-800 mt-1">{stat.value}</h3>
                    <div className={`flex items-center mt-2 text-sm ${
                      stat.trend === 'up' ? 'text-green-500' : 
                      stat.trend === 'down' ? 'text-red-500' : 'text-gray-500'
                    }`}>
                      {stat.change}
                      {stat.trend === 'up' && (
                        <svg className="w-4 h-4 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 15l7-7 7 7" />
                        </svg>
                      )}
                      {stat.trend === 'down' && (
                        <svg className="w-4 h-4 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                        </svg>
                      )}
                    </div>
                  </div>
                  <div className="p-3 rounded-lg bg-blue-50">
                    {stat.icon}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Charts Section */}
        {employeeData && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Attendance Summary */}
            <div className="bg-white border border-gray-100 rounded-2xl p-6 shadow-sm lg:col-span-2">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-lg font-semibold text-gray-800 flex items-center">
                  <FaUsers className="mr-2 text-blue-500" /> Monthly Attendance
                </h2>
                <div className="flex items-center space-x-2">
                  {attendanceData.map((item, index) => (
                    <div key={index} className="flex items-center">
                      <div className="w-3 h-3 rounded-full mr-1" style={{ backgroundColor: COLORS[index] }} />
                      <span className="text-xs text-gray-500">{item.name}</span>
                    </div>
                  ))}
                </div>
              </div>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={attendanceData}>
                    <XAxis 
                      dataKey="name" 
                      axisLine={false} 
                      tickLine={false} 
                      tick={{ fill: '#6B7280', fontSize: 12 }}
                    />
                    <YAxis 
                      axisLine={false} 
                      tickLine={false} 
                      tick={{ fill: '#6B7280', fontSize: 12 }}
                    />
                    <Tooltip 
                      contentStyle={{
                        backgroundColor: '#FFFFFF',
                        border: '1px solid #E5E7EB',
                        borderRadius: '0.5rem',
                        boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                      }}
                    />
                    <Bar 
                      dataKey="value" 
                      radius={[4, 4, 0, 0]} 
                      animationDuration={1500}
                    >
                      {attendanceData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Overtime Distribution */}
            <div className="bg-white border border-gray-100 rounded-2xl p-6 shadow-sm">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-lg font-semibold text-gray-800 flex items-center">
                  <FaClock className="mr-2 text-yellow-500" /> Hours Distribution
                </h2>
                <AttendanceRadialChart 
                  percentage={employeeData.summary.monthly.attendancePercentage} 
                />
              </div>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={overtimeData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={90}
                      paddingAngle={2}
                      dataKey="value"
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      labelLine={false}
                    >
                      {overtimeData.map((entry, index) => (
                        <Cell 
                          key={`cell-${index}`} 
                          fill={index === 0 ? '#F59E0B' : '#3B82F6'} 
                        />
                      ))}
                    </Pie>
                    <Tooltip 
                      formatter={(value) => [`${value} hours`, '']}
                      contentStyle={{
                        backgroundColor: '#FFFFFF',
                        border: '1px solid #E5E7EB',
                        borderRadius: '0.5rem',
                        boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                      }}
                    />
                    <Legend 
                      iconType="circle"
                      wrapperStyle={{ paddingTop: '20px' }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        )}

        {/* Team Members Section */}
        <div className="bg-white border border-gray-100 rounded-2xl p-6 shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-semibold text-gray-800 flex items-center">
              <FaUserTie className="mr-2 text-blue-500" /> Team Members
            </h2>
            <span className="text-sm text-gray-500">
              {teamData.length} members in {teamName}
            </span>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {teamData.map((member) => (
              <div
                key={member.employee_id}
                className="bg-gray-50 hover:bg-white border border-gray-100 p-4 rounded-xl shadow-xs hover:shadow-sm transition-all duration-200"
              >
                <div className="flex items-center space-x-3">
                  <div className="relative">
                    <img
                      src={member.photo || '/default-user.png'}
                      alt={member.name}
                      className="w-12 h-12 rounded-full object-cover border-2 border-white shadow"
                    />
                    <div 
                      className={`absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-white ${
                        member.monthly.attendancePercentage > 90 ? 'bg-green-500' :
                        member.monthly.attendancePercentage > 70 ? 'bg-yellow-500' : 'bg-red-500'
                      }`}
                    />
                  </div>
                  <div>
                    <h3 className="font-medium text-gray-900">{member.name}</h3>
                    <p className="text-xs text-gray-500">{member.designation}</p>
                  </div>
                </div>
                <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
                  <div className="flex items-center">
                    <div className="w-2 h-2 rounded-full bg-blue-500 mr-1"></div>
                    <span>Present:</span>
                    <span className="font-medium ml-1">{member.monthly.presentDays}</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-2 h-2 rounded-full bg-yellow-500 mr-1"></div>
                    <span>Leave:</span>
                    <span className="font-medium ml-1">{member.monthly.leaveDays}</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-2 h-2 rounded-full bg-red-500 mr-1"></div>
                    <span>Absent:</span>
                    <span className="font-medium ml-1">{member.monthly.absentDays}</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-2 h-2 rounded-full bg-green-500 mr-1"></div>
                    <span>OT Hours:</span>
                    <span className="font-medium ml-1">{member.monthly.totalOvertimeHours}</span>
                  </div>
                </div>
                <div className="mt-3 pt-2 border-t border-gray-100">
                  <div className="flex justify-between items-center">
                    <span className="text-xs text-gray-500">Attendance</span>
                    <span className={`text-xs font-medium ${
                      member.monthly.attendancePercentage > 90 ? 'text-green-600' :
                      member.monthly.attendancePercentage > 70 ? 'text-yellow-600' : 'text-red-600'
                    }`}>
                      {member.monthly.attendancePercentage}%
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-1.5 mt-1">
                    <div 
                      className={`h-1.5 rounded-full ${
                        member.monthly.attendancePercentage > 90 ? 'bg-green-500' :
                        member.monthly.attendancePercentage > 70 ? 'bg-yellow-500' : 'bg-red-500'
                      }`} 
                      style={{ width: `${member.monthly.attendancePercentage}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
}