import { useState, useEffect } from 'react';
import AttendanceCard from './attendance/AttendanceCard';
import AttendanceStats from './attendance/AttendanceStats';
import AttendanceCalendar from './attendance/AttendanceCalendar';
// import CheckInOutButton from './attendance/CheckInOutButton';
import { useSelector } from 'react-redux';

export default function AttendancePage() {
  const [attendanceData, setAttendanceData] = useState([]);
  const [attendanceSummary, setAttendanceSummary] = useState(null);
  const [selectedCategory, setSelectedCategory] = useState(null);   
  const [currentView, setCurrentView] = useState('today');
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    date: '',
    team: 'All',
    status: 'All'
  });

   const user = useSelector((state) => state.auth.user);
  const employeeId = user?.employee?.id;

   useEffect(() => {
      const fetchTasks = async () => {
        try {
          const res = await fetch(`http://localhost:5000/api/attendance/employee/${employeeId}`);
          if (!res.ok) throw new Error("Failed to fetch tasks");
          const data = await res.json();
         console.log(data.tasks || []);
        } catch (err) {
            console.log(err.message);
        } finally {
            console.log(false);
        }
      };
      if (employeeId) fetchTasks();
    }, [employeeId]);

  useEffect(() => {
    const fetchAttendanceData = async () => {
      try {
        setLoading(true);
        const params = new URLSearchParams();
        if (filters.date) params.append('date', filters.date);
        if (filters.team !== 'All') params.append('team', filters.team);
        if (filters.status !== 'All') params.append('status', filters.status);

        const response = await fetch(`http://localhost:5000/api/attendance?${params.toString()}`);
        const data = await response.json();
        setAttendanceData(data);
      } catch (error) {
        console.error('Error fetching attendance:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchAttendanceData();
  }, [filters]);

  useEffect(() => {
    const fetchAttendanceSummary = async () => {
      try {
        const response = await fetch('http://localhost:5000/api/attendance/summary');
        const summary = await response.json();
        setAttendanceSummary(summary);
      } catch (error) {
        console.error('Error fetching attendance summary:', error);
      }
    };

    fetchAttendanceSummary();
  }, []);

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-3xl font-bold text-[#3F8CFF] mb-6">Attendance Dashboard</h1>

        {/* Filters */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <input
            type="date"
            value={filters.date}
            onChange={(e) => setFilters((prev) => ({ ...prev, date: e.target.value }))}
            className="border px-4 py-2 rounded-md"
          />
          <select
            value={filters.team}
            onChange={(e) => setFilters((prev) => ({ ...prev, team: e.target.value }))}
            className="border px-4 py-2 rounded-md"
          >
            <option value="All">All Teams</option>
            <option value="Development">Development</option>
            <option value="Marketing">Marketing</option>
            <option value="HR">HR</option>
          </select>
          <select
            value={filters.status}
            onChange={(e) => setFilters((prev) => ({ ...prev, status: e.target.value }))}
            className="border px-4 py-2 rounded-md"
          >
            <option value="All">All Status</option>
            <option value="Present">Present</option>
            <option value="Absent">Absent</option>
            <option value="Leave">Leave</option>
          </select>
        </div>

        {/* View Toggle */}
        <div className="flex space-x-4 mb-6">
          <button
            onClick={() => setCurrentView('today')}
            className={`px-4 py-2 rounded-full ${currentView === 'today' ? 'bg-[#3F8CFF] text-white' : 'bg-white text-[#3F8CFF] border border-[#3F8CFF]'}`}
          >
            Today's View
          </button>
          <button
            onClick={() => setCurrentView('calendar')}
            className={`px-4 py-2 rounded-full ${currentView === 'calendar' ? 'bg-[#3F8CFF] text-white' : 'bg-white text-[#3F8CFF] border border-[#3F8CFF]'}`}
          >
            Calendar View
          </button>
        </div>

        {/* Check In/Out Button */}
        {/* <CheckInOutButton/> */}

        {/* Stats Cards */}
      {attendanceSummary && (
  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
    <div
      onClick={() => setSelectedCategory('all')}
      className={`cursor-pointer bg-white p-4 rounded-lg shadow border-l-4 ${
        selectedCategory === 'all' ? 'border-blue-700 bg-blue-50' : 'border-green-500'
      }`}
    >
      <h3 className="text-sm font-medium text-gray-500">Total Employees</h3>
      <p className="text-2xl font-bold text-gray-900">{attendanceSummary.totalEmployees}</p>
    </div>
    <div
      onClick={() => setSelectedCategory('present')}
      className={`cursor-pointer bg-white p-4 rounded-lg shadow border-l-4 ${
        selectedCategory === 'present' ? 'border-blue-700 bg-blue-50' : 'border-yellow-500'
      }`}
    >
      <h3 className="text-sm font-medium text-gray-500">Total Present</h3>
      <p className="text-2xl font-bold text-gray-900">{attendanceSummary.totalPresent}</p>
    </div>
    <div
      onClick={() => setSelectedCategory('leave')}
      className={`cursor-pointer bg-white p-4 rounded-lg shadow border-l-4 ${
        selectedCategory === 'leave' ? 'border-blue-700 bg-blue-50' : 'border-red-500'
      }`}
    >
      <h3 className="text-sm font-medium text-gray-500">Total On Leave</h3>
      <p className="text-2xl font-bold text-gray-900">{attendanceSummary.totalOnLeave}</p>
    </div>
    <div
      onClick={() => setSelectedCategory('absent')}
      className={`cursor-pointer bg-white p-4 rounded-lg shadow border-l-4 ${
        selectedCategory === 'absent' ? 'border-blue-700 bg-blue-50' : 'border-purple-500'
      }`}
    >
      <h3 className="text-sm font-medium text-gray-500">Total Absent</h3>
      <p className="text-2xl font-bold text-gray-900">{attendanceSummary.totalAbsent}</p>
    </div>
  </div>
)}

        {/* Attendance Stats */}
        <AttendanceStats data={attendanceData} />
         {selectedCategory && (
  <div className="bg-white p-4 rounded-lg shadow mb-6">
    <h2 className="text-xl font-semibold mb-4 capitalize">
      {selectedCategory === 'all'
        ? 'All Employees'
        : selectedCategory === 'present'
        ? 'Present Employees'
        : selectedCategory === 'leave'
        ? 'Employees on Leave'
        : 'Absent Employees'}
    </h2>

    <ul className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
      {(selectedCategory === 'all'
        ? attendanceSummary.allEmployees
        : selectedCategory === 'present'
        ? attendanceSummary.presentEmployees
        : selectedCategory === 'leave'
        ? attendanceSummary.leaveEmployees
        : attendanceSummary.absentEmployees
      ).map((emp) => (
        <li
          key={emp.id}
          className="flex items-center space-x-4 bg-gray-50 p-3 rounded-lg shadow-sm"
        >
          <img
            src={`http://localhost:5000/uploads/${emp.photo}`}
            alt={emp.name}
            className="w-12 h-12 rounded-full object-cover border"
          />
          <div>
            <p className="font-medium">{emp.name}</p>
            <p className="text-sm text-gray-500">{emp.team_name}</p>
          </div>
        </li>
      ))}
    </ul>
  </div>
)}
        {/* Main Content */}
        {currentView === 'today' ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
            {loading ? (
              <div className="col-span-2 flex justify-center items-center h-64">
                <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-[#3F8CFF]"></div>
              </div>
            ) : (
              attendanceData.map((record) => (
                <AttendanceCard key={record.id} record={record} />
              ))
            )}
          </div>
        ) : (
          <div className="bg-white rounded-xl shadow-md p-6 mt-6">
            <AttendanceCalendar data={attendanceData} />
          </div>
        )}
      </div>

     

    </div>
  );
}
