import React, { useState, useEffect } from 'react';
import axios from 'axios';

const API_BASE_URL = 'http://localhost:5000/api';
const UPLOADS_BASE_URL = 'http://localhost:5000';

const CompactRoomTable = () => {
  const roomOptions = [
    'Deluxe King Room',
    'Deluxe Twin Room',
    'Premier Room',
    'Executive Room',
    'Club Room',
    'Junior Suite',
    'Executive Suite',
    'Presidential Suite'
  ];

  const [tableData, setTableData] = useState([
    {
      id: 1,
      category: '',
      subCategory: '',
      quantity: '',
      area: '',
      capacity: '',
      features: '',
      remarks: '',
      roomImage: null,
      hotelImage: null,
      roomImagePreview: null,
      hotelImagePreview: null
    }
  ]);

  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [existingRooms, setExistingRooms] = useState([]);
  const [showForm, setShowForm] = useState(false);

  // Fetch existing rooms on component mount
  useEffect(() => {
    fetchAllRooms();
  }, []);

  // API: Get all rooms
  const fetchAllRooms = async () => {
    try {
      setLoading(true);
      const response = await axios.get(`${API_BASE_URL}/rooms`);
      
      if (response.data.success) {
        setExistingRooms(response.data.data);
        console.log('Fetched rooms:', response.data.data);
      }
    } catch (error) {
      console.error('Error fetching rooms:', error);
      alert('Failed to fetch existing rooms. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  // API: Create room
  const createRoomAPI = async (roomData) => {
    try {
      const formData = new FormData();
      
      formData.append('category', roomData.category);
      formData.append('subCategory', roomData.subCategory);
      formData.append('quantity', roomData.quantity);
      formData.append('area', roomData.area);
      formData.append('capacity', roomData.capacity);
      formData.append('features', roomData.features);
      formData.append('remarks', roomData.remarks);
      
      if (roomData.roomImage) {
        formData.append('roomImage', roomData.roomImage);
      }
      if (roomData.hotelImage) {
        formData.append('hotelImage', roomData.hotelImage);
      }

      const response = await axios.post(`${API_BASE_URL}/rooms`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      return response.data;
    } catch (error) {
      console.error('Error creating room:', error);
      throw error;
    }
  };

  // API: Create multiple rooms (bulk)
  const createBulkRooms = async (roomsData) => {
    try {
      const response = await axios.post(`${API_BASE_URL}/rooms/bulk`, {
        rooms: roomsData
      });

      return response.data;
    } catch (error) {
      console.error('Error creating bulk rooms:', error);
      throw error;
    }
  };

  // API: Update room
  const updateRoomAPI = async (id, roomData) => {
    try {
      const formData = new FormData();
      
      formData.append('category', roomData.category);
      formData.append('subCategory', roomData.subCategory);
      formData.append('quantity', roomData.quantity);
      formData.append('area', roomData.area);
      formData.append('capacity', roomData.capacity);
      formData.append('features', roomData.features);
      formData.append('remarks', roomData.remarks);
      
      if (roomData.roomImage) {
        formData.append('roomImage', roomData.roomImage);
      }
      if (roomData.hotelImage) {
        formData.append('hotelImage', roomData.hotelImage);
      }

      const response = await axios.put(`${API_BASE_URL}/rooms/${id}`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      return response.data;
    } catch (error) {
      console.error('Error updating room:', error);
      throw error;
    }
  };

  // API: Delete room
  const deleteRoomAPI = async (id) => {
    try {
      const response = await axios.delete(`${API_BASE_URL}/rooms/${id}`);
      return response.data;
    } catch (error) {
      console.error('Error deleting room:', error);
      throw error;
    }
  };

  const handleDropdownChange = (index, value) => {
    const updatedData = tableData.map((row, rowIndex) => 
      rowIndex === index ? { ...row, subCategory: value } : row
    );
    setTableData(updatedData);
  };

  const handleInputChange = (index, field, value) => {
    const updatedData = tableData.map((row, rowIndex) => 
      rowIndex === index ? { ...row, [field]: value } : row
    );
    setTableData(updatedData);
  };

  const handleImageUpload = (index, field, file) => {
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const updatedData = tableData.map((row, rowIndex) => 
          rowIndex === index ? { 
            ...row, 
            [field]: file,
            [`${field}Preview`]: e.target.result
          } : row
        );
        setTableData(updatedData);
      };
      reader.readAsDataURL(file);
    } else {
      alert('Please select a valid image file.');
    }
  };

  const handleImageRemove = (index, field) => {
    const updatedData = tableData.map((row, rowIndex) => 
      rowIndex === index ? { 
        ...row, 
        [field]: null,
        [`${field}Preview`]: null
      } : row
    );
    setTableData(updatedData);
  };

  const addNewRow = () => {
    setTableData([
      ...tableData,
      {
        id: Date.now(),
        category: '',
        subCategory: '',
        quantity: '',
        area: '',
        capacity: '',
        features: '',
        remarks: '',
        roomImage: null,
        hotelImage: null,
        roomImagePreview: null,
        hotelImagePreview: null
      }
    ]);
  };

  const removeRow = (index) => {
    if (tableData.length > 1) {
      const updatedData = tableData.filter((_, rowIndex) => rowIndex !== index);
      setTableData(updatedData);
    }
  };

  const handleSubmit = async () => {
    const isValid = tableData.every(row => {
      return row.category && row.subCategory && row.quantity && row.area && row.capacity;
    });

    if (!isValid) {
      alert('Please fill in all required fields (Category, Sub-Category, Quantity, Area, Capacity) for all rows.');
      return;
    }

    try {
      setSubmitting(true);

      const submissionData = tableData.map(row => ({
        category: row.category,
        subCategory: row.subCategory,
        quantity: parseInt(row.quantity),
        area: parseFloat(row.area),
        capacity: parseInt(row.capacity),
        features: row.features || '',
        remarks: row.remarks || '',
        roomImage: row.roomImage,
        hotelImage: row.hotelImage,
      }));

      console.log('Submission Data:', submissionData);

      const hasExistingIds = tableData.some(row => row.id && row.id < 1000);

      let results;
      if (hasExistingIds) {
        const updatePromises = tableData.map(row => {
          if (row.id && row.id < 1000) {
            return updateRoomAPI(row.id, row);
          } else {
            return createRoomAPI(row);
          }
        });
        results = await Promise.all(updatePromises);
        console.log('Rooms updated successfully:', results);
        alert('Room configurations updated successfully!');
      } else {
        const hasImages = submissionData.some(room => room.roomImage || room.hotelImage);

        if (hasImages) {
          const creationPromises = submissionData.map(roomData => createRoomAPI(roomData));
          results = await Promise.all(creationPromises);
          console.log('All rooms created successfully:', results);
          alert(`${results.length} room configurations created successfully!`);
        } else {
          const result = await createBulkRooms(submissionData);
          results = [result];
          console.log('Bulk rooms created successfully:', result);
          alert(`${result.data.insertedCount} room configurations created successfully!`);
        }
      }

      await fetchAllRooms();
      setShowForm(false);
      handleReset();

    } catch (error) {
      console.error('Error submitting room configurations:', error);
      if (error.response?.data?.message) {
        alert(`Failed to submit: ${error.response.data.message}`);
      } else {
        alert('Failed to submit room configurations. Please try again.');
      }
    } finally {
      setSubmitting(false);
    }
  };

  const handleReset = () => {
    setTableData([
      {
        id: Date.now(),
        category: '',
        subCategory: '',
        quantity: '',
        area: '',
        capacity: '',
        features: '',
        remarks: '',
        roomImage: null,
        hotelImage: null,
        roomImagePreview: null,
        hotelImagePreview: null
      }
    ]);
  };

  const loadExistingDataForEditing = () => {
    if (existingRooms.length > 0) {
      const formattedData = existingRooms.map((room) => ({
        id: room.id,
        category: room.category || '',
        subCategory: room.subCategory || '',
        quantity: room.quantity?.toString() || '',
        area: room.area?.toString() || '',
        capacity: room.capacity?.toString() || '',
        features: room.features || '',
        remarks: room.remarks || '',
        roomImage: null,
        hotelImage: null,
        roomImagePreview: room.roomImageUrl ? `${UPLOADS_BASE_URL}${room.roomImageUrl}` : null,
        hotelImagePreview: room.hotelImageUrl ? `${UPLOADS_BASE_URL}${room.hotelImageUrl}` : null
      }));
      setTableData(formattedData);
      setShowForm(true);
    }
  };

  const startCreatingNewRooms = () => {
    handleReset();
    setShowForm(true);
  };

  const handleDeleteRoom = async (roomId) => {
    if (window.confirm('Are you sure you want to delete this room configuration?')) {
      try {
        setLoading(true);
        await deleteRoomAPI(roomId);
        await fetchAllRooms();
        alert('Room configuration deleted successfully!');
      } catch (error) {
        console.error('Error deleting room:', error);
        alert('Failed to delete room configuration. Please try again.');
      } finally {
        setLoading(false);
      }
    }
  };

  const clearExistingData = async () => {
    if (window.confirm('Are you sure you want to clear all existing room configurations? This action cannot be undone.')) {
      try {
        setLoading(true);
        const deletePromises = existingRooms.map(room => deleteRoomAPI(room.id));
        await Promise.all(deletePromises);
        setExistingRooms([]);
        alert('All room configurations have been cleared successfully!');
      } catch (error) {
        console.error('Error clearing rooms:', error);
        alert('Failed to clear room configurations. Please try again.');
      } finally {
        setLoading(false);
      }
    }
  };

  return (
    <div className="font-sans max-w-7xl mx-auto">
      <div className="bg-white rounded-lg shadow-lg">
        <div className="p-6 border-b border-gray-200">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-2xl font-bold text-gray-800 mb-2">Room Configuration</h2>
              <p className="text-gray-600">
                {showForm ? 'Add or edit room configurations' : 'View and manage your room configurations'}
              </p>
            </div>
            <div className="flex gap-2">
              <button 
                onClick={fetchAllRooms}
                disabled={loading}
                className="px-4 py-2 bg-purple-500 text-white rounded-md text-sm font-medium hover:bg-purple-600 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2 transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? 'Refreshing...' : 'Refresh'}
              </button>
              
              {!showForm ? (
                <>
                  {existingRooms.length > 0 && (
                    <button 
                      onClick={loadExistingDataForEditing}
                      className="px-4 py-2 bg-blue-500 text-white rounded-md text-sm font-medium hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors duration-200"
                    >
                      Edit Rooms
                    </button>
                  )}
                  <button 
                    onClick={startCreatingNewRooms}
                    className="px-4 py-2 bg-green-500 text-white rounded-md text-sm font-medium hover:bg-green-600 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition-colors duration-200"
                  >
                    Add New Rooms
                  </button>
                </>
              ) : (
                <button 
                  onClick={() => setShowForm(false)}
                  className="px-4 py-2 bg-gray-500 text-white rounded-md text-sm font-medium hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-colors duration-200"
                >
                  Back to List
                </button>
              )}

              {!showForm && existingRooms.length > 0 && (
                <button 
                  onClick={clearExistingData}
                  disabled={loading}
                  className="px-4 py-2 bg-red-500 text-white rounded-md text-sm font-medium hover:bg-red-600 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Clear All
                </button>
              )}
            </div>
          </div>
        </div>
        
        <div className="p-6">
          {/* SHOW LIST DATA IN TABLE FORMAT (Default View) */}
          {!showForm && (
            <>
              {/* Existing Rooms Summary */}
             

              {/* Room List in Table Format */}
              {existingRooms.length > 0 ? (
                <div className="overflow-x-auto border border-gray-200 rounded-lg">
                  <table className="min-w-full bg-white">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider border-r">ID</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider border-r">Category</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider border-r">Sub-Category</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider border-r">Qty</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider border-r">Area (sq.ft.)</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider border-r">Capacity</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider border-r">Features</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider border-r">Remarks</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider border-r">Room Image</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider border-r">Hotel Image</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                      {existingRooms.map((room) => (
                        <tr key={room.id} className="hover:bg-gray-50 transition-colors duration-150">
                          <td className="px-4 py-3 border-r text-sm text-gray-900">{room.id}</td>
                          <td className="px-4 py-3 border-r text-sm text-gray-900">{room.category}</td>
                          <td className="px-4 py-3 border-r text-sm text-gray-900">{room.subCategory}</td>
                          <td className="px-4 py-3 border-r text-sm text-gray-900">{room.quantity}</td>
                          <td className="px-4 py-3 border-r text-sm text-gray-900">{room.area}</td>
                          <td className="px-4 py-3 border-r text-sm text-gray-900">{room.capacity}</td>
                          <td className="px-4 py-3 border-r text-sm text-gray-600 max-w-xs">
                            <div className="line-clamp-2" title={room.features}>
                              {room.features || '-'}
                            </div>
                          </td>
                          <td className="px-4 py-3 border-r text-sm text-gray-600 max-w-xs">
                            <div className="line-clamp-2" title={room.remarks}>
                              {room.remarks || '-'}
                            </div>
                          </td>
                          <td className="px-4 py-3 border-r text-sm text-gray-600">
                            {room.roomImageUrl ? (
                              <div className="flex flex-col items-center space-y-1">
                                <img 
                                  src={`${UPLOADS_BASE_URL}${room.roomImageUrl}`} 
                                  alt="Room" 
                                  className="w-16 h-16 object-cover rounded border hover:scale-110 transition-transform duration-200 cursor-pointer"
                                  onClick={() => window.open(`${UPLOADS_BASE_URL}${room.roomImageUrl}`, '_blank')}
                                />
                                <span className="text-xs text-green-600 bg-green-50 px-2 py-1 rounded">Uploaded</span>
                                <span className="text-xs text-gray-500 truncate max-w-20">
                                  {room.roomImage?.split('-').slice(1).join('-') || 'Room Image'}
                                </span>
                              </div>
                            ) : (
                              <span className="text-gray-400 text-sm">No image</span>
                            )}
                          </td>
                          <td className="px-4 py-3 border-r text-sm text-gray-600">
                            {room.hotelImageUrl ? (
                              <div className="flex flex-col items-center space-y-1">
                                <img 
                                  src={`${UPLOADS_BASE_URL}${room.hotelImageUrl}`} 
                                  alt="Hotel" 
                                  className="w-16 h-16 object-cover rounded border hover:scale-110 transition-transform duration-200 cursor-pointer"
                                  onClick={() => window.open(`${UPLOADS_BASE_URL}${room.hotelImageUrl}`, '_blank')}
                                />
                                <span className="text-xs text-green-600 bg-green-50 px-2 py-1 rounded">Uploaded</span>
                                <span className="text-xs text-gray-500 truncate max-w-20">
                                  {room.hotelImage?.split('-').slice(1).join('-') || 'Hotel Image'}
                                </span>
                              </div>
                            ) : (
                              <span className="text-gray-400 text-sm">No image</span>
                            )}
                          </td>
                          <td className="px-4 py-3">
                            <button
                              onClick={() => handleDeleteRoom(room.id)}
                              className="px-3 py-1 bg-red-500 text-white rounded text-xs font-medium hover:bg-red-600 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-1 transition-colors duration-200"
                            >
                              Delete
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                /* Empty state when no rooms exist */
                <div className="text-center py-12">
                  <div className="text-gray-400 text-6xl mb-4">🏨</div>
                  <h3 className="text-xl font-semibold text-gray-600 mb-2">No Room Configurations</h3>
                  <p className="text-gray-500 mb-6">Get started by creating your first room configuration.</p>
                  <button 
                    onClick={startCreatingNewRooms}
                    className="px-6 py-3 bg-green-500 text-white rounded-lg text-base font-medium hover:bg-green-600 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition-colors duration-200"
                  >
                    Create Room Configuration
                  </button>
                </div>
              )}
            </>
          )}

          {/* SHOW FORM (When showForm is true) */}
          {showForm && (
            <>
             

              <div className="overflow-x-auto mb-6 border border-gray-200 rounded-lg">
                <table className="min-w-full bg-white">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider border-r">Category</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider border-r">Sub-Category</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider border-r">Qty</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider border-r">Area (sq.ft.)</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider border-r">Capacity</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider border-r">Features</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider border-r">Remarks</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider border-r">Room Image</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider border-r">Hotel Image</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {tableData.map((row, index) => (
                      <tr key={row.id} className="hover:bg-gray-50 transition-colors duration-150">
                        <td className="px-4 py-3 border-r">
                          <input
                            type="text"
                            value={row.category}
                            onChange={(e) => handleInputChange(index, 'category', e.target.value)}
                            placeholder="e.g., Standard, Luxury"
                            className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                          />
                        </td>
                        <td className="px-4 py-3 border-r">
                          <select
                            value={row.subCategory}
                            onChange={(e) => handleDropdownChange(index, e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                          >
                            <option value="">Select Room Type</option>
                            {roomOptions.map((option) => (
                              <option key={option} value={option}>{option}</option>
                            ))}
                          </select>
                        </td>
                        <td className="px-4 py-3 border-r">
                          <input
                            type="number"
                            min="0"
                            value={row.quantity}
                            onChange={(e) => handleInputChange(index, 'quantity', e.target.value)}
                            placeholder="0"
                            className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                          />
                        </td>
                        <td className="px-4 py-3 border-r">
                          <input
                            type="number"
                            min="0"
                            step="0.1"
                            value={row.area}
                            onChange={(e) => handleInputChange(index, 'area', e.target.value)}
                            placeholder="0.0"
                            className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                          />
                        </td>
                        <td className="px-4 py-3 border-r">
                          <input
                            type="number"
                            min="0"
                            value={row.capacity}
                            onChange={(e) => handleInputChange(index, 'capacity', e.target.value)}
                            placeholder="0"
                            className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                          />
                        </td>
                        <td className="px-4 py-3 border-r">
                          <textarea
                            value={row.features}
                            onChange={(e) => handleInputChange(index, 'features', e.target.value)}
                            placeholder="Room features & amenities"
                            className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 resize-none"
                            rows="2"
                          />
                        </td>
                        <td className="px-4 py-3 border-r">
                          <textarea
                            value={row.remarks}
                            onChange={(e) => handleInputChange(index, 'remarks', e.target.value)}
                            placeholder="Additional notes"
                            className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 resize-none"
                            rows="2"
                          />
                        </td>
                        <td className="px-4 py-3 border-r">
                          <div className="space-y-2">
                            <label className="block">
                              <input
                                type="file"
                                accept="image/*"
                                onChange={(e) => handleImageUpload(index, 'roomImage', e.target.files[0])}
                                className="hidden"
                                id={`room-image-${index}`}
                              />
                              <span className="block w-full px-3 py-2 bg-blue-50 text-blue-700 rounded-md text-sm font-medium text-center cursor-pointer hover:bg-blue-100 transition-colors duration-200 border border-blue-200">
                                Choose Room Image
                              </span>
                            </label>
                            {row.roomImagePreview && (
                              <div className="relative">
                                <img 
                                  src={row.roomImagePreview} 
                                  alt="Room preview" 
                                  className="w-full h-20 object-cover rounded border"
                                />
                                <button
                                  type="button"
                                  onClick={() => handleImageRemove(index, 'roomImage')}
                                  className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs hover:bg-red-600 transition-colors duration-200"
                                >
                                  ×
                                </button>
                                <p className="text-xs text-gray-500 mt-1 truncate">
                                  {row.roomImage?.name || 'Existing Image'}
                                </p>
                              </div>
                            )}
                          </div>
                        </td>
                        <td className="px-4 py-3 border-r">
                          <div className="space-y-2">
                            <label className="block">
                              <input
                                type="file"
                                accept="image/*"
                                onChange={(e) => handleImageUpload(index, 'hotelImage', e.target.files[0])}
                                className="hidden"
                                id={`hotel-image-${index}`}
                              />
                              <span className="block w-full px-3 py-2 bg-green-50 text-green-700 rounded-md text-sm font-medium text-center cursor-pointer hover:bg-green-100 transition-colors duration-200 border border-green-200">
                                Choose Hotel Image
                              </span>
                            </label>
                            {row.hotelImagePreview && (
                              <div className="relative">
                                <img 
                                  src={row.hotelImagePreview} 
                                  alt="Hotel preview" 
                                  className="w-full h-20 object-cover rounded border"
                                />
                                <button
                                  type="button"
                                  onClick={() => handleImageRemove(index, 'hotelImage')}
                                  className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs hover:bg-red-600 transition-colors duration-200"
                                >
                                  ×
                                </button>
                                <p className="text-xs text-gray-500 mt-1 truncate">
                                  {row.hotelImage?.name || 'Existing Image'}
                                </p>
                              </div>
                            )}
                          </div>
                        </td>
                        <td className="px-4 py-3">
                          <button
                            onClick={() => removeRow(index)}
                            disabled={tableData.length === 1}
                            className={`w-full px-3 py-2 rounded-md text-sm font-medium transition-colors duration-200 ${
                              tableData.length === 1 
                                ? 'bg-gray-200 text-gray-500 cursor-not-allowed' 
                                : 'bg-red-500 text-white hover:bg-red-600 focus:ring-2 focus:ring-red-500 focus:ring-offset-1'
                            }`}
                          >
                            Remove Row
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="flex flex-wrap gap-3 justify-between items-center">
                <div className="flex flex-wrap gap-3">
                  <button 
                    onClick={addNewRow}
                    className="px-4 py-2 bg-blue-500 text-white rounded-md text-sm font-medium hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors duration-200 flex items-center gap-2"
                  >
                    <span>+</span>
                    Add New Row
                  </button>
                  
                  <button 
                    onClick={handleReset}
                    className="px-4 py-2 bg-gray-500 text-white rounded-md text-sm font-medium hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-colors duration-200"
                  >
                    Reset Table
                  </button>
                </div>
                
                <div className="flex gap-3">
                  <button 
                    onClick={() => setShowForm(false)}
                    className="px-6 py-2 bg-gray-500 text-white rounded-md text-sm font-medium hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-colors duration-200"
                  >
                    Cancel
                  </button>
                  <button 
                    onClick={handleSubmit}
                    disabled={submitting}
                    className="px-6 py-2 bg-green-500 text-white rounded-md text-sm font-medium hover:bg-green-600 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {submitting ? 'Submitting...' : 'Submit Configuration'}
                  </button>
                </div>
              </div>

              {/* Summary Section */}

            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default CompactRoomTable;