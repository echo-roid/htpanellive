// import React, { useEffect, useState } from "react";
// import { Pencil, CalendarDays, MapPin, Trash, Archive, X } from "lucide-react";
// import projectimg from "../../assets/projectimg.png";
// import leftarrow from "../../assets/leftarrow.png";
// import { Filter } from "lucide-react";
// import priority from "../../assets/priority.png";
// import { motion } from "framer-motion";
// import pencil from "../../assets/pencil.png";
// import { Switch } from "@headlessui/react";
// import { Bell, ShieldCheck, User, Building2, AppWindow, CreditCard, Lock } from 'lucide-react';
// import dayjs from "dayjs";
// import progress from "../../assets/progress.png";
// import setting from "../../assets/Setting.png";
// import { useParams } from 'react-router-dom';
// import { useDispatch, useSelector } from "react-redux";
// import { fetchEmployees } from "../../redux/slices/employeeSlice";

// const EditEmployeeModal = ({ employee, onClose, onSave }) => {
//   const [formData, setFormData] = useState(employee);
//   const [photoPreview, setPhotoPreview] = useState(employee.photo);
//   const [loading, setLoading] = useState(false);

//   const handleChange = (e) => {
//     const { name, value } = e.target;
//     setFormData(prev => ({ ...prev, [name]: value }));
//   };

//   const handlePhotoChange = (e) => {
//     const file = e.target.files[0];
//     if (file) {
//       setFormData(prev => ({ ...prev, photo: file }));
//       setPhotoPreview(URL.createObjectURL(file));
//     }
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     setLoading(true);
//     try {
//       await onSave(formData);
//       onClose();
//     } finally {
//       setLoading(false);
//     }
//   };

//   return (
//     <div className="fixed inset-0 z-50 bg-black/30 flex items-center justify-center">
//       <div className="bg-white w-[600px] rounded-2xl shadow-lg p-6 relative overflow-y-auto">
//         <button
//           className="absolute top-4 right-4 text-gray-600 hover:text-black"
//           onClick={onClose}
//         >
//           <X size={20} />
//         </button>

//         <h2 className="text-lg font-semibold mb-4">Edit Employee</h2>

//         <form onSubmit={handleSubmit}>
//           <div className="grid grid-cols-2 gap-4">
//             <div>
//               <label className="block text-xs text-gray-500 mb-1">Name</label>
//               <input
//                 name="name"
//                 value={formData.name}
//                 onChange={handleChange}
//                 className="w-full px-3 py-2 rounded-lg border border-gray-200 text-xs"
//                 required
//               />
//             </div>

//             <div>
//               <label className="block text-xs text-gray-500 mb-1">Email</label>
//               <input
//                 name="email"
//                 type="email"
//                 value={formData.email}
//                 onChange={handleChange}
//                 className="w-full px-3 py-2 rounded-lg border border-gray-200 text-xs"
//                 required
//               />
//             </div>

//             <div>
//               <label className="block text-xs text-gray-500 mb-1">Designation</label>
//               <input
//                 name="designation"
//                 value={formData.designation}
//                 onChange={handleChange}
//                 className="w-full px-3 py-2 rounded-lg border border-gray-200 text-xs"
//                 required
//               />
//             </div>

//             <div>
//               <label className="block text-xs text-gray-500 mb-1">Level</label>
//               <input
//                 name="level"
//                 value={formData.level}
//                 onChange={handleChange}
//                 className="w-full px-3 py-2 rounded-lg border border-gray-200 text-xs"
//                 required
//               />
//             </div>

//             <div>
//               <label className="block text-xs text-gray-500 mb-1">Contact Number</label>
//               <input
//                 name="contact_number"
//                 value={formData.contact_number}
//                 onChange={handleChange}
//                 className="w-full px-3 py-2 rounded-lg border border-gray-200 text-xs"
//               />
//             </div>

//             <div>
//               <label className="block text-xs text-gray-500 mb-1">Address</label>
//               <input
//                 name="house_address"
//                 value={formData.house_address}
//                 onChange={handleChange}
//                 className="w-full px-3 py-2 rounded-lg border border-gray-200 text-xs"
//               />
//             </div>

//             <div>
//               <label className="block text-xs text-gray-500 mb-1">Date of Birth</label>
//               <input
//                 name="date_of_birth"
//                 type="date"
//                 value={formData.date_of_birth?.split('T')[0]}
//                 onChange={handleChange}
//                 className="w-full px-3 py-2 rounded-lg border border-gray-200 text-xs"
//               />
//             </div>

//             <div>
//               <label className="block text-xs text-gray-500 mb-1">Reporting Manager</label>
//               <input
//                 name="reporting_manager"
//                 value={formData.reporting_manager}
//                 onChange={handleChange}
//                 className="w-full px-3 py-2 rounded-lg border border-gray-200 text-xs"
//               />
//             </div>

//             <div className="col-span-2">
//               <label className="block text-xs text-gray-500 mb-1">Photo</label>
//               <div className="flex items-center gap-4">
//                 <img 
//                   src={photoPreview} 
//                   alt="Preview" 
//                   className="w-16 h-16 rounded-full object-cover"
//                 />
//                 <input
//                   type="file"
//                   accept="image/*"
//                   onChange={handlePhotoChange}
//                   className="text-xs"
//                 />
//               </div>
//             </div>
//           </div>

//           <div className="mt-6 flex justify-end gap-3">
//             <button
//               type="button"
//               onClick={onClose}
//               className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200"
//             >
//               Cancel
//             </button>
//             <button
//               type="submit"
//               disabled={loading}
//               className="px-4 py-2 text-sm font-medium text-white bg-blue-500 rounded-lg hover:bg-blue-600 disabled:opacity-50"
//             >
//               {loading ? 'Saving...' : 'Save Changes'}
//             </button>
//           </div>
//         </form>
//       </div>
//     </div>
//   );
// };

// const ProjectCard = () => {
//   return (
//     <div className="bg-white rounded-xl shadow-sm flex overflow-hidden w-full max-w-4xl">
//       <div className="flex-1 p-6 space-y-2">
//         <div className='flex gap-3'>
//           <img src={projectimg} alt="projectimg" />
//           <div>
//             <p className="text-xs text-gray-400 ">PN0001265</p>
//             <p className="text-lg font-semibold text-gray-900">
//               Medical App (iOS native)
//             </p>
//           </div>
//         </div>
//         <div className='flex justify-between'>
//           <div className="flex items-center gap-2 text-sm text-gray-500">
//             <CalendarDays className="w-4 h-4" />
//             Created Sep 12, 2020
//           </div>
//           <div className="text-yellow-500 font-medium flex items-center gap-1 text-sm">
//             <span className="text-base font-bold"><img src={priority} alt="priority" className='w-[10px] h-[15px]' /></span> Medium
//           </div>
//         </div>
//       </div>

//       <div className="bg-white border-l px-6 py-4 flex flex-1 flex-col justify-center">
//         <h3 className=" font-semibold text-gray-900 mb-2">Project Data</h3>
//         <div className="flex gap-10">
//           <div>
//             <div className="text-xs text-[#91929E]">All tasks</div>
//             <div className="text-base font-bold text-gray-800">34</div>
//           </div>
//           <div>
//             <div className="text-xs text-[#91929E]">Active tasks</div>
//             <div className="text-base font-bold text-gray-800">13</div>
//           </div>
//           <div>
//             <div className="text-xs text-[#91929E]">Assignees</div>
//             <div className="flex -space-x-2 mt-1">
//               <img src={`https://randomuser.me/api/portraits/men/32.jpg`} className="w-6 h-6 rounded-full border-2 border-white" alt="" />
//               <img src={`https://randomuser.me/api/portraits/men/33.jpg`} className="w-6 h-6 rounded-full border-2 border-white" alt="" />
//               <img src={`https://randomuser.me/api/portraits/men/34.jpg`} className="w-6 h-6 rounded-full border-2 border-white" alt="" />
//               <div className="w-6 h-6 rounded-full bg-blue-500 text-white text-xs font-semibold flex items-center justify-center border-2 border-white">
//                 +2
//               </div>
//             </div>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// const GridUser = ({ team }) => {
//   const dispatch = useDispatch();
//   const { list: employeesRedux, status } = useSelector((state) => state.employee);

//   useEffect(() => {
//     if (status === "idle") {
//       dispatch(fetchEmployees());
//     }
//   }, [status, dispatch]);

//   const itTeamLeaves = employeesRedux.filter(item => 
//     item.team_name && team && 
//     item.team_name.toLowerCase() === team.toLowerCase()
//   );

//   return (
//     <div className="grid grid-cols-4 gap-4 ">
//       {itTeamLeaves.map((elem, i) => (
//         <motion.div
//           key={i}
//           whileHover={{ scale: 1.04 }}
//           className=" shadow rounded-xl p-3 bg-[#F4F9FD] text-center"
//         >
//           <img
//             src={elem?.photo}
//             className="mx-auto rounded-full w-12 h-12 mb-2"
//             alt="user"
//           />
//           <p className="font-medium text-sm">{elem?.name}</p>
//           <p className="text-xs mt-2 text-gray-500">{elem?.designation}</p>
//           <p className="text-[#7D8592] text-[12px] font-semibold mt-2 inline-block py-1 px-3 border-[#7D8592] border-2 rounded-lg">{elem?.level}</p>
//         </motion.div>
//       ))}
//     </div>
//   );
// };

// const LeaveDashboard = () => {
//   const { id } = useParams();
//   const [leaveData, setLeaveData] = useState(null);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState('');
//   const [leaveHistory, setLeaveHistory] = useState([]);

//   useEffect(() => {
//     const fetchLeaveData = async () => {
//       try {
//         setLoading(true);
        
//         const balanceResponse = await fetch(`http://localhost:5000/api/leave/employee/${id}`);
//         if (!balanceResponse.ok) throw new Error('Failed to fetch leave balance');
//         const balanceData = await balanceResponse.json();
        
//         const formatted = Object.entries(balanceData.yearly_balance).reduce((acc, [leaveType, yearlyInfo]) => {
//           const monthlyInfo = balanceData.monthly_balance[leaveType]?.current || {};
//           acc[leaveType] = {
//             yearly: yearlyInfo,
//             monthly: monthlyInfo
//           };
//           return acc;
//         }, {});

//         setLeaveData(formatted);

//         const historyResponse = await fetch(`http://localhost:5000/api/leave/history/${id}`);
//         if (!historyResponse.ok) throw new Error('Failed to fetch leave history');
//         const historyData = await historyResponse.json();
//         setLeaveHistory(historyData);

//       } catch (err) {
//         console.error('Error fetching leave data:', err);
//         setError('Failed to load leave data');
//       } finally {
//         setLoading(false);
//       }
//     };

//     if (id) {
//       fetchLeaveData();
//     }
//   }, [id]);

//   if (loading) {
//     return (
//       <div className="py-6 space-y-6 bg-[#f4f9fd] min-h-screen flex justify-center items-center">
//         <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
//       </div>
//     );
//   }

//   if (error) {
//     return (
//       <div className="py-6 space-y-6 bg-[#f4f9fd] min-h-screen flex justify-center items-center">
//         <div className="text-red-500">{error}</div>
//       </div>
//     );
//   }

//   return (
//     <div className="py-6 space-y-6 bg-[#f4f9fd] min-h-screen">
//       <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
//         {leaveData ? (
//           Object.entries(leaveData).map(([leaveType, info]) => (
//             <div key={leaveType} className="bg-white p-4 rounded-xl shadow-sm">
//               <div className="w-14 h-14 rounded-full border-4 flex items-center justify-center mb-2 text-blue-500 border-blue-200">
//                 <span className="text-lg font-bold text-blue-500">
//                   {info.monthly?.remaining ?? 0}
//                 </span>
//               </div>
//               <h4 className="font-semibold text-gray-800">{leaveType}</h4>
//               <p className="text-[11px] text-[#91929E]">
//                 {info.monthly?.remaining ?? 0} days available (Monthly)
//               </p>
//               <p className="text-[11px] text-[#91929E]">
//                 Used this year: {info.yearly?.used ?? 0} / {info.yearly?.yearly_quota ?? 0}
//               </p>
//             </div>
//           ))
//         ) : (
//           <p className="col-span-3 text-center text-gray-500">Loading leave balances...</p>
//         )}
//       </div>
      
//       <div className="bg-white rounded-xl shadow-sm p-4">
//         <h3 className="font-semibold text-gray-800 mb-4">Leave History</h3>
        
//         <div className="overflow-x-auto">
//           <table className="min-w-full divide-y divide-gray-200">
//             <thead className="bg-gray-50">
//               <tr>
//                 <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Leave Type</th>
//                 <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Start Date</th>
//                 <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">End Date</th>
//                 <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Days</th>
//                 <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
//                 <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Approver</th>
//               </tr>
//             </thead>
//             <tbody className="bg-white divide-y divide-gray-200">
//               {leaveHistory.length > 0 ? (
//                 leaveHistory.map((leave, index) => (
//                   <tr key={index}>
//                     <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900">{leave.leave_type}</td>
//                     <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">
//                       {new Date(leave.start_date).toLocaleDateString()}
//                     </td>
//                     <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">
//                       {new Date(leave.end_date).toLocaleDateString()}
//                     </td>
//                     <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">{leave.days}</td>
//                     <td className="px-4 py-3 whitespace-nowrap">
//                       <span className={`px-2 py-1 text-xs rounded-full font-medium ${
//                         leave.status === 'approved' ? 'bg-green-100 text-green-800' :
//                         leave.status === 'rejected' ? 'bg-red-100 text-red-800' :
//                         'bg-yellow-100 text-yellow-800'
//                       }`}>
//                         {leave.status.charAt(0).toUpperCase() + leave.status.slice(1)}
//                       </span>
//                     </td>
//                     <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">
//                       {leave.approver_name || 'N/A'}
//                     </td>
//                   </tr>
//                 ))
//               ) : (
//                 <tr>
//                   <td colSpan="6" className="px-4 py-4 text-center text-sm text-gray-500">
//                     No leave history found
//                   </td>
//                 </tr>
//               )}
//             </tbody>
//           </table>
//         </div>
//       </div>
//     </div>
//   );
// };

// const ProfileSidebar = () => {
//   const { id } = useParams();
//   const [activeTab, setActiveTab] = useState("Projects");
//   const [dropdownOpen, setDropdownOpen] = useState(false);
//   const [employees, setEmployees] = useState(null);
//   const [isEditModalOpen, setIsEditModalOpen] = useState(false);

//   useEffect(() => {
//     async function fetchEmployeeData() {
//       try {
//         const res = await fetch(`http://localhost:5000/api/employees/${id}`);
//         const result = await res.json();
//         if (result) {
//           setEmployees(result);
//         } else {
//           console.error('Server Error:', result.error);
//         }
//       } catch (err) {
//         console.error('Network Error:', err);
//       }
//     }
//     fetchEmployeeData();
//   }, [id]);

//   async function deleteEmployee() {
//     try {
//       const response = await fetch(`http://localhost:5000/api/employees/${id}`, {
//         method: 'DELETE',
//       });

//       const data = await response.json();

//       if (!response.ok) {
//         throw new Error(data.error || 'Failed to delete employee');
//       }

//       alert('Employee deleted successfully');
//       window.location.href = '/employees'; // Redirect after deletion
//     } catch (error) {
//       console.error('Delete Error:', error.message);
//       alert(`Error: ${error.message}`);
//     }
//   }

//   async function softDeleteEmployee() {
//     try {
//       const response = await fetch(`http://localhost:5000/api/employees/${id}/soft-delete`, {
//         method: 'PATCH',
//       });

//       const data = await response.json();

//       if (!response.ok) {
//         throw new Error(data.error || 'Failed to deactivate employee');
//       }

//       alert('Employee deactivated successfully');
//       window.location.reload(); // Refresh to show updated status
//     } catch (error) {
//       console.error('Soft Delete Error:', error.message);
//       alert(`Error: ${error.message}`);
//     }
//   }

//   const handleEditEmployee = async (updatedData) => {
//     try {
//       const formData = new FormData();
      
//       Object.keys(updatedData).forEach(key => {
//         if (key === 'photo' && typeof updatedData[key] === 'object') {
//           formData.append('photo', updatedData[key]);
//         } else {
//           formData.append(key, updatedData[key]);
//         }
//       });

//       const response = await fetch(`http://localhost:5000/api/employees/${id}`, {
//         method: 'PUT',
//         body: formData,
//       });

//       const data = await response.json();

//       if (!response.ok) {
//         throw new Error(data.error || 'Failed to update employee');
//       }

//       const res = await fetch(`http://localhost:5000/api/employees/${id}`);
//       const result = await res.json();
//       setEmployees(result);
//       return true;
//     } catch (error) {
//       console.error('Update Error:', error.message);
//       alert(`Error: ${error.message}`);
//       return false;
//     }
//   };

//   if (!employees) {
//     return <div className="flex justify-center items-center h-screen">Loading...</div>;
//   }

//   return (
//     <div className="py-4 text-sm">
//       <h1 className="text-2xl font-semibold mb-8 px-2 flex justify-between items-center">
//         My Profile  
//         <img src={setting} className="" width={35} height={35} alt="" />
//       </h1>

//       <div className="flex gap-8">
//         <div className="bg-white rounded-2xl shadow p-4 w-[250px] relative">
//           {/* <Trash 
//             className="w-6 h-6 text-red-500 absolute top-4 bg-[#f4f9fd] p-1 rounded-md shadow cursor-pointer right-[3rem]" 
//             onClick={deleteEmployee} 
//           />
//           <Archive
//             className="w-6 h-6 text-yellow-600 hover:text-yellow-800 absolute top-4 bg-[#f4f9fd] p-1 rounded-md shadow right-[5rem] cursor-pointer"
//             onClick={softDeleteEmployee}
//           /> */}
//           <img 
//             src={pencil} 
//             alt="pencil" 
//             className="absolute top-4 w-[25px] h-[25px] right-4 bg-[#f4f9fd] cursor-pointer p-1 rounded-md shadow" 
//             onClick={() => setIsEditModalOpen(true)}
//           />

//           <div className="flex flex-col mt-4">
//             <img
//               src={employees?.photo}
//               alt="Profile"
//               className="w-16 h-16 rounded-full border-4 border-white shadow -mt-6"
//             />
//             <div className="mt-2 ">
//               <div className="font-semibold text-sm mb-2">{employees?.name}</div>
//               <div className="text-gray-500 text-xs">{employees?.level}-{employees?.designation}</div>
//             </div>
//           </div>

//           <div className="mt-4 border-t pt-4">
//             <h3 className="text-[13px] font-semibold mb-2">Main info</h3>

//             <div className="space-y-2">
//               <label className="block text-xs text-gray-500">Position</label>
//               <input
//                 className="w-full px-3 py-2 rounded-lg border border-gray-200 text-xs"
//                 value={employees?.designation}
//                 readOnly
//               />

//               <label className="block text-xs text-gray-500">Location</label>
//               <div className="relative">
//                 <input
//                   className="w-full px-3 py-2 rounded-lg border border-gray-200 text-xs pr-8"
//                   value={employees?.house_address}
//                   readOnly
//                 />
//                 <MapPin size={14} className="absolute top-2.5 right-3 text-gray-400" />
//               </div>

//               <label className="block text-xs text-gray-500">Birthday Date</label>
//               <div className="relative">
//                 <input
//                   className="w-full px-3 py-2 rounded-lg border border-gray-200 text-xs pr-8"
//                   value={employees?.date_of_birth?.split("T")[0]}
//                   readOnly
//                 />
//                 <CalendarDays size={14} className="absolute top-2.5 right-3 text-gray-400" />
//               </div>
//             </div>
//           </div>

//           <div className="mt-4">
//             <h3 className="text-[13px] font-semibold mb-2">Contact Info</h3>

//             <div className="space-y-2">
//               <label className="block text-xs text-gray-500">Email</label>
//               <input
//                 className="w-full px-3 py-2 rounded-lg border border-gray-200 text-xs"
//                 value={employees?.email}
//                 readOnly
//               />

//               <label className="block text-xs text-gray-500">Mobile Number</label>
//               <input
//                 className="w-full px-3 py-2 rounded-lg border border-gray-200 text-xs"
//                 value={employees?.contact_number}
//                 readOnly
//               />

//               <label className="block text-xs text-gray-500">Manager</label>
//               <input
//                 className="w-full px-3 py-2 rounded-lg border border-gray-200 text-xs"
//                 value={employees?.reporting_manager}
//                 readOnly
//               />

//               <label className="block text-xs text-gray-500">Password</label>
//               <input
//                 className="w-full px-3 py-2 rounded-lg border border-gray-200 text-xs"
//                 value={employees?.password_plain}
//                 readOnly
//               />
//             </div>
//           </div>
//         </div>
        
//         <div className="flex-1">
//           <div className="flex items-center justify-between bg-[#f4f9fd] py-2 rounded-full w-full mb-5">
//             <div className="flex items-center bg-[#e8f0fc] rounded-full p-1 gap-2">
//               {["Projects", "Team", "My vacations"].map((tab) => (
//                 <button
//                   key={tab}
//                   onClick={() => setActiveTab(tab)}
//                   className={`px-4 py-1 rounded-full text-sm font-medium transition-all ${
//                     activeTab === tab
//                       ? "bg-[#2f80ed] text-white shadow"
//                       : "text-gray-600"
//                   }`}
//                 >
//                   {tab}
//                 </button>
//               ))}
//             </div>

//             <div className="flex items-center gap-2 relative">
//               <button className="bg-white p-2 rounded-lg shadow">
//                 <Filter size={16} className="text-gray-600" />
//               </button>

//               <div className="relative">
//                 <button
//                   onClick={() => setDropdownOpen(!dropdownOpen)}
//                   className="bg-white px-4 py-2 rounded-lg shadow text-sm flex items-center gap-1"
//                 >
//                   Current Projects
//                   <svg
//                     className="w-4 h-4"
//                     viewBox="0 0 20 20"
//                     fill="none"
//                     xmlns="http://www.w3.org/2000/svg"
//                   >
//                     <path
//                       d="M6 8L10 12L14 8"
//                       stroke="black"
//                       strokeWidth="1.5"
//                       strokeLinecap="round"
//                       strokeLinejoin="round"
//                     />
//                   </svg>
//                 </button>

//                 {dropdownOpen && (
//                   <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-md z-10">
//                     <div className="py-2 text-sm text-gray-700">
//                       <div className="px-4 py-2 hover:bg-gray-100 cursor-pointer">
//                         All Projects
//                       </div>
//                       <div className="px-4 py-2 hover:bg-gray-100 cursor-pointer">
//                         Archived
//                       </div>
//                       <div className="px-4 py-2 hover:bg-gray-100 cursor-pointer">
//                         Completed
//                       </div>
//                     </div>
//                   </div>
//                 )}
//               </div>
//             </div>
//           </div>
          
//           {activeTab === "Projects" ? (
//             <ProjectCard />
//           ) : activeTab === "Team" ? (
//             <GridUser team={employees?.team_name} />
//           ) : (
//             <LeaveDashboard />
//           )}
//         </div>
//       </div>

//       {isEditModalOpen && (
//         <EditEmployeeModal
//           employee={employees}
//           onClose={() => setIsEditModalOpen(false)}
//           onSave={handleEditEmployee}
//         />
//       )}
//     </div>
//   );
// };

// export default ProfileSidebar;
import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import { Pencil } from "lucide-react";

const EmployeeDetail = ({ onClose, onSave }) => {
  const { id } = useParams();
  const [employee, setEmployee] = useState(null);
  const [documents, setDocuments] = useState(null);
  const [activeTab, setActiveTab] = useState("personal");

  useEffect(() => {
    async function fetchEmployeeData() {
      try {
        const res = await fetch(`http://localhost:5000/api/employees/${id}`);
        const result = await res.json();
        if (result) {
          setEmployee(result);
        } else {
          console.error("Server Error:", result.error);
        }
      } catch (err) {
        console.error("Network Error:", err);
      }
    }
    fetchEmployeeData();
  }, [id]);

  useEffect(() => {
    if (activeTab === "documents") {
      async function fetchDocuments() {
        try {
          const res = await fetch(`http://localhost:5000/api/forms/employeeSpecific/${id}`);
          const result = await res.json();
          if (result?.employee) {
            setDocuments(result.employee);
          } else {
            console.error("Server Error:", result.error);
          }
        } catch (err) {
          console.error("Network Error:", err);
        }
      }
      fetchDocuments();
    }
  }, [id, activeTab]);

  const tabs = [
    { value: "personal", label: "Personal info" },
    { value: "employee", label: "Employee details" },
    { value: "payroll", label: "Payroll details" },
    { value: "documents", label: "Documents" },
    { value: "history", label: "Payroll history" },
    { value: "medical", label: "Medical history" },
    { value: "leave", label: "Leave history" },
  ];

  if (!employee) {
    return <div className="p-6">Loading...</div>;
  }

  // Parse leaves data from JSON string to array
  const parseLeavesData = () => {
    try {
      if (employee.leaves && typeof employee.leaves === 'string') {
        return JSON.parse(employee.leaves);
      }
      return [];
    } catch (error) {
      console.error("Error parsing leaves data:", error);
      return [];
    }
  };

  const leaves = parseLeavesData();
  const documentFiles = [
    { key: "photo_path", label: "Photo" },
    { key: "aadhar_front_path", label: "Aadhar Front" },
    { key: "aadhar_back_path", label: "Aadhar Back" },
    { key: "passport_front_path", label: "Passport Front" },
    { key: "passport_back_path", label: "Passport Back" },
    { key: "edu_10th_path", label: "10th Certificate" },
    { key: "edu_12th_path", label: "12th Certificate" },
    { key: "graduation_path", label: "Graduation Certificate" },
    { key: "diploma_path", label: "Diploma Certificate" },
    { key: "pan_document_path", label: "PAN Document" },
    { key: "cancel_cheque_path", label: "Cancel Cheque" },
    { key: "uan_document_path", label: "UAN Document" },
  ];

  return (
    <div className="p-6 bg-gray-50 min-h-screen">
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-semibold">Employee</h1>
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 rounded-full bg-gray-200 overflow-hidden">
            <img
              src={employee?.photo}
              alt="avatar"
              className="w-full h-full object-cover"
            />
          </div>
          <div className="text-sm">
            <div>{employee?.name}</div>
            <div className="text-gray-500">{employee?.designation}</div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white rounded-md shadow overflow-hidden">
        <div className="flex flex-wrap">
          {tabs.map((tab) => (
            <button
              key={tab.value}
              className={`flex-1 py-3 text-sm font-medium text-center ${
                activeTab === tab.value
                  ? "bg-blue-600 text-white"
                  : "text-gray-700 hover:bg-gray-100"
              }`}
              onClick={() => setActiveTab(tab.value)}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Personal Info Tab */}
      {activeTab === "personal" && (
        <div className="mt-6 grid grid-cols-2 gap-6">
          {/* Existing Personal Info content */}
          <div className="bg-white p-6 rounded-md shadow">
            <div className="flex justify-between mb-4">
              <h2 className="font-semibold">Basic information</h2>
              <Pencil size={16} className="text-gray-400 cursor-pointer" />
            </div>
            <div className="flex gap-4 items-center mb-4">
              <img
                src={employee?.photo}
                alt="avatar"
                className="w-20 h-20 rounded-full object-cover"
              />
              <div>
                <div className="font-medium text-lg">{employee?.name}</div>
                <div className="text-sm text-gray-500">{employee?.identity_id}</div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4 text-sm text-gray-700">
              <div>
                <div>Designation</div>
                <div className="font-medium">{employee?.designation}</div>
              </div>
              <div>
                <div>Team</div>
                <div className="font-medium">{employee?.team_name}</div>
              </div>
              <div>
                <div>Email</div>
                <div className="font-medium">{employee?.email}</div>
              </div>
              <div>
                <div>Phone</div>
                <div className="font-medium">{employee?.contact_number}</div>
              </div>
              <div>
                <div>Birth date</div>
                <div className="font-medium">
                  {new Date(employee?.date_of_birth).toLocaleDateString()}
                </div>
              </div>
              <div>
                <div>Age</div>
                <div className="font-medium">{employee?.age}</div>
              </div>
              <div>
                <div>Reporting Manager</div>
                <div className="font-medium">{employee?.reporting_manager}</div>
              </div>
              <div>
                <div>Current Project</div>
                <div className="font-medium">{employee?.current_project}</div>
              </div>
            </div>
          </div>

          {/* Address */}
          <div className="bg-white p-6 rounded-md shadow">
            <div className="flex justify-between mb-4">
              <h2 className="font-semibold">Address</h2>
              <Pencil size={16} className="text-gray-400 cursor-pointer" />
            </div>
            <div className="text-sm text-gray-700">
              <div className="mb-2">
                <div className="text-gray-500">Residential address</div>
                <div>{employee?.house_address}</div>
              </div>
            </div>
          </div>

          {/* Family */}
          <div className="bg-white p-6 rounded-md shadow">
            <div className="flex justify-between mb-4">
              <h2 className="font-semibold">Family</h2>
              <Pencil size={16} className="text-gray-400 cursor-pointer" />
            </div>
            <div className="text-sm text-gray-700">
              <div className="mb-2">
                Father: <span className="font-medium">{employee?.father_name}</span>
              </div>
              <div className="mb-2">
                Mother: <span className="font-medium">{employee?.mother_name}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Documents Tab */}
      {activeTab === "documents" && documents && (
        <div className="mt-6 grid grid-cols-2 md:grid-cols-3 gap-6">
          {documentFiles.map((doc) => {
            const fileUrl = documents[doc.key];
            if (!fileUrl) return null;
            return (
              <div key={doc.key} className="bg-white p-4 rounded-md shadow flex flex-col items-center">
                <div className="font-medium mb-2">{doc.label}</div>
                <a
                  href={fileUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-600 hover:underline break-all text-sm"
                >
                  {fileUrl.split("/").pop()}
                </a>
              </div>
            );
          })}
        </div>
      )}

      {/* Leave History Tab */}
      {activeTab === "leave" && (
        <div className="mt-6 bg-white rounded-md shadow overflow-hidden">
          <div className="p-6">
            <h2 className="text-xl font-semibold mb-6">Leave History</h2>
            
            {leaves.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                No leave records found
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Leave Type
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Monthly Allocation
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Yearly Allocation
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Used This Month
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Used This Year
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Balance
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {leaves.map((leave, index) => (
                      <tr key={index} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                          {leave.type || 'N/A'}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {leave.monthly || 0}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {leave.yearly || 0}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {leave.used_monthly || 0}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {leave.used_yearly || 0}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                          <span className={`px-2 py-1 rounded-full text-xs ${
                            (leave.monthly - (leave.used_monthly || 0)) > 0 
                              ? 'bg-green-100 text-green-800' 
                              : 'bg-red-100 text-red-800'
                          }`}>
                            Monthly: {leave.monthly - (leave.used_monthly || 0)}
                          </span>
                          <span className={`ml-2 px-2 py-1 rounded-full text-xs ${
                            (leave.yearly - (leave.used_yearly || 0)) > 0 
                              ? 'bg-green-100 text-green-800' 
                              : 'bg-red-100 text-red-800'
                          }`}>
                            Yearly: {leave.yearly - (leave.used_yearly || 0)}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
            
            {/* Leave Summary */}
            {leaves.length > 0 && (
              <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h3 className="font-semibold text-blue-800 mb-2">Total Monthly Allocation</h3>
                  <p className="text-2xl font-bold text-blue-600">
                    {leaves.reduce((sum, leave) => sum + (leave.monthly || 0), 0)}
                  </p>
                </div>
                <div className="bg-green-50 p-4 rounded-lg">
                  <h3 className="font-semibold text-green-800 mb-2">Total Yearly Allocation</h3>
                  <p className="text-2xl font-bold text-green-600">
                    {leaves.reduce((sum, leave) => sum + (leave.yearly || 0), 0)}
                  </p>
                </div>
                <div className="bg-purple-50 p-4 rounded-lg">
                  <h3 className="font-semibold text-purple-800 mb-2">Leave Types</h3>
                  <p className="text-2xl font-bold text-purple-600">{leaves.length}</p>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default EmployeeDetail;