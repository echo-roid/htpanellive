import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { setLeadId } from '../../redux/slices/leadsSlice';

import bookImage  from "../../assets/book.png"
const WonLeadsListing = () => {
  const [leads, setLeads] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [tripTypeFilter, setTripTypeFilter] = useState('All');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const dispatch = useDispatch();

  const fetchWonLeads = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await axios.get('http://localhost:5000/api/leads/won');
      setLeads(response.data);
    } catch (error) {
      console.error('Error fetching won leads:', error);
      setError('Failed to fetch won leads. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchWonLeads();
  }, []);

  // Filter leads based on search term and trip type
  const filteredLeads = leads.filter((lead) => {
    const matchesSearch = lead.clientName?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesTripType = 
      tripTypeFilter === 'All' || 
      lead.domesticInternational?.toLowerCase() === tripTypeFilter.toLowerCase();
    
    return matchesSearch && matchesTripType;
  });

  // Function to handle lead click and store in Redux
  const handleLeadClick = (leadId) => {
    dispatch(setLeadId(leadId));
  };

  // Function to format date
  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    try {
      return new Date(dateString).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      });
    } catch (error) {
      return dateString;
    }
  };

  // Function to get trip type badge styling
  const getTripTypeBadge = (tripType) => {
    switch (tripType?.toLowerCase()) {
      case 'international':
        return 'bg-purple-100 text-purple-800 border border-purple-200';
      case 'domestic':
        return 'bg-green-100 text-green-800 border border-green-200';
      default:
        return 'bg-gray-100 text-gray-800 border border-gray-200';
    }
  };

  if (loading) {
    return (
      <div className="p-6 bg-white rounded-lg shadow-md flex justify-center items-center h-64">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading won leads...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6 bg-white rounded-lg shadow-md">
        <div className="text-center text-red-600">
          <p className="mb-4">{error}</p>
          <button
            onClick={fetchWonLeads}
            className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-400"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6  ">
      <div className="flex justify-between items-center mb-6">
        <h3 className="font-bold text-gray-800">🏆 Won Leads Listing</h3>
         <p className='mb-0 text-[10px] flex gap-1'>
                                          <img src={bookImage} className='mt-0 w-[15px] h-[15px]'/>
                                          Learn More About The  Won Leads
                                      </p>
      </div>

      {/* Filters Section */}
    

      {/* Results Count */}
      <div className="mb-4 flex justify-between items-center">
        <p className="text-[10px] text-gray-600">
          Showing {filteredLeads.length} of {leads.length} won leads
        </p>
        {searchTerm || tripTypeFilter !== 'All' ? (
          <button
            onClick={() => {
              setSearchTerm('');
              setTripTypeFilter('All');
            }}
            className="text-sm text-blue-500 hover:text-blue-700 focus:outline-none"
          >
            Clear filters
          </button>
        ) : null}
      </div>

      {/* Table */}
      {filteredLeads.length > 0 ? (
        <div className="overflow-x-auto   border-gray-100">
      <table className="min-w-full border text-[10px] text-left leading-none border-collapse">
  {/* HEADER */}
  <thead className="bg-gray-50">
    <tr className="h-6">
      <th className="px-2 py-0.5 font-semibold text-gray-700 border-b h-6">
        Client
      </th>
      <th className="px-2 py-0.5 font-semibold text-gray-700 border-b h-6">
        Sales Person
      </th>
      <th className="px-2 py-0.5 font-semibold text-gray-700 border-b h-6">
        Destination
      </th>
      <th className="px-2 py-0.5 font-semibold text-gray-700 border-b h-6">
        Traveling Date
      </th>
      <th className="px-2 py-0.5 font-semibold text-gray-700 border-b h-6">
        Trip Type
      </th>
      <th className="px-2 py-0.5 font-semibold text-gray-700 border-b h-6">
        RFQ Status
      </th>
    </tr>
  </thead>

  {/* BODY */}
  <tbody>
    {filteredLeads.map((lead, idx) => (
      <tr
        key={lead.id || idx}
        className="border-b hover:bg-gray-50 h-6 transition"
      >
        {/* Client */}
        <td className="px-2 py-0.5 whitespace-nowrap align-middle">
          <Link
            to={`/operations/${lead.id}`}
            onClick={() => handleLeadClick(lead.id)}
            className="text-blue-600 hover:underline font-semibold"
          >
            {lead.clientName || "N/A"}
          </Link>
        </td>

        {/* Sales Person */}
        <td className="px-2 py-0.5 whitespace-nowrap align-middle text-gray-700">
          {lead.salesPerson || "N/A"}
        </td>

        {/* Destination */}
        <td className="px-2 py-0.5 whitespace-nowrap align-middle text-gray-700">
          {lead.destination || "N/A"}
        </td>

        {/* Traveling Date */}
        <td className="px-2 py-0.5 whitespace-nowrap align-middle text-gray-700">
          {formatDate(lead.travelingDate)}
        </td>

        {/* Trip Type */}
        <td className="px-2 py-0.5 whitespace-nowrap align-middle">
          <span
            className={`px-1.5 py-[1px] rounded text-[8px] leading-none font-semibold ${getTripTypeBadge(
              lead.domesticInternational
            )}`}
          >
            {lead.domesticInternational || "N/A"}
          </span>
        </td>

        {/* RFQ Status */}
        <td className="px-2 py-0.5 whitespace-nowrap align-middle">
          <span className="px-1.5 py-[1px] rounded text-[8px] leading-none font-semibold bg-green-100 text-green-800 border border-green-200">
            {lead.rfqStatus || "Won"}
          </span>
        </td>
      </tr>
    ))}
  </tbody>
</table>

        </div>
      ) : (
        <div className="text-center py-12">
          <div className="text-gray-400 text-6xl mb-4">🏆</div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">No won leads found</h3>
          <p className="text-gray-500 mb-4">
            {searchTerm || tripTypeFilter !== 'All' 
              ? 'Try adjusting your search criteria or clear filters.'
              : 'No won leads available at the moment.'
            }
          </p>
          {(searchTerm || tripTypeFilter !== 'All') && (
            <button
              onClick={() => {
                setSearchTerm('');
                setTripTypeFilter('All');
              }}
              className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-400"
            >
              Clear filters
            </button>
          )}
        </div>
      )}
    </div>
  );
};

export default WonLeadsListing;