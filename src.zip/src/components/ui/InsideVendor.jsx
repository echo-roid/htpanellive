import React, { useState, useEffect } from "react";
import CompactRoomTable from "./RoomTable.jsx"; // Make sure to import the component

// API base URL - same as your vendor management
const API_BASE_URL = "http://localhost:5000/api";

export default function VendorProfile() {
  const [activeTab, setActiveTab] = useState("dashboard");
  const [vendors, setVendors] = useState([]);
  const [loading, setLoading] = useState(false);
  const [selectedVendor, setSelectedVendor] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");

  const tabs = [
    { id: "dashboard", label: "Dashboard" },
    { id: "vendorDetails", label: "Vendor Details" },
    { id: "product", label: "Product" },
    { id: "payments", label: "Payments" },
    { id: "invoiceTrack", label: "Invoice Track" },
    { id: "tds", label: "TDS" },
    { id: "gstTrack", label: "GST Track" },
  ];

  // Fetch vendors when component mounts or when vendorDetails tab is active
  useEffect(() => {
    if (activeTab === "vendorDetails") {
      fetchVendors();
    }
  }, [activeTab]);

  // API function to fetch all vendors
  const fetchVendors = async () => {
    try {
      setLoading(true);
      const queryParams = new URLSearchParams();
      if (searchTerm) queryParams.append('search', searchTerm);
      
      const response = await fetch(`${API_BASE_URL}/vendors?${queryParams}`);
      const result = await response.json();
      
      if (result.success) {
        setVendors(result.data);
      } else {
        console.error("Failed to fetch vendors:", result.message);
        alert("Failed to load vendors. Please try again.");
      }
    } catch (error) {
      console.error("Error fetching vendors:", error);
      alert("Failed to connect to server. Please check if backend is running.");
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (e) => {
    setSearchTerm(e.target.value);
  };

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    fetchVendors();
  };

  const handleVendorSelect = (vendor) => {
    setSelectedVendor(vendor);
  };

  const getStatusBadge = (status) => {
    const statusColors = {
      Active: "bg-green-100 text-green-800",
      Pending: "bg-yellow-100 text-yellow-800",
      Inactive: "bg-red-100 text-red-800",
    };
    
    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${statusColors[status] || "bg-gray-100 text-gray-800"}`}>
        {status}
      </span>
    );
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-IN');
  };

  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-6">Vendor Profile</h2>

      {/* Tabs */}
      <div className="flex flex-wrap border-b border-gray-300 mb-6">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-5 py-2 text-sm font-medium transition-all ${
              activeTab === tab.id
                ? "border-b-2 border-blue-500 text-blue-600"
                : "text-gray-500 hover:text-blue-500"
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      <div className="bg-white p-6 rounded-xl shadow-sm">
        {activeTab === "dashboard" && (
          <div>
            <h3 className="text-lg font-semibold mb-4">Dashboard</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                <h4 className="font-semibold text-blue-800">Total Vendors</h4>
                <p className="text-2xl font-bold text-blue-600">{vendors.length}</p>
              </div>
              <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                <h4 className="font-semibold text-green-800">Active Vendors</h4>
                <p className="text-2xl font-bold text-green-600">
                  {vendors.filter(v => v.status === 'Active').length}
                </p>
              </div>
              <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-200">
                <h4 className="font-semibold text-yellow-800">Pending Vendors</h4>
                <p className="text-2xl font-bold text-yellow-600">
                  {vendors.filter(v => v.status === 'Pending').length}
                </p>
              </div>
            </div>
            <p>Overview of vendor activities, payments, and invoices.</p>
          </div>
        )}

        {activeTab === "vendorDetails" && (
          <div>
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-lg font-semibold">Vendor Details</h3>
              <form onSubmit={handleSearchSubmit} className="flex gap-2">
                <input
                  type="text"
                  placeholder="Search vendors..."
                  value={searchTerm}
                  onChange={handleSearch}
                  className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <button 
                  type="submit"
                  className="bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700 transition duration-200"
                >
                  Search
                </button>
              </form>
            </div>

            {loading && (
              <div className="text-center py-4">
                <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                <span className="ml-2">Loading vendors...</span>
              </div>
            )}

            {!loading && (
              <div className="overflow-x-auto">
                <table className="min-w-full border border-gray-200 text-sm">
                  <thead className="bg-gray-100">
                    <tr>
                      <th className="p-3 border font-semibold">Vendor ID</th>
                      <th className="p-3 border font-semibold">Vendor Name</th>
                      <th className="p-3 border font-semibold">Business Name</th>
                      <th className="p-3 border font-semibold">Email</th>
                      <th className="p-3 border font-semibold">Phone</th>
                      <th className="p-3 border font-semibold">Contact Person</th>
                      <th className="p-3 border font-semibold">Vendor Type</th>
                      <th className="p-3 border font-semibold">Category</th>
                      <th className="p-3 border font-semibold">Country</th>
                      <th className="p-3 border font-semibold">Status</th>
                      <th className="p-3 border font-semibold">Registered Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    {vendors.length === 0 ? (
                      <tr>
                        <td colSpan="11" className="p-4 border text-center text-gray-500">
                          No vendors found
                        </td>
                      </tr>
                    ) : (
                      vendors.map((vendor) => (
                        <tr 
                          key={vendor.id} 
                          className="hover:bg-gray-50 cursor-pointer transition-colors"
                          onClick={() => handleVendorSelect(vendor)}
                        >
                          <td className="p-3 border font-medium">{vendor.id}</td>
                          <td className="p-3 border">{vendor.vendor_name}</td>
                          <td className="p-3 border">{vendor.business_name || 'N/A'}</td>
                          <td className="p-3 border">{vendor.email}</td>
                          <td className="p-3 border">{vendor.phone || 'N/A'}</td>
                          <td className="p-3 border">{vendor.contact_person}</td>
                          <td className="p-3 border">{vendor.vendor_type}</td>
                          <td className="p-3 border">{vendor.vendor_category}</td>
                          <td className="p-3 border">{vendor.country}</td>
                          <td className="p-3 border">
                            {getStatusBadge(vendor.status)}
                          </td>
                          <td className="p-3 border">{formatDate(vendor.created_at)}</td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            )}

            {/* Vendor Details Modal */}
            {selectedVendor && (
              <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
                <div className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto">
                  <div className="p-6">
                    <div className="flex justify-between items-center mb-6">
                      <h3 className="text-xl font-bold">Vendor Details - {selectedVendor.vendor_name}</h3>
                      <button 
                        onClick={() => setSelectedVendor(null)}
                        className="text-gray-500 hover:text-gray-700"
                      >
                        ✕
                      </button>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {/* Basic Information */}
                      <div className="space-y-4">
                        <h4 className="font-semibold text-lg border-b pb-2">Basic Information</h4>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <label className="text-sm text-gray-600">Vendor ID</label>
                            <p className="font-medium">{selectedVendor.id}</p>
                          </div>
                          <div>
                            <label className="text-sm text-gray-600">Status</label>
                            <div>{getStatusBadge(selectedVendor.status)}</div>
                          </div>
                          <div>
                            <label className="text-sm text-gray-600">Vendor Name</label>
                            <p className="font-medium">{selectedVendor.vendor_name}</p>
                          </div>
                          <div>
                            <label className="text-sm text-gray-600">Business Name</label>
                            <p className="font-medium">{selectedVendor.business_name || 'N/A'}</p>
                          </div>
                          <div>
                            <label className="text-sm text-gray-600">Vendor Type</label>
                            <p className="font-medium">{selectedVendor.vendor_type}</p>
                          </div>
                          <div>
                            <label className="text-sm text-gray-600">Category</label>
                            <p className="font-medium">{selectedVendor.vendor_category}</p>
                          </div>
                          <div>
                            <label className="text-sm text-gray-600">Rating</label>
                            <p className="font-medium">{selectedVendor.rating || 'N/A'}</p>
                          </div>
                        </div>
                      </div>

                      {/* Contact Information */}
                      <div className="space-y-4">
                        <h4 className="font-semibold text-lg border-b pb-2">Contact Information</h4>
                        <div className="space-y-3">
                          <div>
                            <label className="text-sm text-gray-600">Contact Person</label>
                            <p className="font-medium">{selectedVendor.contact_person}</p>
                          </div>
                          <div>
                            <label className="text-sm text-gray-600">Email</label>
                            <p className="font-medium">{selectedVendor.email}</p>
                          </div>
                          <div>
                            <label className="text-sm text-gray-600">Phone</label>
                            <p className="font-medium">{selectedVendor.phone || 'N/A'}</p>
                          </div>
                          <div>
                            <label className="text-sm text-gray-600">Website</label>
                            <p className="font-medium">{selectedVendor.website || 'N/A'}</p>
                          </div>
                        </div>
                      </div>

                      {/* Address Information */}
                      <div className="space-y-4">
                        <h4 className="font-semibold text-lg border-b pb-2">Address Information</h4>
                        <div className="space-y-3">
                          <div>
                            <label className="text-sm text-gray-600">Address Line 1</label>
                            <p className="font-medium">{selectedVendor.address_line1 || 'N/A'}</p>
                          </div>
                          <div>
                            <label className="text-sm text-gray-600">Address Line 2</label>
                            <p className="font-medium">{selectedVendor.address_line2 || 'N/A'}</p>
                          </div>
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <label className="text-sm text-gray-600">State</label>
                              <p className="font-medium">{selectedVendor.state || 'N/A'}</p>
                            </div>
                            <div>
                              <label className="text-sm text-gray-600">Country</label>
                              <p className="font-medium">{selectedVendor.country}</p>
                            </div>
                          </div>
                          <div>
                            <label className="text-sm text-gray-600">ZIP/PIN Code</label>
                            <p className="font-medium">{selectedVendor.zip_pin || 'N/A'}</p>
                          </div>
                          <div>
                            <label className="text-sm text-gray-600">Relationship Country</label>
                            <p className="font-medium">{selectedVendor.relationship_country}</p>
                          </div>
                        </div>
                      </div>

                      {/* Bank & Tax Information */}
                      <div className="space-y-4">
                        <h4 className="font-semibold text-lg border-b pb-2">Bank & Tax Information</h4>
                        <div className="space-y-3">
                          <div>
                            <label className="text-sm text-gray-600">Bank Account Number</label>
                            <p className="font-medium">{selectedVendor.bank_account_number || 'N/A'}</p>
                          </div>
                          <div>
                            <label className="text-sm text-gray-600">IFSC Code</label>
                            <p className="font-medium">{selectedVendor.ifsc_code || 'N/A'}</p>
                          </div>
                          <div>
                            <label className="text-sm text-gray-600">SWIFT Code</label>
                            <p className="font-medium">{selectedVendor.swift_code || 'N/A'}</p>
                          </div>
                          <div>
                            <label className="text-sm text-gray-600">GST Number</label>
                            <p className="font-medium">{selectedVendor.gst_number || 'N/A'}</p>
                          </div>
                          <div>
                            <label className="text-sm text-gray-600">PAN Number</label>
                            <p className="font-medium">{selectedVendor.pan_number || 'N/A'}</p>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="mt-6 flex justify-end space-x-3">
                      <button
                        onClick={() => setSelectedVendor(null)}
                        className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition duration-200"
                      >
                        Close
                      </button>
                      <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition duration-200">
                        Edit Vendor
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {activeTab === "product" && (
          <div>
            <h3 className="text-lg font-semibold mb-4">Product Management</h3>
            <p className="text-gray-600 mb-6">Manage room configurations and product details for vendors.</p>
            
            {/* Integrated CompactRoomTable Component */}
            <CompactRoomTable />
          </div>
        )}

        {activeTab === "payments" && (
          <div>
            <h3 className="text-lg font-semibold mb-2">Payments</h3>
            <p>Map the Payment details of the related vendor.</p>
          </div>
        )}

        {activeTab === "invoiceTrack" && (
          <div>
            <h3 className="text-lg font-semibold mb-4">Invoice Track</h3>
            <div className="overflow-x-auto">
              <table className="min-w-full border border-gray-200 text-sm">
                <thead className="bg-gray-100">
                  <tr>
                    <th className="p-3 border">Project Code</th>
                    <th className="p-3 border">Division</th>
                    <th className="p-3 border">Invoice No</th>
                    <th className="p-3 border">Date Of Invoice</th>
                    <th className="p-3 border">Amount</th>
                    <th className="p-3 border">Uploaded Date</th>
                    <th className="p-3 border">Document</th>
                    <th className="p-3 border">Payment Status</th>
                    <th className="p-3 border">Payment Request</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="hover:bg-gray-50">
                    <td className="p-3 border">PRJ-001</td>
                    <td className="p-3 border">North</td>
                    <td className="p-3 border">INV-1203</td>
                    <td className="p-3 border">12/10/2025</td>
                    <td className="p-3 border">₹45,000</td>
                    <td className="p-3 border">13/10/2025</td>
                    <td className="p-3 border text-blue-600 underline cursor-pointer">View</td>
                    <td className="p-3 border text-yellow-600 font-medium">Pending</td>
                    <td className="p-3 border">
                      <button className="bg-blue-500 hover:bg-blue-600 text-white px-3 py-1 rounded text-xs">
                        Request Payment
                      </button>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === "tds" && (
          <div>
            <h3 className="text-lg font-semibold mb-2">TDS</h3>
            <p>Track and verify TDS deduction and status for vendors.</p>
          </div>
        )}

        {activeTab === "gstTrack" && (
          <div>
            <h3 className="text-lg font-semibold mb-2">GST Track</h3>
            <p>Track as per the division sheet attached for data reference.</p>
          </div>
        )}
      </div>
    </div>
  );
}