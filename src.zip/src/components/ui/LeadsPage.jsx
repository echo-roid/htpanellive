  import React, { useState, useEffect } from "react";
  import { MoreVertical, Pencil, Trash2, GripVertical, Calendar, CheckCircle, Clock, AlertCircle, Plus } from "lucide-react";
  import axios from "axios";
  import * as api from "../../api/services";
  import * as apiCo from "../../api/Companie";
  import { Link } from "react-router-dom";
  import bookImage  from "../../assets/book.png"

  const API_URL = "http://localhost:5000/api/leads";
  const EMPLOYEE_API_URL = "http://localhost:5000/api/employees";
  const COMPANY_API_URL = "http://localhost:5000/api/contacts";
  const CLIENT_API_URL = "http://localhost:5000/api/companies";

  // LeadFormDrawer component
  const LeadFormDrawer = ({
    isOpen,
    onClose,
    addNewLead,
    updateLead,
    leadToEdit
  }) => {
    const isEditMode = Boolean(leadToEdit);

    const [formData, setFormData] = useState({
      dateOfRfqReceive: "",
      clientName: "",
      clientCode: "",
      salesPerson: "",
      clientCoordinator: "",
      destination: "",
      paxCount: "",
      travelingStartDate: "",
      travelingEndDate: "",
      modeOfBidding: "",
      leadType: "",
      domesticInternational: "",
      rfqStatus: "New",
      uploadDocuments: [],
    });

    const [files, setFiles] = useState([]);
    const [existingFiles, setExistingFiles] = useState([]);
    const [filesToRemove, setFilesToRemove] = useState([]);

    const [employees, setEmployees] = useState([]);
    const [filteredEmployees, setFilteredEmployees] = useState([]);
    const [showEmployeeDropdown, setShowEmployeeDropdown] = useState(false);
    const [employeeSearch, setEmployeeSearch] = useState("");

    const [companies, setCompanies] = useState([]);
    const [filteredCompanies, setFilteredCompanies] = useState([]);
    const [showCompanyDropdown, setShowCompanyDropdown] = useState(false);
    const [companySearch, setCompanySearch] = useState("");
    const [loadingCompanies, setLoadingCompanies] = useState(false);
    const [companyError, setCompanyError] = useState(null);

    const [clients, setClients] = useState([]);
    const [filteredClients, setFilteredClients] = useState([]);
    const [showClientDropdown, setShowClientDropdown] = useState(false);
    const [clientSearch, setClientSearch] = useState("");

    const [divisions, setDivisions] = useState([]);
    const [filteredDivisions, setFilteredDivisions] = useState([]);
    const [showDivisionDropdown, setShowDivisionDropdown] = useState(false);
    const [clientCodeSearch, setClientCodeSearch] = useState("");

    const leadTypeOptions = ["Corporate", "Individual", "Group", "Other"];
    const modeOfBiddingOptions = ["Email", "Portal", "Direct", "Other"];
    const domesticInternationalOptions = ["Domestic", "International"];

    useEffect(() => {
      const fetchEmployees = async () => {
        try {
          const response = await fetch(EMPLOYEE_API_URL);
          if (!response.ok) {
            throw new Error('Failed to fetch employees');
          }
          const data = await response.json();
          setEmployees(data);
          setFilteredEmployees(data);
        } catch (err) {
          console.error('Error fetching employees:', err);
        }
      };
      
      const fetchCompanies = async () => {
        setLoadingCompanies(true);
        setCompanyError(null);
        try {
          const response = await fetch(COMPANY_API_URL);

          if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
          }

          const result = await response.json();
          const apicompanyDataMap = result?.data?.contacts?.map((contact) => {
            return contact?.companies;
          });

          const uniqueCompanies = [...new Set(apicompanyDataMap.filter(Boolean))];
          setCompanies(uniqueCompanies);
          setFilteredCompanies(uniqueCompanies);
        } catch (err) {
          console.error('Error fetching companies:', err);
          setCompanyError(err.message);
          setCompanies([]);
          setFilteredCompanies([]);
        } finally {
          setLoadingCompanies(false);
        }
      };
      
      const fetchClients = async () => {
        try {
          const response = await fetch(CLIENT_API_URL);

          if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
          }

          const result = await response.json();
          const clientNames = result?.data?.companies?.map(client => ({
            name: client.name,
            code: client.client_code || ""
          }));

          setClients(clientNames);
          setFilteredClients(clientNames);
        } catch (err) {
          console.error('Error fetching clients:', err);
          setClients([]);
          setFilteredClients([]);
        }
      };

      fetchEmployees();
      fetchCompanies();
      fetchClients();
    }, []);

    useEffect(() => {
      if (isEditMode && leadToEdit) {
        let travelingStartDate = "";
        let travelingEndDate = "";
        
        if (leadToEdit.travelingDate && leadToEdit.travelingDate.includes("/")) {
          const dates = leadToEdit.travelingDate.split("/");
          
          if (dates[0]) {
            const [day, month, year] = dates[0].split("-");
            travelingStartDate = `${year}-${month}-${day}`;
          }
          
          if (dates[1]) {
            const [day, month, year] = dates[1].split("-");
            travelingEndDate = `${year}-${month}-${day}`;
          }
        } else if (leadToEdit.travelingDate) {
          const [day, month, year] = leadToEdit.travelingDate.split("-");
          travelingStartDate = `${year}-${month}-${day}`;
        }
        
        setFormData({
          dateOfRfqReceive: leadToEdit.dateOfRfqReceive || "",
          clientName: leadToEdit.clientName || "",
          clientCode: leadToEdit.clientCode || "",
          salesPerson: leadToEdit.salesPerson || "",
          clientCoordinator: leadToEdit.clientCoordinator || "",
          destination: leadToEdit.destination || "",
          paxCount: leadToEdit.paxCount || "",
          travelingStartDate: travelingStartDate,
          travelingEndDate: travelingEndDate,
          modeOfBidding: leadToEdit.modeOfBidding || "",
          leadType: leadToEdit.leadType || "",
          domesticInternational: leadToEdit.domesticInternational || "",
          rfqStatus: leadToEdit.rfqStatus || "New",
        });
        
        setEmployeeSearch(leadToEdit.salesPerson || "");
        setCompanySearch(leadToEdit.clientCoordinator || "");
        setClientSearch(leadToEdit.clientName || "");
        setClientCodeSearch(leadToEdit.clientCode || "");
        
        if (leadToEdit.uploadDocuments) {
          setExistingFiles(leadToEdit.uploadDocuments);
        }
        
        // Fetch divisions for the client if client code exists
        if (leadToEdit.clientCode) {
          fetchDivisions(leadToEdit.clientCode);
        }
      } else {
        setFormData({
          dateOfRfqReceive: "",
          clientName: "",
          clientCode: "",
          salesPerson: "",
          clientCoordinator: "",
          destination: "",
          paxCount: "",
          travelingStartDate: "",
          travelingEndDate: "",
          modeOfBidding: "",
          leadType: "",
          domesticInternational: "",
          rfqStatus: "New",
        });
        setEmployeeSearch("");
        setCompanySearch("");
        setClientSearch("");
        setClientCodeSearch("");
        setExistingFiles([]);
        setFiles([]);
        setFilesToRemove([]);
        setDivisions([]);
        setFilteredDivisions([]);
      }
    }, [leadToEdit, isEditMode]);

    useEffect(() => {
      if (employeeSearch) {
        const filtered = employees.filter(employee =>
          employee.name.toLowerCase().includes(employeeSearch.toLowerCase())
        );
        setFilteredEmployees(filtered);
      } else {
        setFilteredEmployees(employees);
      }
    }, [employeeSearch, employees]);

    useEffect(() => {
      if (companySearch) {
        const filtered = companies.filter(company =>
          company.toLowerCase().includes(companySearch.toLowerCase())
        );
        setFilteredCompanies(filtered);
      } else {
        setFilteredCompanies(companies);
      }
    }, [companySearch, companies]);

    useEffect(() => {
      if (clientSearch) {
        const filtered = clients.filter(client =>
          client.name.toLowerCase().includes(clientSearch.toLowerCase())
        );
        setFilteredClients(filtered);
      } else {
        setFilteredClients(clients);
      }
    }, [clientSearch, clients]);

    useEffect(() => {
      if (clientCodeSearch) {
        const filtered = divisions.filter(division =>
          division.subDivisionCode.toLowerCase().includes(clientCodeSearch.toLowerCase())
        );
        setFilteredDivisions(filtered);
      } else {
        setFilteredDivisions(divisions);
      }
    }, [clientCodeSearch, divisions]);

    const handleChange = (e) => {
      const { name, value } = e.target;
      setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleFileChange = (e) => {
      setFiles(Array.from(e.target.files));
    };

    const handleRemoveFile = (index) => {
      const fileToRemove = existingFiles[index];
      setFilesToRemove(prev => [...prev, fileToRemove]);
      setExistingFiles(prev => prev.filter((_, i) => i !== index));
    };

    const handleEmployeeSelect = (employee) => {
      setFormData(prev => ({ ...prev, salesPerson: employee.name }));
      setEmployeeSearch(employee.name);
      setShowEmployeeDropdown(false);
    };

    const handleEmployeeSearchChange = (e) => {
      setEmployeeSearch(e.target.value);
      setFormData(prev => ({ ...prev, salesPerson: e.target.value }));
      setShowEmployeeDropdown(true);
    };

    const handleCompanySelect = (company) => {
      setFormData(prev => ({ ...prev, clientCoordinator: company }));
      setCompanySearch(company);
      setShowCompanyDropdown(false);
    };

    const handleCompanySearchChange = (e) => {
      setCompanySearch(e.target.value);
      setFormData(prev => ({ ...prev, clientCoordinator: e.target.value }));
      setShowCompanyDropdown(true);
    };

    const handleClientSelect = async (client) => {
      setFormData(prev => ({ 
        ...prev, 
        clientName: client.name,
        clientCode: client.code || ""
      }));
      setClientSearch(client.name);
      setClientCodeSearch(client.code || "");
      setShowClientDropdown(false);
      
      // Fetch divisions for the selected client
      if (client.code) {
        await fetchDivisions(client.code);
      } else {
        setDivisions([]);
        setFilteredDivisions([]);
      }
    };

    const handleClientSearchChange = (e) => {
      setClientSearch(e.target.value);
      setFormData(prev => ({ ...prev, clientName: e.target.value }));
      setShowClientDropdown(true);
    };

    const handleDivisionSelect = (division) => {
      setFormData(prev => ({ ...prev, clientCode: division.subDivisionCode }));
      setClientCodeSearch(division.subDivisionCode);
      setShowDivisionDropdown(false);
    };

    const handleClientCodeSearchChange = (e) => {
      setClientCodeSearch(e.target.value);
      setFormData(prev => ({ ...prev, clientCode: e.target.value }));
      setShowDivisionDropdown(true);
    };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Validate that end date is not before start date
    if (formData.travelingEndDate && formData.travelingStartDate && 
        new Date(formData.travelingEndDate) < new Date(formData.travelingStartDate)) {
      alert("End date cannot be before start date");
      return;
    }
    
    try {
      const formDataToSend = new FormData();
      
      Object.entries(formData).forEach(([key, value]) => {
        if (key !== "travelingStartDate" && key !== "travelingEndDate") {
          formDataToSend.append(key, value);
        }
      });
      
      const travelingDate = formData.travelingEndDate 
        ? `${formatDateForDisplay(formData.travelingStartDate)}/${formatDateForDisplay(formData.travelingEndDate)}`
        : formatDateForDisplay(formData.travelingStartDate);
      
      formDataToSend.append('travelingDate', travelingDate);
      
      if (formData.travelingStartDate && formData.travelingEndDate) {
        const startDate = new Date(formData.travelingStartDate);
        const endDate = new Date(formData.travelingEndDate);
        const timeDiff = Math.abs(endDate.getTime() - startDate.getTime());
        const dayCount = Math.ceil(timeDiff / (1000 * 3600 * 24)) + 1;
        const nightCount = dayCount - 1;
        
        formDataToSend.append('dayCount', dayCount);
        formDataToSend.append('nightCount', nightCount);
      }
      
      files.forEach(file => {
        formDataToSend.append('files', file);
      });

      if (isEditMode) {
        filesToRemove.forEach(file => {
          formDataToSend.append('filesToRemove', file);
        });
      }

      let response;
      
      if (isEditMode) {
        response = await axios.put(
          `${API_URL}/${leadToEdit.id}`,
          formDataToSend,
          {
            headers: {
              "Content-Type": "multipart/form-data"
            }
          }
        );
        updateLead(response.data);
      } else {
        response = await axios.post(API_URL, formDataToSend, {
          headers: {
            "Content-Type": "multipart/form-data"
          }
        });
        addNewLead(response.data);
      }
      
      onClose();
      
      setFormData({
        dateOfRfqReceive: "",
        clientName: "",
        clientCode: "",
        salesPerson: "",
        clientCoordinator: "",
        destination: "",
        paxCount: "",
        travelingStartDate: "",
        travelingEndDate: "",
        modeOfBidding: "",
        leadType: "",
        domesticInternational: "",
        rfqStatus: "New",
      });
      setEmployeeSearch("");
      setCompanySearch("");
      setClientSearch("");
      setClientCodeSearch("");
      setFiles([]);
      setExistingFiles([]);
      setFilesToRemove([]);
      setDivisions([]);
      setFilteredDivisions([]);
    } catch (error) {
      console.error("Error saving lead:", error);
      alert(`Failed to ${isEditMode ? 'update' : 'create'} lead. Please try again.`);
    }
  };

    const formatDateForDisplay = (dateString) => {
      if (!dateString) return "";
      
      const date = new Date(dateString);
      const day = String(date.getDate()).padStart(2, '0');
      const month = String(date.getMonth() + 1).padStart(2, '0');
      const year = date.getFullYear();
      
      return `${day}-${month}-${year}`;
    };

    async function createEmptyContact(val) {
      console.log(val)
      const obj = {
        name: val,
        phone: "NA",
        email: "NA",
        additionalNumber: "NA",
        companies: ["NA"],
        status: "Active"
      };

      await api.createContact(obj);
    }

    async function createEmptyCompanies(val) {
      const obj = {
        clientName: val,
      email:  "-",
      panNumber:  "-",
      address:  "-",
      pinCode:  "-",
      state:  "",
      clientType: "Individual",
      contactPerson: "-",
      contactNumber: "-",
      // Company-specific fields (initially empty)
      cinNumber:  "-",
      website:  "-",
      industryType:  "-",
      businessType: "-",
      contracts:  "-",
      relationManager:  "-",
      client_code: "-",
      status: "Active"
      };

      await apiCo.createCompany(obj);
    }

    const fetchDivisions = async (parentClientCode) => {
      try {
        const res = await axios.get(
          `http://localhost:5000/api/divisions/${parentClientCode}`
        );

        if (res.data.success) {
          setDivisions(res.data.data);
          setFilteredDivisions(res.data.data);
        } else {
          setDivisions([]);
          setFilteredDivisions([]);
        }
      } catch (err) {
        console.error("Error fetching divisions:", err);
        setDivisions([]);
        setFilteredDivisions([]);
      }
    };

    return (
      <div
        className={`fixed inset-0 z-50 transition-transform duration-300 ease-in-out ${isOpen ? "translate-x-0" : "translate-x-full"
          }`}
      >
        <div
          className="absolute inset-0 bg-black bg-opacity-40"
          onClick={onClose}
        />
        <div className="absolute right-0 top-0 h-full w-full max-w-3xl bg-white p-6 overflow-y-auto shadow-xl">
          <div className="flex justify-between items-center border-b pb-3">
            <h2 className="text-xl font-semibold">
              {isEditMode ? "Edit Lead" : "Add New Lead"}
            </h2>
            <button onClick={onClose} className="text-gray-600 hover:text-black text-2xl">
              &times;
            </button>
          </div>

          <form className="mt-4 space-y-5" onSubmit={handleSubmit}>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block font-medium">Date Of RFQ Receive</label>
                <input
                  type="date"
                  name="dateOfRfqReceive"
                  value={formData.dateOfRfqReceive}
                  onChange={handleChange}
                  className="w-full border rounded px-3 py-2 mt-1"
                  required
                />
              </div>
              <div>
                <label className="block font-medium">Client Name</label>
                <div className="relative">
                  <input
                    type="text"
                    value={clientSearch}
                    onChange={handleClientSearchChange}
                    onFocus={() => setShowClientDropdown(true)}
                    className="w-full border rounded px-3 py-2 mt-1"
                    required
                    placeholder="Search or select client"
                  />
                  {showClientDropdown && (
                    <div className="absolute z-10 w-full mt-1 bg-white border rounded-md shadow-lg max-h-60 overflow-auto">
                      {filteredClients.length > 0 ? (
                        filteredClients.map((client, index) => (
                          <div
                            key={index}
                            className="px-4 py-2 cursor-pointer hover:bg-gray-100"
                            onClick={() => handleClientSelect(client)}
                          >
                            {client.name}
                          </div>
                        ))
                      ) : clientSearch ? (
                        <div
                          className="px-4 py-2 cursor-pointer hover:bg-gray-100 bg-blue-50"
                          onClick={() => {
                            handleClientSelect({name: clientSearch, code: ""});
                            createEmptyCompanies(clientSearch);
                          }}
                        >
                          + Add "{clientSearch}"
                        </div>
                      ) : (
                        <div className="px-4 py-2 text-gray-500">No clients found</div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block font-medium">Client Code</label>
                <div className="relative">
                  <input
                    type="text"
                    value={clientCodeSearch}
                    onChange={handleClientCodeSearchChange}
                    onFocus={() => setShowDivisionDropdown(true)}
                    className="w-full border rounded px-3 py-2 mt-1"
                    placeholder="Enter or select client code"
                  />
                  {showDivisionDropdown && (
                    <div className="absolute z-10 w-full mt-1 bg-white border rounded-md shadow-lg max-h-60 overflow-auto">
                      {filteredDivisions.length > 0 ? (
                        filteredDivisions.map((division, index) => (
                          <div
                            key={index}
                            className="px-4 py-2 cursor-pointer hover:bg-gray-100"
                            onClick={() => handleDivisionSelect(division)}
                          >
                            {division.subDivisionCode}
                          </div>
                        ))
                      ) : (
                        <div
                          className="px-4 py-2 cursor-pointer hover:bg-gray-100"
                          onClick={() => {
                            setFormData(prev => ({ ...prev, clientCode: formData.clientCode }));
                            setClientCodeSearch(formData.clientCode);
                            setShowDivisionDropdown(false);
                          }}
                        >
                          {formData.clientCode || "No division codes available"}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
              <div>
                <label className="block font-medium">Sales Person</label>
                <div className="relative">
                  <input
                    type="text"
                    value={employeeSearch}
                    onChange={handleEmployeeSearchChange}
                    onFocus={() => setShowEmployeeDropdown(true)}
                    className="w-full border rounded px-3 py-2 mt-1"
                    required
                    placeholder="Search or select sales person"
                  />
                  {showEmployeeDropdown && (
                    <div className="absolute z-10 w-full mt-1 bg-white border rounded-md shadow-lg max-h-60 overflow-auto">
                      {filteredEmployees.length > 0 ? (
                        filteredEmployees.map(employee => (
                          <div
                            key={employee.id}
                            className="px-4 py-2 cursor-pointer hover:bg-gray-100 flex items-center"
                            onClick={() => handleEmployeeSelect(employee)}
                          >
                            {employee.photo && (
                              <img
                                src={employee.photo}
                                alt={employee.name}
                                className="w-8 h-8 rounded-full mr-3 object-cover"
                              />
                            )}
                            <div>
                              <div className="font-medium">{employee.name}</div>
                              {employee.position && (
                                <div className="text-xs text-gray-500">{employee.position}</div>
                              )}
                            </div>
                          </div>
                        ))
                      ) : employeeSearch ? (
                        <div
                          className="px-4 py-2 cursor-pointer hover:bg-gray-100 bg-blue-50"
                          onClick={() => {
                            setFormData(prev => ({ ...prev, salesPerson: employeeSearch }));
                            setEmployeeSearch(employeeSearch);
                            setShowEmployeeDropdown(false);
                          }}
                        >
                          + Add "{employeeSearch}"
                        </div>
                      ) : (
                        <div className="px-4 py-2 text-gray-500">No employees found</div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block font-medium">Client Coordinator</label>
                <div className="relative">
                  <input
                    type="text"
                    value={companySearch}
                    onChange={handleCompanySearchChange}
                    onFocus={() => setShowCompanyDropdown(true)}
                    className="w-full border rounded px-3 py-2 mt-1"
                    required
                    placeholder="Search or select client coordinator"
                  />
                  {showCompanyDropdown && (
                    <div className="absolute z-10 w-full mt-1 bg-white border rounded-md shadow-lg max-h-60 overflow-auto">
                      {filteredCompanies.length > 0 ? (
                        filteredCompanies.map((company, index) => (
                          <div
                            key={index}
                            className="px-4 py-2 cursor-pointer hover:bg-gray-100"
                            onClick={() => handleCompanySelect(company)}
                          >
                            {company}
                          </div>
                        ))
                      ) : companySearch ? (
                        <div
                          className="px-4 py-2 cursor-pointer hover:bg-gray-100 bg-blue-50"
                          onClick={() => {
                            handleCompanySelect(companySearch);
                            createEmptyContact(companySearch);
                          }}
                        >
                          + Add "{companySearch}"
                        </div>
                      ) : (
                        <div className="px-4 py-2 text-gray-500">No companies found</div>
                      )}
                    </div>
                  )}
                </div>
              </div>
              <div>
                <label className="block font-medium">Destination</label>
                <input
                  type="text"
                  name="destination"
                  value={formData.destination}
                  onChange={handleChange}
                  className="w-full border rounded px-3 py-2 mt-1"
                  required
                />
              </div>
            </div>

        <div className="grid grid-cols-2 gap-4">
    <div>
      <label className="block font-medium">Project Size</label>
      <input
        type="number"
        name="paxCount"
        value={formData.paxCount}
        onChange={handleChange}
        className="w-full border rounded px-3 py-2 mt-1"
        required
        min="1"
      />
    </div>
    <div>
      <label className="block font-medium">Project Duration</label>
      <div className="grid grid-cols-2 gap-4 mt-1">
        <div>
          <label className="block text-sm text-gray-500 mb-1">Start Date</label>
          <input
            type="date"
            name="travelingStartDate"
            value={formData.travelingStartDate}
            onChange={handleChange}
            className="w-full border rounded px-3 py-2"
            required
          />
        </div>
        <div>
          <label className="block text-sm text-gray-500 mb-1">End Date</label>
          <input
            type="date"
            name="travelingEndDate"
            value={formData.travelingEndDate}
            onChange={handleChange}
            className={`w-full border rounded px-3 py-2 ${
              formData.travelingEndDate && formData.travelingStartDate && 
              new Date(formData.travelingEndDate) < new Date(formData.travelingStartDate) 
                ? 'border-red-500' 
                : ''
            }`}
            min={formData.travelingStartDate || ''}
          />
        </div>
      </div>
      {formData.travelingEndDate && formData.travelingStartDate && 
      new Date(formData.travelingEndDate) < new Date(formData.travelingStartDate) && (
        <div className="mt-2 text-sm text-red-600">
          End date cannot be before start date
        </div>
      )}
      {formData.travelingStartDate && formData.travelingEndDate && 
      new Date(formData.travelingEndDate) >= new Date(formData.travelingStartDate) && (
        <div className="mt-2 text-sm text-gray-600">
          {(() => {
            const startDate = new Date(formData.travelingStartDate);
            const endDate = new Date(formData.travelingEndDate);
            const timeDiff = Math.abs(endDate.getTime() - startDate.getTime());
            const dayCount = Math.ceil(timeDiff / (1000 * 3600 * 24)) + 1;
            const nightCount = dayCount - 1;
            
            return `${nightCount} Nights / ${dayCount} Days`;
          })()}
        </div>
      )}
    </div>
  </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block font-medium">Mode of Bidding</label>
                <select
                  name="modeOfBidding"
                  value={formData.modeOfBidding}
                  onChange={handleChange}
                  className="w-full border rounded px-3 py-2 mt-1"
                  required
                >
                  <option value="">Select</option>
                  {modeOfBiddingOptions.map(option => (
                    <option key={option} value={option}>{option}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block font-medium">Lead Type</label>
                <select
                  name="leadType"
                  value={formData.leadType}
                  onChange={handleChange}
                  className="w-full border rounded px-3 py-2 mt-1"
                  required
                >
                  <option value="">Select</option>
                  {leadTypeOptions.map(option => (
                    <option key={option} value={option}>{option}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Domestic/International Field */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block font-medium">Domestic/International</label>
                <select
                  name="domesticInternational"
                  value={formData.domesticInternational}
                  onChange={handleChange}
                  className="w-full border rounded px-3 py-2 mt-1"
                  required
                >
                  <option value="">Select</option>
                  {domesticInternationalOptions.map(option => (
                    <option key={option} value={option}>{option}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block font-medium">RFQ Status</label>
                <input
                  type="text"
                  name="rfqStatus"
                  value={formData.rfqStatus}
                  className="w-full border rounded px-3 py-2 mt-1 bg-gray-100"
                  readOnly
                />
              </div>
            </div>

            <div>
              <label className="block font-medium">Documents Upload</label>
              <input
                type="file"
                className="w-full border rounded px-3 py-2 mt-1"
                multiple
                onChange={handleFileChange}
              />
              {files.length > 0 && (
                <div className="mt-2 text-sm">
                  {files.length} new file(s) selected
                </div>
              )}
            </div>

            {isEditMode && existingFiles.length > 0 && (
              <div>
                <label className="block font-medium">Existing Documents</label>
                <div className="border rounded p-2 mt-1">
                  {existingFiles.map((file, index) => (
                    <div key={index} className="flex justify-between items-center py-1">
                      <a
                        href={file}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-blue-600 hover:underline"
                      >
                        Document {index + 1}
                      </a>
                      <button
                        type="button"
                        onClick={() => handleRemoveFile(index)}
                        className="text-red-600 hover:text-red-800"
                      >
                        Remove
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="flex justify-end space-x-3 pt-4 border-t mt-6">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700"
              >
                {isEditMode ? "Update Lead" : "Create Lead"}
              </button>
            </div>
          </form>
        </div>
      </div>
    );
  };

  // Task Management Component
  const TaskManagementDrawer = ({
    isOpen,
    onClose,
    selectedLead,
    tasks,
    setTasks,
    taskFormData,
    setTaskFormData,
    editingTaskId,
    setEditingTaskId
  }) => {
    const handleTaskSubmit = (e) => {
      e.preventDefault();
      
      const taskData = {
        ...taskFormData,
        leadId: selectedLead.id,
        leadName: selectedLead.clientName
      };

      if (editingTaskId) {
        // Update existing task
        setTasks(tasks.map(task => 
          task.id === editingTaskId 
            ? { ...task, ...taskData, id: editingTaskId, updatedAt: new Date().toISOString() }
            : task
        ));
      } else {
        // Add new task
        const newTask = {
          ...taskData,
          id: Date.now(),
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        };
        setTasks([...tasks, newTask]);
      }

      resetTaskForm();
    };

    const handleEditTask = (task) => {
      setTaskFormData({
        title: task.title,
        description: task.description,
        dueDate: task.dueDate,
        priority: task.priority,
        status: task.status,
        assignedTo: task.assignedTo
      });
      setEditingTaskId(task.id);
    };

    const handleDeleteTask = (taskId) => {
      if (window.confirm("Are you sure you want to delete this task?")) {
        setTasks(tasks.filter(task => task.id !== taskId));
      }
    };

    const resetTaskForm = () => {
      setTaskFormData({
        title: "",
        description: "",
        dueDate: "",
        priority: "Medium",
        status: "Pending",
        assignedTo: ""
      });
      setEditingTaskId(null);
    };

    const handleTaskInputChange = (e) => {
      const { name, value } = e.target;
      setTaskFormData(prev => ({ ...prev, [name]: value }));
    };

    const getPriorityColor = (priority) => {
      switch (priority) {
        case "High": return "bg-red-100 text-red-800 border border-red-200";
        case "Medium": return "bg-yellow-100 text-yellow-800 border border-yellow-200";
        case "Low": return "bg-green-100 text-green-800 border border-green-200";
        default: return "bg-gray-100 text-gray-800 border border-gray-200";
      }
    };

    const getStatusIcon = (status) => {
      switch (status) {
        case "Completed": return <CheckCircle size={16} className="text-green-500" />;
        case "In Progress": return <Clock size={16} className="text-blue-500" />;
        case "Pending": return <AlertCircle size={16} className="text-orange-500" />;
        default: return <Clock size={16} className="text-gray-500" />;
      }
    };

    const getStatusColor = (status) => {
      switch (status) {
        case "Completed": return "bg-green-50 text-green-700 border border-green-200";
        case "In Progress": return "bg-blue-50 text-blue-700 border border-blue-200";
        case "Pending": return "bg-orange-50 text-orange-700 border border-orange-200";
        default: return "bg-gray-50 text-gray-700 border border-gray-200";
      }
    };

    if (!isOpen || !selectedLead) return null;

    return (
      <div className="fixed inset-0 z-50 bg-black bg-opacity-40 flex justify-end">
        <div className="bg-white h-full w-full max-w-4xl p-6 overflow-y-auto shadow-xl">
          <div className="flex justify-between items-center border-b pb-3">
            <div>
              <h2 className="text-xl font-semibold">Task Management</h2>
              <p className="text-gray-600">Lead: {selectedLead.clientName}</p>
            </div>
            <button 
              onClick={() => {
                onClose();
                resetTaskForm();
              }} 
              className="text-gray-600 hover:text-black text-2xl"
            >
              &times;
            </button>
          </div>

          {/* Add/Edit Task Form */}
          <div className="mt-6 bg-gray-50 p-4 rounded-lg border">
            <h3 className="text-lg font-medium mb-4">
              {editingTaskId ? "Edit Task" : "Add New Task"}
            </h3>
            <form onSubmit={handleTaskSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block font-medium">Task Title *</label>
                  <input
                    type="text"
                    name="title"
                    className="w-full border rounded px-3 py-2 mt-1"
                    value={taskFormData.title}
                    onChange={handleTaskInputChange}
                    required
                  />
                </div>
                <div>
                  <label className="block font-medium">Due Date</label>
                  <input
                    type="date"
                    name="dueDate"
                    className="w-full border rounded px-3 py-2 mt-1"
                    value={taskFormData.dueDate}
                    onChange={handleTaskInputChange}
                  />
                </div>
              </div>

              <div>
                <label className="block font-medium">Description</label>
                <textarea
                  name="description"
                  className="w-full border rounded px-3 py-2 mt-1"
                  rows="3"
                  value={taskFormData.description}
                  onChange={handleTaskInputChange}
                  placeholder="Enter task description..."
                />
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="block font-medium">Priority</label>
                  <select
                    name="priority"
                    className="w-full border rounded px-3 py-2 mt-1"
                    value={taskFormData.priority}
                    onChange={handleTaskInputChange}
                  >
                    <option value="Low">Low</option>
                    <option value="Medium">Medium</option>
                    <option value="High">High</option>
                  </select>
                </div>
                <div>
                  <label className="block font-medium">Status</label>
                  <select
                    name="status"
                    className="w-full border rounded px-3 py-2 mt-1"
                    value={taskFormData.status}
                    onChange={handleTaskInputChange}
                  >
                    <option value="Pending">Pending</option>
                    <option value="In Progress">In Progress</option>
                    <option value="Completed">Completed</option>
                  </select>
                </div>
                <div>
                  <label className="block font-medium">Assigned To</label>
                  <input
                    type="text"
                    name="assignedTo"
                    className="w-full border rounded px-3 py-2 mt-1"
                    value={taskFormData.assignedTo}
                    onChange={handleTaskInputChange}
                    placeholder="Assign to..."
                  />
                </div>
              </div>

              <div className="flex justify-end space-x-3 pt-2">
                {editingTaskId && (
                  <button
                    type="button"
                    onClick={resetTaskForm}
                    className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
                  >
                    Cancel Edit
                  </button>
                )}
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 flex items-center gap-2"
                >
                  <Plus size={16} />
                  {editingTaskId ? "Update Task" : "Add Task"}
                </button>
              </div>
            </form>
          </div>

          {/* Tasks List */}
          <div className="mt-8">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium">Tasks ({tasks.length})</h3>
              <div className="flex gap-2">
                <span className="text-sm text-gray-500">
                  {tasks.filter(t => t.status === 'Completed').length} completed
                </span>
                <span className="text-sm text-gray-500">•</span>
                <span className="text-sm text-gray-500">
                  {tasks.filter(t => t.status === 'Pending').length} pending
                </span>
              </div>
            </div>
            
            {tasks.length > 0 ? (
              <div className="space-y-4">
                {tasks.map((task) => (
                  <div key={task.id} className="border rounded-lg p-4 hover:shadow-md transition-shadow bg-white">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h4 className="font-semibold text-lg">{task.title}</h4>
                          <span className={`px-2 py-1 rounded text-xs font-medium ${getPriorityColor(task.priority)}`}>
                            {task.priority}
                          </span>
                          <span className={`px-2 py-1 rounded text-xs font-medium ${getStatusColor(task.status)} flex items-center gap-1`}>
                            {getStatusIcon(task.status)}
                            {task.status}
                          </span>
                        </div>
                        
                        <p className="text-gray-600 mb-3">{task.description}</p>
                        
                        <div className="flex items-center gap-4 text-sm text-gray-500">
                          {task.dueDate && (
                            <div className="flex items-center gap-1">
                              <Calendar size={14} />
                              Due: {new Date(task.dueDate).toLocaleDateString()}
                            </div>
                          )}
                          {task.assignedTo && (
                            <div>Assigned to: <span className="font-medium">{task.assignedTo}</span></div>
                          )}
                          <div>Created: {new Date(task.createdAt).toLocaleDateString()}</div>
                        </div>
                      </div>
                      
                      <div className="flex gap-2 ml-4">
                        <button 
                          onClick={() => handleEditTask(task)}
                          className="text-blue-500 hover:text-blue-700 p-1 rounded hover:bg-blue-50"
                          title="Edit Task"
                        >
                          <Pencil size={16} />
                        </button>
                        <button 
                          onClick={() => handleDeleteTask(task.id)}
                          className="text-red-500 hover:text-red-700 p-1 rounded hover:bg-red-50"
                          title="Delete Task"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500 border-2 border-dashed border-gray-300 rounded-lg">
                <Calendar size={48} className="mx-auto mb-4 text-gray-300" />
                <p className="text-lg font-medium">No tasks found</p>
                <p className="text-sm">Add a task to get started with task management</p>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  };

  export default function LeadsPage() {
    const [isDrawerOpen, setIsDrawerOpen] = useState(false);
    const [leadToEdit, setLeadToEdit] = useState(null);
    const [leads, setLeads] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [editingStatusId, setEditingStatusId] = useState(null);
    const [tempRfqStatus, setTempRfqStatus] = useState('');
    
    // Task Management States
    const [isTaskDrawerOpen, setIsTaskDrawerOpen] = useState(false);
    const [selectedLead, setSelectedLead] = useState(null);
    const [tasks, setTasks] = useState([]);
    const [taskFormData, setTaskFormData] = useState({
      title: "",
      description: "",
      dueDate: "",
      priority: "Medium",
      status: "Pending",
      assignedTo: ""
    });
    const [editingTaskId, setEditingTaskId] = useState(null);
    
    // Column management state
    const [columns, setColumns] = useState([
   
      { id: 'dateOfRfqReceive', label: 'Date Of RFQ Receive', visible: true },
      { id: 'clientName', label: 'Client Name', visible: true },
      { id: 'clientCode', label: 'Client Code', visible: true },
      { id: 'salesPerson', label: 'Sales Person', visible: true },
      { id: 'clientCoordinator', label: 'Client Coordinator', visible: true },
      { id: 'destination', label: 'Destination', visible: true },
      { id: 'paxCount', label: 'Project Size', visible: true },
      { id: 'travelingDate', label: 'Project Duration', visible: true },
      { id: 'modeOfBidding', label: 'Mode of Bidding', visible: true },
      { id: 'leadType', label: 'Lead Type', visible: true },
      { id: 'domesticInternational', label: 'Domestic/International', visible: true },
      { id: 'rfqStatus', label: 'RFQ Status', visible: true },
      { id: 'actions', label: 'Action', visible: true }
    ]);
    
    const [isManagingColumns, setIsManagingColumns] = useState(false);
    const [dragItem, setDragItem] = useState(null);
    const [dragOverItem, setDragOverItem] = useState(null);

    useEffect(() => {
      const fetchLeads = async () => {
        try {
          const response = await axios.get(API_URL);
          setLeads(response.data);
          setLoading(false);
        } catch (err) {
          setError("Failed to fetch leads");
          setLoading(false);
          console.error(err);
        }
      };

      fetchLeads();
      
      // Load column preferences from localStorage
      const savedColumns = localStorage.getItem('leadsTableColumns');
      if (savedColumns) {
        setColumns(JSON.parse(savedColumns));
      }
    }, []);

    // Save column preferences to localStorage whenever they change
    useEffect(() => {
      localStorage.setItem('leadsTableColumns', JSON.stringify(columns));
    }, [columns]);

    const addNewLead = (newLead) => {
      setLeads(prevLeads => [newLead, ...prevLeads]);
    };

    const updateLead = (updatedLead) => {
      setLeads(prevLeads =>
        prevLeads.map(lead =>
          lead.id === updatedLead.id ? updatedLead : lead
        )
      );
    };

    const deleteLead = async (id) => {
      try {
        await axios.delete(`${API_URL}/${id}`);
        setLeads(prevLeads => prevLeads.filter(lead => lead.id !== id));
      } catch (err) {
        console.error("Failed to delete lead:", err);
        alert("Failed to delete lead. Please try again.");
      }
    };

    const handleEditClick = (lead) => {
      setLeadToEdit(lead);
      setIsDrawerOpen(true);
    };

    const handleAddClick = () => {
      setLeadToEdit(null);
      setIsDrawerOpen(true);
    };

    const closeDrawer = () => {
      setIsDrawerOpen(false);
      setLeadToEdit(null);
    };

    // Task Management Functions
    const handleOpenTasks = (lead) => {
      setSelectedLead(lead);
      // Fetch tasks for this lead - in a real app, you'd make an API call here
      const mockTasks = [
        {
          id: 1,
          title: "Follow up on RFQ",
          description: "Contact client to discuss RFQ requirements and timeline",
          dueDate: "2024-01-18",
          priority: "High",
          status: "Pending",
          assignedTo: lead.salesPerson,
          createdAt: new Date().toISOString()
        },
        {
          id: 2,
          title: "Prepare proposal document",
          description: "Create detailed proposal based on RFQ requirements",
          dueDate: "2024-01-25",
          priority: "Medium",
          status: "In Progress",
          assignedTo: "Proposal Team",
          createdAt: new Date().toISOString()
        }
      ];
      setTasks(mockTasks);
      setIsTaskDrawerOpen(true);
    };

    const closeTaskDrawer = () => {
      setIsTaskDrawerOpen(false);
      setSelectedLead(null);
      setTaskFormData({
        title: "",
        description: "",
        dueDate: "",
        priority: "Medium",
        status: "Pending",
        assignedTo: ""
      });
      setEditingTaskId(null);
    };

    const handleStatusChange = (e) => {
      setTempRfqStatus(e.target.value);
    };

    const saveStatusChange = async (lead) => {
      try {
        const response = await axios.patch(
          `${API_URL}/${lead.id}/status`,
          { rfqStatus: tempRfqStatus }
        );

        setLeads(prevLeads =>
          prevLeads.map(l => l.id === lead.id ? response.data : l)
        );

        setEditingStatusId(null);
      } catch (err) {
        console.error("Failed to update status:", err);
        alert("Failed to update status. Please try again.");
      }
    };

    // Column management functions
    const toggleColumnVisibility = (columnId) => {
      setColumns(columns.map(column =>
        column.id === columnId ? { ...column, visible: !column.visible } : column
      ));
    };

    const handleDragStart = (e, index) => {
      setDragItem(index);
    };

    const handleDragOver = (e, index) => {
      e.preventDefault();
      setDragOverItem(index);
    };

    const handleDrop = () => {
      if (dragItem === null || dragOverItem === null) return;
      
      const newColumns = [...columns];
      const draggedItem = newColumns[dragItem];
      newColumns.splice(dragItem, 1);
      newColumns.splice(dragOverItem, 0, draggedItem);
      
      setColumns(newColumns);
      setDragItem(null);
      setDragOverItem(null);
    };

    const resetColumns = () => {
      setColumns([
        { id: 'dateOfRfqReceive', label: 'Date Of RFQ Receive', visible: true },
        { id: 'clientName', label: 'Client Name', visible: true },
        { id: 'clientCode', label: 'Client Code', visible: true },
        { id: 'salesPerson', label: 'Sales Person', visible: true },
        { id: 'clientCoordinator', label: 'Client Coordinator', visible: true },
        { id: 'destination', label: 'Destination', visible: true },
        { id: 'paxCount', label: 'Project Size', visible: true },
        { id: 'travelingDate', label: 'Project Duration', visible: true },
        { id: 'modeOfBidding', label: 'Mode of Bidding', visible: true },
        { id: 'leadType', label: 'Lead Type', visible: true },
        { id: 'domesticInternational', label: 'Domestic/International', visible: true },
        { id: 'rfqStatus', label: 'RFQ Status', visible: true },
        { id: 'actions', label: 'Action', visible: true }
      ]);
    };

    if (loading) {
      return <div className="p-4">Loading leads...</div>;
    }

    if (error) {
      return <div className="p-4 text-red-500">{error}</div>;
    }

    return (
      <>
        <div className=" p-4 rounded-md ">
            <div className='flex justify-between align-center'>
                              <h6 className='!font-bold text-[22px] mb-5'>Leads Page</h6>
                              <p className='mb-0 text-[10px] flex gap-1'>
                                  <img src={bookImage} className='mt-0 w-[15px] h-[15px]'/>
                                  Learn More About The Sale
                              </p>
                          </div>
           <div className="flex justify-between items-center mb-1 h-7">
    {/* Search */}
    <input
      type="text"
      placeholder="Search Leads"
      className="border rounded px-2 text-[10px] h-6 w-1/3 leading-none"
    />

    {/* Actions */}
    <div className="flex items-center gap-1">
      <button className="border px-2 text-[10px] h-6 rounded leading-none">
        Sort
      </button>

      <input
        type="text"
        value="06/11/2025 - 06/17/2025"
        className="border px-2 text-[10px] h-6 rounded leading-none"
        readOnly
      />

      <button
        className="bg-purple-100 text-purple-700 px-2 text-[10px] h-6 rounded font-medium leading-none"
        onClick={() => setIsManagingColumns(true)}
      >
        Manage Columns
      </button>

      <button
        className="bg-red-500 text-white px-2 text-[10px] h-6 rounded leading-none"
        onClick={handleAddClick}
      >
        Add Leads
      </button>
    </div>
        </div>

          {/* Column Management Modal */}
          {isManagingColumns && (
            <div className="fixed inset-0 z-50 bg-black bg-opacity-40 flex items-center justify-center">
              <div className="bg-white p-6 rounded-md shadow-xl w-96">
                <h3 className="text-lg font-semibold mb-4">Manage Columns</h3>
                <p className="text-sm text-gray-500 mb-4">Drag to reorder columns or toggle visibility</p>
                
                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {columns.map((column, index) => (
                    <div
                      key={column.id}
                      className={`flex items-center justify-between p-2 border rounded ${
                        dragOverItem === index ? 'bg-blue-50 border-blue-200' : ''
                      }`}
                      draggable
                      onDragStart={(e) => handleDragStart(e, index)}
                      onDragOver={(e) => handleDragOver(e, index)}
                      onDrop={handleDrop}
                    >
                      <div className="flex items-center">
                        <GripVertical size={16} className="text-gray-400 mr-2 cursor-move" />
                        <span>{column.label}</span>
                      </div>
                      <label className="flex items-center cursor-pointer">
                        <div className="relative">
                          <input
                            type="checkbox"
                            checked={column.visible}
                            onChange={() => toggleColumnVisibility(column.id)}
                            className="sr-only"
                          />
                          <div className={`w-10 h-6 rounded-full ${column.visible ? 'bg-blue-500' : 'bg-gray-300'} transition`} />
                          <div className={`absolute top-1 w-4 h-4 rounded-full transition-transform bg-white ${column.visible ? 'transform translate-x-5' : 'translate-x-1'}`} />
                        </div>
                      </label>
                    </div>
                  ))}
                </div>
                
                <div className="flex justify-between mt-6">
                  <button
                    onClick={resetColumns}
                    className="px-4 py-2 border border-gray-300 rounded text-gray-700"
                  >
                    Reset to Default
                  </button>
                  <button
                    onClick={() => setIsManagingColumns(false)}
                    className="px-4 py-2 bg-red-600 text-white rounded"
                  >
                    Done
                  </button>
                </div>
              </div>
            </div>
          )}

      <div className="overflow-x-auto">
      <table className="w-full text-[9px] text-left leading-none border-collapse border">
        {/* HEADER */}
        <thead className="bg-gray-100">
          <tr className="h-6">
            <th
                   
                    className="px-2 py-0.5 whitespace-nowrap font-semibold h-6 align-middle"
                  >
                    SR.NO
                  </th>
            {columns.map(
              (column) =>
                column.visible && (
                  <th
                    key={column.id}
                    className="px-2 py-0.5 whitespace-nowrap font-semibold h-6 align-middle"
                  >
                    {column.label}
                  </th>
                )
            )}
          </tr>
        </thead>

        {/* BODY */}
        <tbody>
          {leads.map((lead,i) => (
            <tr
              key={lead.id}
              className="border-b hover:bg-gray-50 h-6"
            >

              <td className="px-2 py-0.5 whitespace-nowrap align-middle">
                     {i+1}
                </td>
              {columns.find((c) => c.id === "dateOfRfqReceive")?.visible && (
                <td className="px-2 py-0.5 whitespace-nowrap align-middle">
                  <Link
                    to="/InsideLeadPage"
                    className="text-blue-600 hover:underline"
                  >
                    {lead.dateOfRfqReceive}
                  </Link>
                </td>
              )}

              {columns.find((c) => c.id === "clientName")?.visible && (
                <td className="px-2 py-0.5 font-semibold whitespace-nowrap align-middle">
                  {lead.clientName}
                </td>
              )}

              {columns.find((c) => c.id === "clientCode")?.visible && (
                <td className="px-2 py-0.5 whitespace-nowrap align-middle">
                  {lead.clientCode}
                </td>
              )}

              {columns.find((c) => c.id === "salesPerson")?.visible && (
                <td className="px-2 py-0.5 whitespace-nowrap align-middle">
                  {lead.salesPerson}
                </td>
              )}

              {columns.find((c) => c.id === "clientCoordinator")?.visible && (
                <td className="px-2 py-0.5 whitespace-nowrap align-middle">
                  {lead.clientCoordinator}
                </td>
              )}

              {columns.find((c) => c.id === "destination")?.visible && (
                <td className="px-2 py-0.5 whitespace-nowrap align-middle">
                  {lead.destination}
                </td>
              )}

              {columns.find((c) => c.id === "paxCount")?.visible && (
                <td className="px-2 py-0.5 text-center whitespace-nowrap align-middle">
                  {lead.paxCount}
                </td>
              )}

              {columns.find((c) => c.id === "travelingDate")?.visible && (
                <td className="px-2 py-0.5 whitespace-nowrap align-middle">
                  {lead.travelingDate}
                </td>
              )}

              {columns.find((c) => c.id === "modeOfBidding")?.visible && (
                <td className="px-2 py-0.5 whitespace-nowrap align-middle">
                  {lead.modeOfBidding}
                </td>
              )}

              {columns.find((c) => c.id === "leadType")?.visible && (
                <td className="px-2 py-0.5 whitespace-nowrap align-middle">
                  {lead.leadType}
                </td>
              )}

              {columns.find((c) => c.id === "domesticInternational")?.visible && (
                <td className="px-2 py-0.5 whitespace-nowrap align-middle">
                  {lead.domesticInternational}
                </td>
              )}

              {columns.find((c) => c.id === "rfqStatus")?.visible && (
                <td className="px-2 py-0.5 whitespace-nowrap align-middle">
                  {editingStatusId === lead.id ? (
                    <div className="flex items-center gap-1 h-5">
                      <select
                        value={tempRfqStatus}
                        onChange={handleStatusChange}
                        className="border rounded px-1 text-[8px] h-5 leading-none"
                        autoFocus
                      >
                        {["New", "Open", "Closed", "Won", "Lost", "Pending"].map(
                          (s) => (
                            <option key={s} value={s}>
                              {s}
                            </option>
                          )
                        )}
                      </select>

                      <button
                        onClick={() => saveStatusChange(lead)}
                        className="bg-green-500 text-white px-2 text-[8px] h-5 rounded leading-none"
                      >
                        Save
                      </button>
                    </div>
                  ) : (
                    <div className="flex items-center gap-1">
                      <span
                        className={`px-1 py-[1px] rounded text-[8px] leading-none font-semibold text-white ${
                          lead.rfqStatus === "Won"
                            ? "bg-green-500"
                            : lead.rfqStatus === "Lost"
                            ? "bg-red-500"
                            : lead.rfqStatus === "New"
                            ? "bg-blue-500"
                            : "bg-yellow-500"
                        }`}
                      >
                        {lead.rfqStatus}
                      </span>

                      <button
                        onClick={() => {
                          setEditingStatusId(lead.id);
                          setTempRfqStatus(lead.rfqStatus);
                        }}
                        className="text-gray-500 hover:text-gray-700 p-[2px]"
                      >
                        <Pencil size={10} />
                      </button>
                    </div>
                  )}
                </td>
              )}

              {columns.find((c) => c.id === "actions")?.visible && (
                <td className="px-2 py-0.5 whitespace-nowrap align-middle">
                  <div className="flex gap-1">
                    <button
                      onClick={() => handleEditClick(lead)}
                      className="text-blue-600 p-[2px]"
                    >
                      <Pencil size={10} />
                    </button>

                    <button
                      onClick={() => deleteLead(lead.id)}
                      className="text-red-600 p-[2px]"
                    >
                      <Trash2 size={10} />
                    </button>

                    <button
                      onClick={() => handleOpenTasks(lead)}
                      className="text-green-600 p-[2px]"
                    >
                      <Calendar size={10} />
                    </button>

                    <button className="text-gray-600 p-[2px]">
                      <MoreVertical size={10} />
                    </button>
                  </div>
                </td>
              )}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
        </div>

        <LeadFormDrawer
          isOpen={isDrawerOpen}
          onClose={closeDrawer}
          addNewLead={addNewLead}
          updateLead={updateLead}
          leadToEdit={leadToEdit}
        />

        <TaskManagementDrawer
          isOpen={isTaskDrawerOpen}
          onClose={closeTaskDrawer}
          selectedLead={selectedLead}
          tasks={tasks}
          setTasks={setTasks}
          taskFormData={taskFormData}
          setTaskFormData={setTaskFormData}
          editingTaskId={editingTaskId}
          setEditingTaskId={setEditingTaskId}
        />
      </>
    );
  }