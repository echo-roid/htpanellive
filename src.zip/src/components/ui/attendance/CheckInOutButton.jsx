import { useState, useEffect, useRef, useCallback } from 'react';
import axios from 'axios';
import { useSelector } from 'react-redux';

export default function CheckInOutButton() {
  const [isChecking, setIsChecking] = useState(false);
  const [action, setAction] = useState(null);
  const [error, setError] = useState(null);
  const [todayRecord, setTodayRecord] = useState(null);
  const [showWebcam, setShowWebcam] = useState(false);

  const videoRef = useRef(null);
  const canvasRef = useRef(null);

  const user = useSelector((state) => state.auth.user);
  const employeeId = user?.employee?.id;

  // Get today's date in local timezone
  const getTodayDate = () => {
    const now = new Date();
    return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
  };

  // Fetch today's record
  const fetchTodayRecord = useCallback(async () => {
    try {
      const today = getTodayDate();
      const response = await axios.get(`http://localhost:5000/api/attendance?date=${today}`);
      const record = response.data.find(r => r.employee_id === employeeId);
      setTodayRecord(record || null);
    } catch (err) {
      console.error('Attendance fetch error:', err);
      setError('Failed to load attendance data');
    }
  }, [employeeId]);

  // Start webcam only when showWebcam is true
  useEffect(() => {
    let stream = null;
    
    if (showWebcam) {
      const startCamera = async () => {
        try {
          stream = await navigator.mediaDevices.getUserMedia({ video: true });
          if (videoRef.current) videoRef.current.srcObject = stream;
        } catch (err) {
          console.error('Camera error:', err);
          setError('Camera access denied');
        }
      };
      
      startCamera();
    }

    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, [showWebcam]);

  // Initial fetch of today's record
  useEffect(() => {
    fetchTodayRecord();
  }, [fetchTodayRecord]);

  const captureImage = () => {
    return new Promise((resolve) => {
      const canvas = canvasRef.current;
      const video = videoRef.current;
      
      // Create a temporary canvas if not available
      const tempCanvas = canvas || document.createElement('canvas');
      const ctx = tempCanvas.getContext('2d');

      tempCanvas.width = video.videoWidth;
      tempCanvas.height = video.videoHeight;
      ctx.drawImage(video, 0, 0);

      // Stop camera after capturing
      if (video.srcObject) {
        video.srcObject.getTracks().forEach(track => track.stop());
        video.srcObject = null;
      }

      tempCanvas.toBlob(blob => {
        const file = new File([blob], 'photo.jpg', { type: 'image/jpeg' });
        resolve(file);
      }, 'image/jpeg');
    });
  };

  const handleAction = async (type) => {
    try {
      setIsChecking(true);
      setAction(type);
      setError(null);
      
      // Show webcam before capturing
      setShowWebcam(true);
      
      // Wait for webcam to initialize
      await new Promise(resolve => setTimeout(resolve, 500));

      const photoFile = await captureImage();

      const position = await new Promise((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(resolve, reject);
      });

      const formData = new FormData();
      formData.append('employeeId', employeeId);
      formData.append('latitude', position.coords.latitude);
      formData.append('longitude', position.coords.longitude);
      formData.append('photo', photoFile);

      const endpoint =
        type === 'checkin'
          ? 'http://localhost:5000/api/attendance/check-in'
          : 'http://localhost:5000/api/attendance/check-out';

      const response = await axios.post(endpoint, formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });

      // Use the server's response to update the state immediately
      if (type === 'checkin') {
        setTodayRecord({
          ...todayRecord,
          check_in: response.data.check_in,
          photo_in: response.data.photo_in
        });
      } else {
        setTodayRecord({
          ...todayRecord,
          check_out: response.data.check_out,
          photo_out: response.data.photo_out
        });
      }

      alert(`Successfully ${type === 'checkin' ? 'checked in' : 'checked out'}.`);
    } catch (err) {
      console.error(`${type} error:`, err);
      const apiError = err.response?.data?.error;
      setError(
        typeof apiError === 'object'
          ? apiError.message || JSON.stringify(apiError)
          : apiError || `Failed to ${type}`
      );
    } finally {
      setIsChecking(false);
      setAction(null);
      setShowWebcam(false);
      
      // Refetch to ensure data is up-to-date
      fetchTodayRecord();
    }
  };

    console.log(todayRecord?.check_out,"jjjjjj")
  return (
    <div className="mb-6">
      {/* Webcam - Always render but conditionally show */}
      {showWebcam && (
        <>
          <video 
            ref={videoRef} 
            autoPlay 
            muted 
            className="w-64 h-48 border rounded mb-4"
          />
          <canvas 
            ref={canvasRef} 
            style={{ display: 'none' }} 
          />
        </>
      )}

      {/* Check-In */}
      {!todayRecord?.check_in && (
        <button
          onClick={() => handleAction('checkin')}
          disabled={isChecking}
          className="px-6 py-3 rounded-lg font-medium bg-[#3F8CFF] text-white hover:bg-[#2d7ae6] mr-4"
        >
          {isChecking && action === 'checkin' ? 'Checking In...' : 'Check In'}
        </button>
      )}

      {/* Check-Out */}
      {todayRecord?.check_in && !todayRecord?.check_out && (
        <button
          onClick={() => handleAction('checkout')}
          disabled={isChecking}
          className="px-6 py-3 rounded-lg font-medium border border-[#3F8CFF] text-[#3F8CFF] hover:bg-gray-50"
        >
          {isChecking && action === 'checkout' ? 'Checking Out...' : 'Check Out'}
        </button>
      )}

      {/* Already Done */}
      {todayRecord?.check_in && todayRecord?.check_out && (
        <div className="mt-2 text-green-600 font-semibold">
          ✅ You have completed check-in and check-out today.
        </div>
      )}

      {/* Error Message */}
      {error && (
        <div className="mt-2 text-sm text-red-600">
          {typeof error === 'object' ? JSON.stringify(error) : error}
        </div>
      )}
    </div>
  );
}