import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';
import { createWorker } from 'tesseract.js';
import html2canvas from 'html2canvas';

// Helper function to check if a value is empty
const isEmpty = (value) => {
    if (value == null) return true;
    if (typeof value === 'string') return value.trim() === '';
    if (Array.isArray(value)) return value.length === 0;
    if (typeof value === 'object') {
        return Object.values(value).every(val => isEmpty(val));
    }
    return false;
};

// Helper function to evaluate a single condition
const evaluateCondition = (condition, formData) => {
    const fieldValue = formData[condition.field];

    switch (condition.operator) {
        case 'Is Filled':
            return !isEmpty(fieldValue);
        case 'Is Not Filled':
            return isEmpty(fieldValue);
        case 'Equals':
            return fieldValue == condition.value;
        case 'Not Equals':
            return fieldValue != condition.value;
        case 'Greater Than':
            return parseFloat(fieldValue) > parseFloat(condition.value);
        case 'Less Than':
            return parseFloat(fieldValue) < parseFloat(condition.value);
        case 'Contains':
            return typeof fieldValue === 'string' &&
                fieldValue.includes(condition.value);
        case 'Does Not Contain':
            return typeof fieldValue === 'string' &&
                !fieldValue.includes(condition.value);
        default:
            console.warn(`Unknown operator: ${condition.operator}`);
            return false;
    }
};

// Signature Pad Component
const SignaturePad = ({ fieldId, onSave, currentSignature }) => {
    const canvasRef = useRef(null);
    const [isDrawing, setIsDrawing] = useState(false);
    const [prevPos, setPrevPos] = useState({ x: 0, y: 0 });

    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        
        const ctx = canvas.getContext('2d');
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        // Load existing signature if available
        if (currentSignature) {
            const img = new Image();
            img.src = currentSignature;
            img.onload = () => {
                ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
            };
        }
    }, [fieldId, currentSignature]);

    const startDrawing = (e) => {
        const canvas = canvasRef.current;
        const rect = canvas.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;

        setIsDrawing(true);
        setPrevPos({ x, y });

        const ctx = canvas.getContext('2d');
        ctx.beginPath();
        ctx.moveTo(x, y);
    };

    const draw = (e) => {
        if (!isDrawing) return;

        const canvas = canvasRef.current;
        const ctx = canvas.getContext('2d');
        const rect = canvas.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;

        ctx.lineTo(x, y);
        ctx.strokeStyle = '#000';
        ctx.lineWidth = 2;
        ctx.stroke();

        setPrevPos({ x, y });
    };

    const endDrawing = () => {
        if (!isDrawing) return;
        setIsDrawing(false);
        const canvas = canvasRef.current;
        const dataURL = canvas.toDataURL();
        onSave(dataURL);
    };

    const clearSignature = () => {
        const canvas = canvasRef.current;
        const ctx = canvas.getContext('2d');
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        onSave(null);
    };

    return (
        <div className="space-y-2">
            <canvas
                ref={canvasRef}
                width={400}
                height={200}
                className="border-2 border-dashed border-gray-300 rounded-lg w-full cursor-crosshair bg-white"
                onMouseDown={startDrawing}
                onMouseMove={draw}
                onMouseUp={endDrawing}
                onMouseLeave={endDrawing}
            />
            <button
                type="button"
                onClick={clearSignature}
                className="bg-gray-200 hover:bg-gray-300 px-3 py-1 rounded text-sm"
            >
                Clear Signature
            </button>
        </div>
    );
};

const SharedFormViewer = () => {
    const { shareId } = useParams();
    const [form, setForm] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [currentStep, setCurrentStep] = useState(0);
    const [formData, setFormData] = useState({});
    const [validationErrors, setValidationErrors] = useState({});
    const [elementVisibility, setElementVisibility] = useState({});
    const [showTargets, setShowTargets] = useState(new Set());
    const [ocrProcessing, setOcrProcessing] = useState({});
    const [previewUrls, setPreviewUrls] = useState({});
    const [leadId, setLeadID] = useState();
    const [validtionforemail, setValidtionForEmail] = useState();
    const [triggerFuc, setTriggerFuc] = useState({ phone: "", email: "" });
    const [nearestAirportData, setNearestAirportData] = useState({});
    const [searchingAirport, setSearchingAirport] = useState(false);
    const [airportError, setAirportError] = useState('');
    const fileInputRef = useRef(null);

    // Edit functionality states
    const [editingField, setEditingField] = useState(null);
    const [editValue, setEditValue] = useState('');
    const [editComplexValue, setEditComplexValue] = useState({});
    const [editFile, setEditFile] = useState(null);
    const [editFilePreview, setEditFilePreview] = useState('');
    
    // Thank you modal state
    const [showThankYou, setShowThankYou] = useState(false);
    const [submissionSuccess, setSubmissionSuccess] = useState(false);
    
    const formContainerRef = useRef(null);

    // Add review step to the steps array
    const stepsWithReview = form ? [
        ...form.steps,
        { id: 'review', name: 'Review & Submit', type: 'review' }
    ] : [];

    useEffect(() => {
        const fetchForm = async () => {
            try {
                const response = await axios.get(`http://localhost:5000/api/forms/shared/${shareId}`);
                const rawForm = response.data.form;
                setLeadID(rawForm?.lead_id)
                // Normalize the form structure
                const normalizedForm = {
                    ...rawForm,
                    steps: rawForm.steps.map(step => ({
                        ...step,
                        elements: step.elements.map(element => ({
                            ...element,
                            // Flatten the nested config
                            ...(element.config?.config || {})
                        }))
                    }))
                };

                setForm(normalizedForm);

                // Initialize form data structure
                const initialData = {};
                normalizedForm.steps.forEach(step => {
                    step.elements.forEach(field => {
                        if (field.type === 'address') {
                            initialData[`${field.id}.street1`] = '';
                            initialData[`${field.id}.street2`] = '';
                            initialData[`${field.id}.city`] = '';
                            initialData[`${field.id}.state`] = '';
                            initialData[`${field.id}.postalCode`] = '';
                        } else if (field.type === 'aadhar') {
                            initialData[`${field.id}.aadharNumber`] = '';
                            initialData[`${field.id}.firstName`] = '';
                            initialData[`${field.id}.lastName`] = '';
                            initialData[`${field.id}.dob`] = '';
                            initialData[`${field.id}.gender`] = '';
                            initialData[`${field.id}.address`] = '';
                            initialData[`${field.id}.frontImage`] = null;
                            initialData[`${field.id}.backImage`] = null;
                        } else if (field.type === 'passport') {
                            initialData[`${field.id}.passportNumber`] = '';
                            initialData[`${field.id}.firstName`] = '';
                            initialData[`${field.id}.lastName`] = '';
                            initialData[`${field.id}.nationality`] = '';
                            initialData[`${field.id}.dob`] = '';
                            initialData[`${field.id}.placeOfBirth`] = '';
                            initialData[`${field.id}.issueDate`] = '';
                            initialData[`${field.id}.expiryDate`] = '';
                            initialData[`${field.id}.frontImage`] = null;
                            initialData[`${field.id}.backImage`] = null;
                        } else if (field.type === 'multiple-choice') {
                            initialData[field.id] = [];
                        } else if (field.type === 'star-rating') {
                            initialData[field.id] = { rating: field.rating ?? 0 };
                        } else if (field.type === 'scale-rating') {
                            initialData[field.id] = {
                                value: field.value ?? (field.min && field.max ? Math.floor((field.min + field.max) / 2) : 5)
                            };
                        } else if (field.type === 'banner') {
                            initialData[field.id] = field.bannerImage || null;
                        } else if (field.type === 'single-choice' || field.type === 'dropdown') {
                            initialData[field.id] = field.selectedOption || '';
                        } else if (field.type === 'ocr-aadhar') {
                            initialData[`${field.id}.frontImage`] = null;
                            initialData[`${field.id}.backImage`] = null;
                            initialData[`${field.id}.aadharNumber`] = '';
                            initialData[`${field.id}.name`] = '';
                            initialData[`${field.id}.dob`] = '';
                            initialData[`${field.id}.gender`] = '';
                            initialData[`${field.id}.address`] = '';
                        } else if (field.type === 'ocr-passport' || field.type === 'ocr-password') {
                            initialData[`${field.id}.frontImage`] = null;
                            initialData[`${field.id}.backImage`] = null;
                            initialData[`${field.id}.passportNumber`] = '';
                            initialData[`${field.id}.fullName`] = '';
                            initialData[`${field.id}.nationality`] = '';
                            initialData[`${field.id}.dob`] = '';
                            initialData[`${field.id}.placeOfBirth`] = '';
                            initialData[`${field.id}.issueDate`] = '';
                            initialData[`${field.id}.expiryDate`] = '';
                        } else if (field.type === 'nearest-airport') {
                            initialData[`${field.id}.address`] = '';
                            initialData[`${field.id}.selectedAirport`] = '';
                            initialData[`${field.id}.airportCode`] = '';
                            initialData[`${field.id}.distanceKm`] = '';
                        } else if (field.type === 'signature') {
                            initialData[field.id] = field.signatureData || null;
                        } else {
                            initialData[field.id] = field.defaultValue || '';
                        }
                    });
                });
                setFormData(initialData);

                // Identify fields that have show rules
                const showTargetsSet = new Set();
                if (normalizedForm.rules) {
                    normalizedForm.rules.forEach(rule => {
                        rule.actions.forEach(action => {
                            if (action.action === 'show') {
                                showTargetsSet.add(action.target);
                            }
                        });
                    });
                }
                setShowTargets(showTargetsSet);

                // Initialize visibility: hide fields with show rules by default
                const initialVisibility = {};
                normalizedForm.steps.forEach(step => {
                    step.elements.forEach(element => {
                        // Fields with show rules start hidden, others visible
                        initialVisibility[element.id] = !showTargetsSet.has(element.id);
                    });
                });
                setElementVisibility(initialVisibility);
            } catch (err) {
                setError(err.response?.data?.message || 'Failed to load form');
            } finally {
                setLoading(false);
            }
        };

        fetchForm();
    }, [shareId]);

    // Clean up preview URLs on unmount
    useEffect(() => {
        return () => {
            Object.values(previewUrls).forEach(url => {
                if (typeof url === 'string' && url.startsWith('blob:')) {
                    URL.revokeObjectURL(url);
                }
            });
        };
    }, [previewUrls]);

    // Update element visibility when form data changes
    useEffect(() => {
        if (!form || !form.rules) return;

        // Create a new visibility object
        const newVisibility = { ...elementVisibility };
        let visibilityChanged = false;

        // Apply all rules
        form.rules.forEach(rule => {
            const conditionsMet = rule.conditions.every(condition =>
                evaluateCondition(condition, formData)
            );

            if (conditionsMet) {
                rule.actions.forEach(action => {
                    if (action.action === 'show') {
                        if (!newVisibility[action.target]) {
                            newVisibility[action.target] = true;
                            visibilityChanged = true;
                        }
                    } else if (action.action === 'hide') {
                        if (newVisibility[action.target]) {
                            newVisibility[action.target] = false;
                            visibilityChanged = true;
                        }
                    }
                });
            } else {
                // When conditions are not met, hide fields with show rules
                rule.actions.forEach(action => {
                    if (action.action === 'show' && showTargets.has(action.target)) {
                        if (newVisibility[action.target]) {
                            newVisibility[action.target] = false;
                            visibilityChanged = true;
                        }
                    }
                });
            }
        });

        if (visibilityChanged) {
            setElementVisibility(newVisibility);
        }
    }, [formData, form, showTargets]);

    const handleElementChange = (fieldId, updates) => {
        setFormData(prev => {
            // For signature fields, store the data URL directly
            if (prev[fieldId] !== null && typeof prev[fieldId] === 'string' && prev[fieldId].startsWith('data:image')) {
                return {
                    ...prev,
                    [fieldId]: updates
                };
            }

            // For banner fields, we store the image URL directly
            if (prev[fieldId] !== null && typeof prev[fieldId] === 'string' && prev[fieldId].startsWith('data:image')) {
                return {
                    ...prev,
                    [fieldId]: updates
                };
            }

            // For fields stored as objects (like star-rating, scale-rating)
            if (typeof prev[fieldId] === 'object' && !Array.isArray(prev[fieldId])) {
                return {
                    ...prev,
                    [fieldId]: {
                        ...prev[fieldId],
                        ...updates
                    }
                };
            }
            // For fields stored as primitives or arrays
            return {
                ...prev,
                [fieldId]: updates
            };
        });

        // Clear validation error when field changes
        if (validationErrors[fieldId]) {
            setValidationErrors(prev => {
                const newErrors = { ...prev };
                delete newErrors[fieldId];
                return newErrors;
            });
        }
    };

    const handleSearch = async (place, fieldId) => {
        try {
            setAirportError('');
            setSearchingAirport(true);
            
            // 1. Get coordinates using OpenCage
            const geoResponse = await axios.get(
                'https://api.opencagedata.com/geocode/v1/json',
                {
                    params: {
                        key: "d961ea3a73bc4618ba5955a6dcd8893f",
                        q: place,
                        pretty: 1,
                        language: 'en',
                    },
                }
            );

            if (!geoResponse.data.results.length) {
                throw new Error('Location not found');
            }

            const { lat, lng } = geoResponse.data.results[0].geometry;

            // 2. Find nearest airport using Aerodatabox API
            const airportResponse = await axios.get(
                'https://aerodatabox.p.rapidapi.com/airports/search/location',
                {
                    params: {
                        lat,
                        lon: lng,
                        radiusKm: 200,
                        limit: 5,
                    },
                    headers: {
                        'X-RapidAPI-Key': "ab97cbeb66msh472fd9ddf3c3acep193d81jsn71726d85047f",
                        'X-RapidAPI-Host': 'aerodatabox.p.rapidapi.com'
                    },
                }
            );

            // Check if airports were found
            if (!airportResponse.data.items || !airportResponse.data.items.length) {
                throw new Error('No airports found nearby');
            }

            const nearestAirport = airportResponse.data.items[0];
            
            // Update form data with the found airport information
            handleElementChange(`${fieldId}.selectedAirport`, nearestAirport.name || nearestAirport.shortName || 'Unknown Airport');
            handleElementChange(`${fieldId}.distanceKm`, Math.round(calculateDistance(lat, lng, nearestAirport.location.lat, nearestAirport.location.lon)));
            handleElementChange(`${fieldId}.airportCode`, nearestAirport.iata || nearestAirport.icao || 'N/A');
            
            // Store the full airport data for reference
            setNearestAirportData(prev => ({
                ...prev,
                [fieldId]: nearestAirport
            }));

        } catch (err) {
            console.error('Airport search error:', err);
            setAirportError(err.response?.data?.message || err.message || 'Something went wrong. Please try again.');
        } finally {
            setSearchingAirport(false);
        }
    };

    // Helper function to calculate distance between two points (Haversine formula)
    const calculateDistance = (lat1, lon1, lat2, lon2) => {
        const R = 6371; // Earth's radius in km
        const dLat = (lat2 - lat1) * Math.PI / 180;
        const dLon = (lon2 - lon1) * Math.PI / 180;
        const a = 
            Math.sin(dLat/2) * Math.sin(dLat/2) +
            Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
            Math.sin(dLon/2) * Math.sin(dLon/2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        return R * c;
    };

    const parseOcrText = (text, type, side = 'front') => {
        const result = {};

        if (type === 'ocr-passport' || type === 'ocr-password') {
            const cleanText = text.toUpperCase().replace(/\s+/g, ' ').trim();
            console.log('Processing passport', side.toUpperCase(), 'image text:', cleanText);

            if (side === 'front') {
                // 1. Passport Number from MRZ line
                const passportRegex = /([A-Z][0-9]{6,})<[0-9]/;
                const passportMatch = cleanText.match(passportRegex);
                if (passportMatch && passportMatch[1]) {
                    result.passportNumber = passportMatch[1];
                }

                // 2. Name from MRZ: P<INDSURNAME<<GIVENNAME<<<<
                const mrzNameRegex = /P<[A-Z]+([A-Z]+)<<([A-Z]+)<+/i;
                const mrzNameMatch = cleanText.match(mrzNameRegex);
                if (mrzNameMatch && mrzNameMatch[1] && mrzNameMatch[2]) {
                    result.surname = mrzNameMatch[1].replace(/^[A-Z]{3}/, '');
                    result.givenName = mrzNameMatch[2];
                    result.fullName = `${result.surname} ${result.givenName}`;
                }

                // 3. Nationality and Country
                const nationalityRegex = /REPUBLIC\s+OF\s+([A-Z]+)/i;
                const nationalityMatch = cleanText.match(nationalityRegex);
                if (nationalityMatch && nationalityMatch[1]) {
                    result.nationality = nationalityMatch[1];
                    result.country = nationalityMatch[1];
                }

                // 4. Date of Birth
                const dobRegex = /(\d{2}[\/\-]\d{2}[\/\-]\d{4})/;
                const dobMatch = cleanText.match(dobRegex);
                if (dobMatch && dobMatch[1]) {
                    const [day, month, year] = dobMatch[1].split(/[\/\-]/);
                    result.dob = `${year}-${month}-${day}`;
                }

                // 5. Gender
                const genderRegex = /\b([MF])\b/;
                const genderMatch = cleanText.match(genderRegex);
                if (genderMatch && genderMatch[1]) {
                    result.gender = genderMatch[1] === 'M' ? 'Male' : 'Female';
                }

                // 6. Place of Birth
                const pobRegex = /PLACE\s+OF\s+BIRTH[:\s]*([A-Z][A-Z\s,]+)/i;
                const pobMatch = cleanText.match(pobRegex);
                if (pobMatch && pobMatch[1]) {
                    result.placeOfBirth = pobMatch[1].trim();
                }

                // 7. Place of Issue
                const poiRegex = /PLACE\s+OF\s+ISSUE[:\s]*([A-Z][A-Z\s]+)/i;
                const poiMatch = cleanText.match(poiRegex);
                if (poiMatch && poiMatch[1]) {
                    result.placeOfIssue = poiMatch[1].trim();
                }

                // 8. Dates of Issue and Expiry
                const dateRegex = /(\d{2}[\/\-]\d{2}[\/\-]\d{4})/g;
                const dateMatches = cleanText.match(dateRegex);
                if (dateMatches) {
                    if (dateMatches[0]) {
                        const [day, month, year] = dateMatches[0].split(/[\/\-]/);
                        result.issueDate = `${year}-${month}-${day}`;
                    }
                    if (dateMatches[1]) {
                        const [day, month, year] = dateMatches[1].split(/[\/\-]/);
                        result.expiryDate = `${year}-${month}-${day}`;
                    }
                }

            } else {
                // BACK SIDE PARSING - Dynamic family details

                // 1. Father's Name
                const fatherRegex = /NAME\s+OF\s+FATHER[^A-Z]*([A-Z][A-Z\s]+)/i;
                const fatherMatch = cleanText.match(fatherRegex);
                if (fatherMatch && fatherMatch[1]) {
                    result.fatherName = fatherMatch[1].trim();
                }

                // 2. Mother's Name
                const motherRegex = /NAME\s+OF\s+MOTHER[^A-Z]*([A-Z][A-Z\s]+)/i;
                const motherMatch = cleanText.match(motherRegex);
                if (motherMatch && motherMatch[1]) {
                    result.motherName = motherMatch[1].trim();
                }

                // 3. Spouse Name
                const spouseRegex = /NAME\s+OF\s+SPOUSE[^A-Z]*([A-Z][A-Z\s]+)/i;
                const spouseMatch = cleanText.match(spouseRegex);
                if (spouseMatch && spouseMatch[1]) {
                    result.spouseName = spouseMatch[1].trim();
                }

                // 4. Address components
                const addressComponents = [];

                // House Number
                const houseRegex = /H\s+NO[^A-Z0-9]*([A-Z0-9\s]+)/i;
                const houseMatch = cleanText.match(houseRegex);
                if (houseMatch && houseMatch[1]) {
                    addressComponents.push(`H NO ${houseMatch[1].trim()}`);
                }

                // Area
                const areaRegex = /[^A-Z]([A-Z][A-Z\s]+)(?=,)/;
                const areaMatch = cleanText.match(areaRegex);
                if (areaMatch && areaMatch[1]) {
                    addressComponents.push(areaMatch[1].trim());
                }

                // City
                const cityRegex = /([A-Z][A-Z\s]+)(极?=,)/g;
                const cityMatches = cleanText.match(cityRegex);
                if (cityMatches && cityMatches[1]) {
                    addressComponents.push(cityMatches[1].trim());
                }

                // District
                const districtRegex = /([A-Z][A-Z\s]+)(?=\.)/;
                const districtMatch = cleanText.match(districtRegex);
                if (districtMatch && districtMatch[1]) {
                    addressComponents.push(districtMatch[1].trim());
                }

                // PIN Code
                const pinRegex = /PIN[^0-9]*(\d{6})/i;
                const pinMatch = cleanText.match(pinRegex);
                if (pinMatch && pinMatch[1]) {
                    result.pinCode = pinMatch[1];
                    addressComponents.push(`PIN: ${pinMatch[1]}`);
                }

                // State
                const stateRegex = /,([A-Z][A-Z\s]+),INDIA/i;
                const stateMatch = cleanText.match(stateRegex);
                if (stateMatch && stateMatch[1]) {
                    addressComponents.push(stateMatch[1].trim());
                }

                // Country
                addressComponents.push('INDIA');

                if (addressComponents.length > 0) {
                    result.address = addressComponents.join(', ');
                }

                // 5. Old Passport Number
                const oldPassportRegex = /OLD\s+PASSPORT[^A-Z0-9]*([A-Z0-9]+)/i;
                const oldPassportMatch = cleanText.match(oldPassportRegex);
                if (oldPassportMatch && oldPassportMatch[1]) {
                    result.oldPassportNumber = oldPassportMatch[1];
                }
            }

        } else if (type === 'ocr-aadhar') {
            // AADHAR PROCESSING
            const cleanText = text.toUpperCase().replace(/\s+/g, ' ').trim();
            console.log('Processing aadhar', side.toUpperCase(), 'image text:', cleanText);

            if (side === 'front') {
                // 1. Aadhar Number
                const aadharPatterns = [
                    /(\d{4}\s?\d{4}\s?\d{4})/,
                    /(\d{12})/,
                    /\b\d{4}[\s-]?\d{4}[\s-]?\d{4}\b/
                ];

                for (const pattern of aadharPatterns) {
                    const match = cleanText.match(pattern);
                    if (match) {
                        const aadharNo = match[1] || match[0];
                        result.aadharNumber = aadharNo.replace(/\s/g, '');
                        if (result.aadharNumber.length === 12) break;
                    }
                }

                // 2. Name
                const namePatterns = [
                    /([A-Z][A-Z\s]{3,}?)(?=\s*(?:DOB|DATE|MALE|FEMALE|\d{2}[\/\-]\d{2}[\/\-]\d{4}|$))/i,
                    /(?:NAME|नाम)[\s:]*([A-Z][A-Z\s]+)/i
                ];

                for (const pattern of namePatterns) {
                    const match = cleanText.match(pattern);
                    if (match && match[1]) {
                        result.name = match[1].trim();
                        break;
                    }
                }

                // 3. Date of Birth
                const dobPatterns = [
                    /DOB[:\s]*(\d{2}[\/\-]\d{2}[\/\-]\d{4})/i,
                    /DATE\s+OF\s+BIRTH[:\s]*(\d{2}[\/\-]\d{2}[\/\-]\d{4})/i,
                    /(\d{2}[\/\-]\d{2}[\/\-]\d{4})/
                ];

                for (const pattern of dobPatterns) {
                    const match = cleanText.match(pattern);
                    if (match && match[1]) {
                        const [day, month, year] = match[1].split(/[\/\-]/);
                        result.dob = `${year}-${month}-${day}`;
                        break;
                    }
                }

                // 4. Gender
                const genderPatterns = [
                    /(?:GENDER|SEX|लिंग)[\s:]*([MF])/i,
                    /\b(MALE|FEMALE)\b/i,
                    /\b([MF])\b/
                ];

                for (const pattern of genderPatterns) {
                    const match = cleanText.match(pattern);
                    if (match) {
                        const genderText = match[1] || match[0];
                        result.gender = genderText.includes('M') || genderText.includes('MALE') ? 'Male' : 'Female';
                        break;
                    }
                }

                // 5. Address
                const addressPatterns = [
                    /(?:ADDRESS|पता)[\s:]*([A-Z0-9][A-Z0-9\s,]+)/i,
                    /([A-Z][A-Z\s,]{10,}?)(?=\s*(?:PIN|INDIA|$))/i
                ];

                for (const pattern of addressPatterns) {
                    const match = cleanText.match(pattern);
                    if (match && match[1]) {
                        result.address = match[1].trim();
                        break;
                    }
                }

            } else {
                // AADHAR BACK SIDE
                // Clean up OCR artifacts
                const cleanedText = cleanText.replace(/[^A-Z0-9\s,:\.\/\-]/g, ' ').replace(/\s+/g, ' ').trim();

                // 1. Address
                const addressPatterns = [
                    /(?:ADDRESS|पता)[\s:]*([A-Z0-9][A-Z0-9\s,\.\/\-]+?)(?=\s*(?:PIN|POSTAL|$))/i,
                    /([A-Z0-9][A-Z0-9\s,\.\/\-]{15,}?)(?=\s*(?:PIN|POSTAL|$))/i
                ];

                for (const pattern of addressPatterns) {
                    const match = cleanedText.match(pattern);
                    if (match && match[1]) {
                        result.address = match[1].trim();
                        break;
                    }
                }

                // 2. Father's/Husband's Name
                const relativePatterns = [
                    /S\/O[:\s]*([A-Z][A-Z\s]+)/i,
                    /H\/O[:\s]*([A-Z][A-Z\s]+)/i,
                    /W\/O[:\s]*([A-Z][A-Z\s]+)/i
                ];

                for (const pattern of relativePatterns) {
                    const match = cleanedText.match(pattern);
                    if (match && match[1]) {
                        result.relativeName = match[1].trim();
                        break;
                    }
                }

                // 3. PIN Code
                const pinPatterns = [
                    /PIN[:\s]*(\d{6})/i,
                    /POSTAL[:\s]*(\d{6})/i,
                    /(\d{6})(?=\s*(?:INDIA|$))/i
                ];

                for (const pattern of pinPatterns) {
                    const match = cleanedText.match(pattern);
                    if (match && match[1]) {
                        result.pinCode = match[1];
                        break;
                    }
                }

                // 4. Extract address components if full address not found
                if (!result.address) {
                    const addressComponents = [];

                    // House number
                    const housePattern = /[A-Z]*\d+[A-Z]*\/?[A-Z\d]*/;
                    const houseMatch = cleanedText.match(housePattern);
                    if (houseMatch) {
                        addressComponents.push(houseMatch[0]);
                    }

                    // Area/Locality
                    const areaPattern = /[A-Z]{3,}\s+[A-Z]{3,}/;
                    const areaMatch = cleanedText.match(areaPattern);
                    if (areaMatch) {
                        addressComponents.push(areaMatch[0]);
                    }

                    // City/District
                    const cityPattern = /(?:DELHI|MUMBAI|KOLKATA|CHENNAI|BANGALORE|HYDERABAD|PUNE|AHMEDABAD)/i;
                    const cityMatch = cleanedText.match(cityPattern);
                    if (cityMatch) {
                        addressComponents.push(cityMatch[0]);
                    }

                    if (addressComponents.length > 0) {
                        result.address = addressComponents.join(', ');
                    }
                }
            }
        }

        console.log('Final parsed result:', result);
        return result;
    };

    // Enhanced processOCR function to handle both sides
    const processOCR = async (file, fieldId, parentFieldId, elementType, side = 'front') => {
        let worker;
        try {
            setOcrProcessing(prev => ({ ...prev, [fieldId]: true }));

            console.log(`Starting OCR processing for ${elementType}, side: ${side}`);

            worker = await createWorker({
                logger: m => console.log(m),
                errorHandler: err => console.error('Tesseract error:', err)
            });

            await worker.load();
            await worker.loadLanguage('eng');
            await worker.initialize('eng');

            const { data: { text } } = await worker.recognize(file);
            console.log('Raw OCR Text:', text);

            const parsedData = parseOcrText(text, elementType, side);
            console.log('Parsed Data:', parsedData);

            // Fill the form data
            Object.entries(parsedData).forEach(([key, value]) => {
                const fullFieldId = `${parentFieldId}.${key}`;
                if (value) {
                    handleElementChange(fullFieldId, value);
                }
            });

            // Show success message with extracted fields
            const extractedFields = Object.keys(parsedData).filter(key => parsedData[key]);
            if (extractedFields.length > 0) {
                alert(`✅ OCR Success! Extracted: ${extractedFields.join(', ')}`);
            } else {
                alert('⚠️ No data extracted. Please enter details manually.');
            }

        } catch (error) {
            console.error('OCR processing failed:', error);
            alert(`❌ OCR failed: ${error.message || 'Please enter details manually.'}`);
        } finally {
            if (worker) {
                await worker.terminate();
            }
            setOcrProcessing(prev => ({ ...prev, [fieldId]: false }));
        }
    };

    const handleFileUpload = (e, fieldId, fieldType) => {
        const files = e.target.files;
        if (!files || files.length === 0) return;
        const file = files[0];

        // Create and store preview URL
        const previewUrl = URL.createObjectURL(file);
        setPreviewUrls(prev => ({ ...prev, [fieldId]: previewUrl }));

        // Update form data with preview URL
        handleElementChange(fieldId, previewUrl);

        // Check if we should process OCR
        const parentFieldId = fieldId.split('.')[0];
        const elementType = form?.steps
            .flatMap(step => step.elements)
            .find(el => el.id === parentFieldId)?.type;

        // Determine if this is front or back image
        const side = fieldId.includes('frontImage') ? 'front' :
            fieldId.includes('backImage') ? 'back' : 'unknown';

        // Process OCR for supported document types
        if ((elementType === 'ocr-aadhar' ||
            elementType === 'ocr-passport' ||
            elementType === 'ocr-password') &&
            (side === 'front' || side === 'back')) {

            processOCR(file, fieldId, parentFieldId, elementType, side);
        }
    };

    const handleUploadButtonClick = (fieldId, fieldType) => {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = fieldType === 'image' ? 'image/*' : '*';
        input.multiple = fieldType === 'multiple' || fieldType === 'image-gallery';
        input.onchange = (e) => handleFileUpload(e, fieldId, fieldType);
        input.click();
    };

    const validateField = (fieldId, value, rules) => {
        const errors = [];

        if (!rules) return errors;

        rules.forEach(rule => {
            if (rule.fieldId === fieldId) {
                switch (rule.condition) {
                    case 'required':
                        if (!value ||
                            (typeof value === 'string' && value.trim() === '') ||
                            (Array.isArray(value) && value.length === 0)) {
                            errors.push(rule.message || 'This field is required');
                        }
                        break;
                    case 'minLength':
                        if (value && value.length < rule.value) {
                            errors.push(rule.message || `Minimum length is ${rule.value}`);
                        }
                        break;
                    case 'maxLength':
                        if (value && value.length > rule.value) {
                            errors.push(rule.message || `Maximum length is ${rule.value}`);
                        }
                        break;
                    case 'regex':
                        const regex = new RegExp(rule.value);
                        if (value && !regex.test(value)) {
                            errors.push(rule.message || 'Invalid format');
                        }
                        break;
                    case 'aadhar':
                        if (value && !/^\d{12}$/.test(value)) {
                            errors.push(rule.message || 'Aadhar number must be 12 digits');
                        }
                        break;
                    // Add more validation cases as needed
                }
            }
        });

        return errors;
    };

    const validateCurrentStep = () => {
        if (!form) return true;

        const currentStepFields = form.steps[currentStep].elements;
        let isValid = true;
        const newErrors = {};

        currentStepFields.forEach(field => {
            if (!elementVisibility[field.id]) return;

            const value = formData[field.id];
            const errors = validateField(field.id, value, form.rules);

            if (errors.length > 0) {
                isValid = false;
                newErrors[field.id] = errors[0]; // Show first error only
            }
        });

        setValidationErrors(newErrors);
        return isValid;
    };

    const handleNextStep = () => {
        if (validateCurrentStep()) {
            setCurrentStep(prev => Math.min(prev + 1, stepsWithReview.length - 1));
        }
    };

    const handlePrevStep = () => {
        setCurrentStep(prev => Math.max(prev - 1, 0));
    };

    const validPhoneNumber = async (phone) => {
        const API_KEY = "bdc_c86aa934de754b72aebadb76ab65ad24"
        const countryCode = "IN";
        const phoneRes = await fetch(
            `https://api-bdc.net/data/phone-number-validate?number=${encodeURIComponent(
                phone
            )}&countryCode=${countryCode}&key=${API_KEY}`
        );

        const phoneData = await phoneRes.json();
        setTriggerFuc((prev) => ({
            ...prev,
            phone: true
        }))

        console.log(phoneData);
    }

    const valiemailcheck = async (email) => {
        setTriggerFuc((prev) => ({
            ...prev,
            email: true
        }))
        const API_KEY = "bdc_c86aa934de754b72aebadb76ab65ad24"
        try {
            // Email validation
            const emailRes = await fetch(
                `https://api-bdc.net/data/email-verify?emailAddress=${encodeURIComponent(
                    email
                )}&key=${API_KEY}`
            );
            const emailData = await emailRes.json();

            if (emailData.isValid) {
                setValidtionForEmail(true);
            } else {
                setValidtionForEmail(false);
            }

        } catch (error) {
            console.error('Error validating:', error);
        }
    };

    const handleSubmit = async () => {
        try {
            // Prepare form data in the required array format
            const submissionData = [];

            // Process each field in formData
            Object.keys(formData).forEach(key => {
                // For nested fields (like address, aadhar, nearest-airport, etc.)
                if (key.includes('.')) {
                    const [parentId, fieldName] = key.split('.');
                    const parentElement = form.steps
                        .flatMap(step => step.elements)
                        .find(el => el.id === parentId);

                    // Find or create the parent object
                    let parentObj = submissionData.find(item => item.field_id === parentId);

                    if (!parentObj) {
                        parentObj = {
                            type: parentElement?.type || '',
                            value: {},
                            field_id: parentId,
                            label: parentElement?.label || ''
                        };
                        submissionData.push(parentObj);
                    }

                    // Add the nested field value
                    if (typeof parentObj.value !== 'object' || parentObj.value === null) {
                        parentObj.value = {};
                    }
                    parentObj.value[fieldName] = formData[key];
                } else {
                    // For simple fields
                    const fieldElement = form.steps
                        .flatMap(step => step.elements)
                        .find(el => el.id === key);

                    submissionData.push({
                        type: fieldElement?.type || '',
                        value: formData[key],
                        field_id: key,
                        label: fieldElement?.label || ''
                    });
                }
            });

            await axios.post(`http://localhost:5000/api/forms/submit`, {
                shareId: shareId,
                lead_id: leadId,
                responses: submissionData
            });
            
            setSubmissionSuccess(true);
            setShowThankYou(true);
            
        } catch (err) {
            alert(err.response?.data?.message || 'Submission failed');
        }
    };

    // Function to format field value for display
    const formatFieldValue = (fieldId, value) => {
        if (value == null || value === '') return 'Not provided';
        
        // Handle blob URLs (file uploads)
        if (typeof value === 'string' && value.startsWith('blob:')) {
            return '✅ File uploaded';
        }
        
        // Handle signature data URLs
        if (typeof value === 'string' && value.startsWith('data:image') && fieldId.includes('signature')) {
            return '✅ Signature provided';
        }
        
        if (Array.isArray(value)) {
            return value.length > 0 ? value.join(', ') : 'Not provided';
        }
        
        if (typeof value === 'object') {
            // Handle star rating
            if (value.rating !== undefined) {
                return `${value.rating} star${value.rating !== 1 ? 's' : ''}`;
            }
            // Handle scale rating
            if (value.value !== undefined) {
                return value.value.toString();
            }
            
            // For complex objects like address, aadhar, passport, etc.
            const nonEmptyValues = Object.entries(value)
                .filter(([key, val]) => !isEmpty(val))
                .map(([key, val]) => {
                    // Format the key for better display
                    const formattedKey = key
                        .replace(/([A-Z])/g, ' $1')
                        .replace(/^./, str => str.toUpperCase())
                        .replace(/\./g, ' ');
                    
                    // Handle nested file uploads
                    if (typeof val === 'string' && val.startsWith('blob:')) {
                        return `${formattedKey}: ✅ Uploaded`;
                    }
                    return `${formattedKey}: ${val}`;
                });
            
            return nonEmptyValues.length > 0 ? nonEmptyValues.join('\n') : 'Not provided';
        }
        
        return value.toString();
    };

    // Function to get field label by ID
    const getFieldLabel = (fieldId) => {
        if (fieldId.includes('.')) {
            const [parentId, fieldName] = fieldId.split('.');
            const parentElement = form.steps
                .flatMap(step => step.elements)
                .find(el => el.id === parentId);
            
            if (parentElement) {
                // Format the field name for better display
                const formattedFieldName = fieldName
                    .replace(/([A-Z])/g, ' $1')
                    .replace(/^./, str => str.toUpperCase())
                    .replace(/(front|back)Image/i, '$1 Image')
                    .replace(/AadharNumber/i, 'Aadhar Number')
                    .replace(/PassportNumber/i, 'Passport Number')
                    .replace(/PostalCode/i, 'Postal Code')
                    .replace(/Dob/i, 'Date of Birth');
                
                return `${parentElement.label} - ${formattedFieldName}`;
            }
        } else {
            const element = form.steps
                .flatMap(step => step.elements)
                .find(el => el.id === fieldId);
            return element?.label || fieldId;
        }
        return fieldId;
    };

    // Check if field is a file/image field
    const isFileField = (fieldId, currentValue) => {
        const element = form.steps
            .flatMap(step => step.elements)
            .find(el => el.id === fieldId) || 
            form.steps
                .flatMap(step => step.elements)
                .find(el => fieldId.startsWith(el.id));

        if (!element) return false;

        // List of actual file/image field types
        const fileFieldTypes = [
            'signature', 
            'file-upload', 
            'banner',
            'image-gallery'
        ];

        // Check if it's specifically an image upload field (frontImage, backImage, etc.)
        const isImageUploadField = fieldId.includes('frontImage') || 
               fieldId.includes('backImage') ||
               fieldId.includes('.image');

        // Check if it's a file field type
        const isFileType = fileFieldTypes.includes(element.type) || isImageUploadField;

        // Additional check: if current value is a blob URL, treat it as a file field
        const hasBlobValue = currentValue && typeof currentValue === 'string' && currentValue.startsWith('blob:');

        return isFileType || hasBlobValue;
    };

    // Render file preview in review mode
    const renderFilePreview = (fieldId, value) => {
        // Only show file preview for actual file fields with blob URLs or signature data URLs
        if (!value || typeof value !== 'string') {
            return null;
        }

        // Handle signature data URLs
        if (value.startsWith('data:image') && fieldId.includes('signature')) {
            return (
                <div className="flex items-center space-x-3">
                    <img
                        src={value}
                        alt="Signature"
                        className="w-16 h-16 object-contain border rounded"
                    />
                    <span className="text-green-600 text-sm">✅ Signature provided</span>
                </div>
            );
        }

        // Handle blob URLs (file uploads)
        if (value.startsWith('blob:')) {
            return (
                <div className="flex items-center space-x-3">
                    <img
                        src={value}
                        alt="Uploaded file"
                        className="w-16 h-16 object-cover border rounded"
                        onError={(e) => {
                            e.target.style.display = 'none';
                            e.target.nextSibling.style.display = 'block';
                        }}
                    />
                    <div className="hidden">
                        <div className="w-16 h-16 bg-gray-100 border rounded flex items-center justify-center">
                            <span className="text-2xl">📄</span>
                        </div>
                    </div>
                    <span className="text-green-600 text-sm">✅ File uploaded</span>
                </div>
            );
        }

        return null;
    };

    // Start editing a field
    const startEditing = (fieldId, currentValue) => {
        setEditingField(fieldId);
        
        if (typeof currentValue === 'object' && !Array.isArray(currentValue)) {
            setEditComplexValue(currentValue);
            setEditValue('');
        } else if (Array.isArray(currentValue)) {
            setEditValue(currentValue.join(', '));
            setEditComplexValue({});
        } else {
            setEditValue(currentValue || '');
            setEditComplexValue({});
        }

        if (currentValue && typeof currentValue === 'string' && (currentValue.startsWith('blob:') || currentValue.startsWith('data:image'))) {
            setEditFilePreview(currentValue);
        }
    };

    // Cancel editing
    const cancelEditing = () => {
        setEditingField(null);
        setEditValue('');
        setEditComplexValue({});
        setEditFile(null);
        setEditFilePreview('');
    };

    // Save the edited value
    const saveEditing = () => {
        if (editingField) {
            let newValue;
            
            if (editFile) {
                const previewUrl = URL.createObjectURL(editFile);
                setPreviewUrls(prev => ({ ...prev, [editingField]: previewUrl }));
                newValue = previewUrl;
            } else if (Object.keys(editComplexValue).length > 0) {
                newValue = editComplexValue;
            } else if (editValue.includes(',') && editingField.includes('.')) {
                newValue = editValue.split(',').map(item => item.trim()).filter(item => item);
            } else {
                newValue = editValue;
            }
            
            handleElementChange(editingField, newValue);
            cancelEditing();
        }
    };

    // Handle complex field editing
    const handleComplexFieldChange = (subField, value) => {
        setEditComplexValue(prev => ({
            ...prev,
            [subField]: value
        }));
    };

    // Handle file change in edit mode
    const handleEditFileChange = (e) => {
        const file = e.target.files[0];
        if (file) {
            setEditFile(file);
            const previewUrl = URL.createObjectURL(file);
            setEditFilePreview(previewUrl);
        }
    };

    // Remove file in edit mode
    const handleRemoveEditFile = () => {
        setEditFile(null);
        setEditFilePreview('');
        handleElementChange(editingField, '');
    };

    // Render edit input based on field type
    const renderEditInput = (fieldId, currentValue) => {
        const element = form.steps
            .flatMap(step => step.elements)
            .find(el => el.id === fieldId) || 
            form.steps
                .flatMap(step => step.elements)
                .find(el => fieldId.startsWith(el.id));

        if (!element) {
            return (
                <input
                    type="text"
                    value={editValue}
                    onChange={(e) => setEditValue(e.target.value)}
                    className="w-full p-2 border rounded"
                    autoFocus
                />
            );
        }

        // Handle signature fields
        if (element.type === 'signature') {
            return (
                <div className="space-y-4">
                    <SignaturePad 
                        fieldId={fieldId}
                        onSave={(signatureData) => {
                            handleElementChange(fieldId, signatureData);
                            setEditFilePreview(signatureData);
                        }}
                        currentSignature={currentValue}
                    />
                    {currentValue && (
                        <div className="p-2 bg-gray-50 rounded">
                            <p className="text-sm text-gray-600">
                                Current signature will be replaced when you draw a new one.
                            </p>
                        </div>
                    )}
                </div>
            );
        }

        // Handle file fields
        if (isFileField(fieldId, currentValue)) {
            return (
                <div className="space-y-4">
                    {(editFilePreview || (currentValue && typeof currentValue === 'string' && (currentValue.startsWith('blob:') || currentValue.startsWith('data:image')))) && (
                        <div>
                            <p className="text-sm font-medium mb-2">Current File:</p>
                            {editFilePreview || currentValue ? (
                                <img
                                    src={editFilePreview || currentValue}
                                    alt="Preview"
                                    className="w-full max-w-xs h-auto border rounded-lg"
                                />
                            ) : (
                                <p className="text-gray-500">No file uploaded</p>
                            )}
                        </div>
                    )}

                    <div className="space-y-2">
                        <input
                            type="file"
                            onChange={handleEditFileChange}
                            className="w-full p-2 border rounded"
                            accept={element.type === 'image' ? 'image/*' : '*'}
                        />
                        <div className="flex space-x-2">
                            <button
                                type="button"
                                onClick={() => document.querySelector('input[type="file"]').click()}
                                className="px-3 py-1 bg-blue-600 text-white text-sm rounded hover:bg-blue-700"
                            >
                                Choose New File
                            </button>
                            {(editFilePreview || (currentValue && typeof currentValue === 'string' && (currentValue.startsWith('blob:') || currentValue.startsWith('data:image')))) && (
                                <button
                                    type="button"
                                    onClick={handleRemoveEditFile}
                                    className="px-3 py-1 bg-red-600 text-white text-sm rounded hover:bg-red-700"
                                >
                                    Remove File
                                </button>
                            )}
                        </div>
                    </div>

                    {editFile && (
                        <div className="p-2 bg-gray-50 rounded">
                            <p className="text-sm">
                                <strong>Selected File:</strong> {editFile.name}<br/>
                                <strong>Size:</strong> {(editFile.size / 1024 / 1024).toFixed(2)} MB<br/>
                                <strong>Type:</strong> {editFile.type}
                            </p>
                        </div>
                    )}
                </div>
            );
        }

        // Handle nested fields
        if (fieldId.includes('.')) {
            const [parentId, subField] = fieldId.split('.');
            const parentElement = form.steps
                .flatMap(step => step.elements)
                .find(el => el.id === parentId);

            if (!parentElement) {
                return (
                    <input
                        type="text"
                        value={editValue}
                        onChange={(e) => setEditValue(e.target.value)}
                        className="w-full p-2 border rounded"
                        autoFocus
                    />
                );
            }

            switch (parentElement.type) {
                case 'address':
                case 'aadhar':
                case 'passport':
                case 'ocr-aadhar':
                case 'ocr-passport':
                case 'ocr-password':
                case 'nearest-airport':
                    return (
                        <input
                            type="text"
                            value={editValue}
                            onChange={(e) => setEditValue(e.target.value)}
                            className="w-full p-2 border rounded"
                            placeholder={`Enter ${subField}`}
                            autoFocus
                        />
                    );
                
                default:
                    return (
                        <input
                            type="text"
                            value={editValue}
                            onChange={(e) => setEditValue(e.target.value)}
                            className="w-full p-2 border rounded"
                            autoFocus
                        />
                    );
            }
        }

        // Handle main field types
        switch (element.type) {
            case 'star-rating':
                return (
                    <div className="flex items-center">
                        {[...Array(element.maxRating || 5)].map((_, i) => (
                            <button
                                key={i}
                                onClick={() => handleComplexFieldChange('rating', i + 1)}
                                className="text-2xl mr-1 cursor-pointer"
                            >
                                {i < (editComplexValue.rating || 0) ? "★" : "☆"}
                            </button>
                        ))}
                    </div>
                );

            case 'scale-rating':
                return (
                    <div>
                        <div className="flex items-center justify-between mb-2">
                            <span>{element.min || 1}</span>
                            <input
                                type="range"
                                min={element.min || 1}
                                max={element.max || 10}
                                value={editComplexValue.value || currentValue?.value || 5}
                                onChange={(e) => handleComplexFieldChange('value', parseInt(e.target.value))}
                                className="w-full mx-2"
                            />
                            <span>{element.max || 10}</span>
                        </div>
                        <div className="text-center">Value: {editComplexValue.value || currentValue?.value || 5}</div>
                    </div>
                );

            case 'multiple-choice':
                return (
                    <div>
                        <textarea
                            value={editValue}
                            onChange={(e) => setEditValue(e.target.value)}
                            className="w-full p-2 border rounded"
                            placeholder="Enter options separated by commas"
                            rows={3}
                            autoFocus
                        />
                        <p className="text-xs text-gray-500 mt-1">Separate multiple choices with commas</p>
                    </div>
                );

            case 'single-choice':
            case 'dropdown':
                return (
                    <select
                        value={editValue}
                        onChange={(e) => setEditValue(e.target.value)}
                        className="w-full p-2 border rounded"
                        autoFocus
                    >
                        <option value="">Select an option</option>
                        {element.options?.map((option, idx) => (
                            <option key={idx} value={option}>{option}</option>
                        ))}
                    </select>
                );

            case 'date':
                return (
                    <input
                        type="date"
                        value={editValue}
                        onChange={(e) => setEditValue(e.target.value)}
                        className="w-full p-2 border rounded"
                        autoFocus
                    />
                );

            case 'time':
                return (
                    <input
                        type="time"
                        value={editValue}
                        onChange={(e) => setEditValue(e.target.value)}
                        className="w-full p-2 border rounded"
                        autoFocus
                    />
                );

            case 'email':
                return (
                    <div>
                        <input
                            type="email"
                            value={editValue}
                            onChange={(e) => setEditValue(e.target.value)}
                            className="w-full p-2 border rounded"
                            autoFocus
                        />
                    </div>
                );

            case 'phone':
                return (
                    <div>
                        <input
                            type="tel"
                            value={editValue}
                            onChange={(e) => setEditValue(e.target.value)}
                            className="w-full p-2 border rounded"
                            autoFocus
                        />
                    </div>
                );

            default:
                return (
                    <input
                        type="text"
                        value={editValue}
                        onChange={(e) => setEditValue(e.target.value)}
                        className="w-full p-2 border rounded"
                        autoFocus
                    />
                );
        }
    };

    // Download Form as Image
    const downloadFormAsImage = async () => {
        if (!formContainerRef.current) {
            console.error('Form container ref not found');
            alert('Cannot capture form. Please try again.');
            return;
        }

        try {
            const downloadBtn = document.querySelector('.download-btn');
            const originalBtnText = downloadBtn?.textContent;
            
            if (downloadBtn) {
                downloadBtn.textContent = "Downloading...";
                downloadBtn.disabled = true;
            }

            await new Promise(resolve => setTimeout(resolve, 500));

            const canvas = await html2canvas(formContainerRef.current, {
                scale: 2,
                useCORS: true,
                allowTaint: false,
                backgroundColor: '#ffffff',
                logging: false,
                removeContainer: true,
                onclone: (clonedDoc, element) => {
                    const downloadBtns = clonedDoc.querySelectorAll('.download-btn');
                    downloadBtns.forEach(btn => {
                        btn.style.display = 'none';
                    });
                }
            });

            const imageData = canvas.toDataURL('image/png', 1.0);
            const link = document.createElement('a');
            link.download = `form-${form?.name || 'data'}-${new Date().toISOString().split('T')[0]}.png`;
            link.href = imageData;
            
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);

            if (downloadBtn) {
                downloadBtn.textContent = originalBtnText;
                downloadBtn.disabled = false;
            }

            console.log('Form downloaded successfully');

        } catch (error) {
            console.error('Error capturing form screenshot:', error);
            alert('Failed to download form as image. Please try again.');
            
            const downloadBtn = document.querySelector('.download-btn');
            if (downloadBtn) {
                downloadBtn.textContent = "📸 Download as Image";
                downloadBtn.disabled = false;
            }
        }
    };

    // Download Form as Text
    const downloadFormAsText = () => {
        try {
            let textContent = `FORM: ${form?.name || 'Untitled Form'}\n`;
            textContent += `Generated on: ${new Date().toLocaleString()}\n`;
            textContent += '='.repeat(60) + '\n\n';

            // Group fields by their parent ID for better organization
            const fieldGroups = {};
            
            Object.entries(formData)
                .filter(([_, value]) => !isEmpty(value))
                .sort(([keyA], [keyB]) => keyA.localeCompare(keyB))
                .forEach(([fieldId, value]) => {
                    if (fieldId.includes('.')) {
                        const [parentId] = fieldId.split('.');
                        if (!fieldGroups[parentId]) {
                            fieldGroups[parentId] = [];
                        }
                        fieldGroups[parentId].push({ fieldId, value });
                    } else {
                        if (!fieldGroups[fieldId]) {
                            fieldGroups[fieldId] = [];
                        }
                        fieldGroups[fieldId].push({ fieldId, value });
                    }
                });

            if (Object.keys(fieldGroups).length === 0) {
                textContent += 'No form data filled yet.\n';
            } else {
                Object.entries(fieldGroups).forEach(([parentId, fields]) => {
                    const parentElement = form.steps
                        .flatMap(step => step.elements)
                        .find(el => el.id === parentId);
                    
                    const isComplexField = fields.length > 1 || 
                        (fields.length === 1 && typeof fields[0].value === 'object' && !fields[0].value.startsWith?.('blob:'));
                    
                    if (isComplexField) {
                        textContent += `📋 ${parentElement?.label || getFieldLabel(parentId)}\n`;
                        textContent += '-'.repeat(40) + '\n';
                        
                        fields.forEach(({ fieldId, value }) => {
                            const label = getFieldLabel(fieldId).replace(`${parentElement?.label || parentId} - `, '');
                            const formattedValue = formatFieldValue(fieldId, value);
                            textContent += `  • ${label}: ${formattedValue.replace(/\n/g, '\n    ')}\n`;
                        });
                        textContent += '\n';
                    } else {
                        fields.forEach(({ fieldId, value }) => {
                            const label = getFieldLabel(fieldId);
                            const formattedValue = formatFieldValue(fieldId, value);
                            textContent += `• ${label}:\n  ${formattedValue.replace(/\n/g, '\n  ')}\n\n`;
                        });
                    }
                });
            }

            const blob = new Blob([textContent], { type: 'text/plain;charset=utf-8' });
            const url = URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.download = `form-data-${form?.name || 'form'}-${new Date().toISOString().split('T')[0]}.txt`;
            link.href = url;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(url);

        } catch (error) {
            console.error('Error downloading text file:', error);
            alert('Failed to download text file. Please try again.');
        }
    };

    // Thank You Modal Component
    const ThankYouModal = () => {
        if (!showThankYou) return null;

        return (
            <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
                <div className="bg-white rounded-lg max-w-md w-full p-6 text-center animate-fade-in">
                    <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <svg className="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                    </div>
                    
                    <h2 className="text-2xl font-bold text-gray-900 mb-2">
                        Thank You!
                    </h2>
                    
                    <p className="text-gray-600 mb-6">
                        Your form has been submitted successfully. We appreciate your time and will get back to you soon.
                    </p>
                    
                    <div className="space-y-3">
                        <button
                            onClick={() => setShowThankYou(false)}
                            className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors"
                        >
                            Close
                        </button>
                        
                        <button
                            onClick={() => {
                                setShowThankYou(false);
                                // Reset form if needed
                                setCurrentStep(0);
                                setFormData({});
                            }}
                            className="w-full bg-gray-200 text-gray-800 py-2 px-4 rounded-md hover:bg-gray-300 focus:outline-none focus:ring-2 focus:ring-gray-500 transition-colors"
                        >
                            Fill Another Form
                        </button>
                    </div>
                </div>
            </div>
        );
    };

    // Render review step with edit functionality
    const renderReviewStep = () => {
        // Group fields by their parent ID for better organization
        const fieldGroups = {};
        
        Object.entries(formData)
            .filter(([_, value]) => !isEmpty(value))
            .sort(([keyA], [keyB]) => keyA.localeCompare(keyB))
            .forEach(([fieldId, value]) => {
                if (fieldId.includes('.')) {
                    const [parentId] = fieldId.split('.');
                    if (!fieldGroups[parentId]) {
                        fieldGroups[parentId] = [];
                    }
                    fieldGroups[parentId].push({ fieldId, value });
                } else {
                    if (!fieldGroups[fieldId]) {
                        fieldGroups[fieldId] = [];
                    }
                    fieldGroups[fieldId].push({ fieldId, value });
                }
            });

        return (
            <div className="bg-white shadow rounded-lg p-6">
                <h2 className="text-2xl font-bold mb-6 text-gray-900">Review Your Information</h2>
                <div className="space-y-6">
                    {Object.keys(fieldGroups).length > 0 ? (
                        Object.entries(fieldGroups).map(([parentId, fields]) => {
                            const parentElement = form.steps
                                .flatMap(step => step.elements)
                                .find(el => el.id === parentId);
                            
                            const isComplexField = fields.length > 1 || 
                                (fields.length === 1 && typeof fields[0].value === 'object' && !fields[0].value.startsWith?.('blob:'));
                            
                            return (
                                <div key={parentId} className="border-b pb-4 last:border-b-0">
                                    {isComplexField ? (
                                        // Render complex field as a group
                                        <div>
                                            <h3 className="font-semibold text-lg mb-3 text-gray-800">
                                                {parentElement?.label || getFieldLabel(parentId)}
                                            </h3>
                                            <div className="space-y-3 ml-4">
                                                {fields.map(({ fieldId, value }) => (
                                                    <div key={fieldId} className="flex flex-col sm:flex-row sm:items-start justify-between">
                                                        <div className="sm:w-1/3 mb-2 sm:mb-0">
                                                            <label className="font-medium text-gray-700 text-sm">
                                                                {getFieldLabel(fieldId).replace(`${parentElement?.label || parentId} - `, '')}
                                                            </label>
                                                        </div>
                                                        
                                                        <div className="sm:w-2/3">
                                                            {editingField === fieldId ? (
                                                                <div className="space-y-2">
                                                                    {renderEditInput(fieldId, value)}
                                                                    <div className="flex space-x-2 mt-2">
                                                                        <button
                                                                            onClick={saveEditing}
                                                                            className="px-3 py-1 bg-green-600 text-white text-sm rounded hover:bg-green-700"
                                                                        >
                                                                            Save
                                                                        </button>
                                                                        <button
                                                                            onClick={cancelEditing}
                                                                            className="px-3 py-1 bg-gray-500 text-white text-sm rounded hover:bg-gray-600"
                                                                        >
                                                                            Cancel
                                                                        </button>
                                                                    </div>
                                                                </div>
                                                            ) : (
                                                                <div className="flex items-center justify-between">
                                                                    <div className="flex-1">
                                                                        {isFileField(fieldId, value) && value ? (
                                                                            renderFilePreview(fieldId, value)
                                                                        ) : (
                                                                            <pre className="text-gray-900 break-words whitespace-pre-wrap font-sans">
                                                                                {formatFieldValue(fieldId, value)}
                                                                            </pre>
                                                                        )}
                                                                    </div>
                                                                    <button
                                                                        onClick={() => startEditing(fieldId, value)}
                                                                        className="flex-shrink-0 ml-4 text-blue-600 hover:text-blue-800 text-sm font-medium"
                                                                        title="Edit this field"
                                                                    >
                                                                        Edit
                                                                    </button>
                                                                </div>
                                                            )}
                                                        </div>
                                                    </div>
                                                ))}
                                            </div>
                                        </div>
                                    ) : (
                                        // Render simple field
                                        fields.map(({ fieldId, value }) => (
                                            <div key={fieldId} className="flex flex-col sm:flex-row sm:items-start justify-between">
                                                <div className="sm:w-1/3 mb-2 sm:mb-0">
                                                    <label className="font-medium text-gray-700 text-sm">
                                                        {getFieldLabel(fieldId)}
                                                    </label>
                                                </div>
                                                
                                                <div className="sm:w-2/3">
                                                    {editingField === fieldId ? (
                                                        <div className="space-y-2">
                                                            {renderEditInput(fieldId, value)}
                                                            <div className="flex space-x-2 mt-2">
                                                                <button
                                                                    onClick={saveEditing}
                                                                    className="px-3 py-1 bg-green-600 text-white text-sm rounded hover:bg-green-700"
                                                                >
                                                                    Save
                                                                </button>
                                                                <button
                                                                    onClick={cancelEditing}
                                                                    className="px-3 py-1 bg-gray-500 text-white text-sm rounded hover:bg-gray-600"
                                                                >
                                                                    Cancel
                                                                </button>
                                                            </div>
                                                        </div>
                                                    ) : (
                                                        <div className="flex items-center justify-between">
                                                            <div className="flex-1">
                                                                {isFileField(fieldId, value) && value ? (
                                                                    renderFilePreview(fieldId, value)
                                                                ) : (
                                                                    <pre className="text-gray-900 break-words whitespace-pre-wrap font-sans">
                                                                        {formatFieldValue(fieldId, value)}
                                                                    </pre>
                                                                )}
                                                            </div>
                                                            <button
                                                                onClick={() => startEditing(fieldId, value)}
                                                                className="flex-shrink-0 ml-4 text-blue-600 hover:text-blue-800 text-sm font-medium"
                                                                title="Edit this field"
                                                            >
                                                                Edit
                                                            </button>
                                                        </div>
                                                    )}
                                                </div>
                                            </div>
                                        ))
                                    )}
                                </div>
                            );
                        })
                    ) : (
                        <div className="text-center py-8">
                            <p className="text-gray-500">No information provided yet.</p>
                        </div>
                    )}
                </div>

                <div className="flex justify-between mt-8">
                    <button
                        type="button"
                        onClick={handlePrevStep}
                        className="px-6 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300 focus:outline-none focus:ring-2 focus:ring-gray-500"
                    >
                        Back to Form
                    </button>
                    
                    <div className="flex space-x-4">
                        <button
                            type="button"
                            onClick={() => {
                                const firstIncompleteStep = form.steps.findIndex((step, index) => {
                                    const hasVisibleFields = step.elements.some(el => elementVisibility[el.id]);
                                    return hasVisibleFields && index < currentStep;
                                });
                                
                                if (firstIncompleteStep !== -1) {
                                    setCurrentStep(firstIncompleteStep);
                                } else {
                                    handlePrevStep();
                                }
                            }}
                            className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        >
                            Edit Form
                        </button>
                        
                        <button
                            type="button"
                           onClick={() => {
  handleSubmit();
  downloadFormAsImage();
}}

                            className="px-6 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500"
                        >
                            Submit Form
                        </button>
                    </div>
                </div>
            </div>
        );
    };

    const renderDescription = (element) => {
        if (element.description) {
            return <p className="mt-1 text-sm text-gray-500">{element.description}</p>;
        }
        return null;
    };

    const renderError = (fieldId) => {
        const error = validationErrors[fieldId];
        if (error) {
            return <p className="mt-1 text-sm text-red-600">{error}</p>;
        }
        return null;
    };

    const renderField = (element) => {
        // Skip rendering if element is hidden
        if (!elementVisibility[element.id]) {
            return null;
        }

        const style = element.styles || {};
        const fieldId = element.id;

        switch (element.type) {
            case "heading":
                const HeadingTag = element.level || "h2";
                return (
                    <div style={style}>
                        <HeadingTag className="font-bold">{element.text}</HeadingTag>
                        {renderDescription(element)}
                    </div>
                );

            case "full-name":
                return (
                    <div style={style}>
                        <label className="block mb-1 font-medium">
                            {element.label}
                            {element.required && <span className="text-red-500 ml-1">*</span>}
                        </label>
                        <input
                            type="text"
                            className="w-full p-2 border rounded"
                            placeholder={element.placeholder}
                            value={formData[fieldId] || ""}
                            onChange={(e) => handleElementChange(fieldId, e.target.value)}
                        />
                        {renderDescription(element)}
                        {renderError(fieldId)}
                    </div>
                );

            case "phone":
                return (
                    <div style={style}>
                        <label className="block mb-1 font-medium">
                            {element.label}
                            {element.required && <span className="text-red-500 ml-1">*</span>}
                        </label>

                        <div className='flex gap-3 items-baseline justify-center'>
                            <div className='w-full'>
                                <input
                                    type="text"
                                    className="w-full p-2 border rounded"
                                    placeholder={element.placeholder}
                                    value={formData[fieldId] || ""}
                                    onChange={(e) => handleElementChange(fieldId, e.target.value)}
                                />

                                {
                                    triggerFuc?.phone && (validtionforemail ? <p className='text-[11px] text-[green]'>Valid Phone Number</p> : <p className='text-[11px] text-[red]'>InValid Phone Number</p>)
                                }
                            </div>

                            <button
                                className="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded shadow-md transition duration-300" onClick={() => {
                                    validPhoneNumber(formData[fieldId])
                                }}
                            >
                                Verify
                            </button>
                        </div>

                        {renderDescription(element)}
                        {renderError(fieldId)}
                    </div>
                );

            case "email":
                return (
                    <div style={style}>
                        <label className="block mb-1 font-medium">
                            {element.label}
                            {element.required && <span className="text-red-500 ml-1">*</span>}
                        </label>

                        <div className='flex gap-3 items-baseline justify-center'>
                            <div className='w-full'>
                                <input
                                    type="text"
                                    className="w-full p-2 border rounded"
                                    placeholder={element.placeholder}
                                    value={formData[fieldId] || ""}
                                    onChange={(e) => handleElementChange(fieldId, e.target.value)}
                                />

                                {
                                    triggerFuc?.email && (validtionforemail ? <p className='text-[11px] text-[green]'>Valid Email</p> : <p className='text-[11px] text-[red]'>InValid Email</p>)
                                }
                            </div>

                            <button
                                className="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded shadow-md transition duration-300" onClick={() => {
                                    valiemailcheck(formData[fieldId])
                                }}
                            >
                                Verify
                            </button>
                        </div>

                        {renderDescription(element)}
                        {renderError(fieldId)}
                    </div>
                );

            case "address":
                return (
                    <div style={style}>
                        <label className="block mb-1 font-medium">
                            {element.label}
                            {element.required && <span className="text-red-500 ml-1">*</span>}
                        </label>
                        <div className="space-y-2">
                            <input
                                type="text"
                                value={formData[`${fieldId}.street1`] || ""}
                                onChange={(e) => handleElementChange(`${fieldId}.street1`, e.target.value)}
                                className="w-full p-2 border rounded"
                                placeholder="Street Address"
                            />
                            <input
                                type="text"
                                value={formData[`${fieldId}.street2`] || ""}
                                onChange={(e) => handleElementChange(`${fieldId}.street2`, e.target.value)}
                                className="w-full p-2 border rounded"
                                placeholder="Street Address Line 2"
                            />
                            <div className="grid grid-cols-2 gap-2">
                                <input
                                    type="text"
                                    value={formData[`${fieldId}.city`] || ""}
                                    onChange={(e) => handleElementChange(`${fieldId}.city`, e.target.value)}
                                    className="p-2 border rounded"
                                    placeholder="City"
                                />
                                <input
                                    type="text"
                                    value={formData[`${fieldId}.state`] || ""}
                                    onChange={(e) => handleElementChange(`${fieldId}.state`, e.target.value)}
                                    className="p-2 border rounded"
                                    placeholder="State/Province"
                                />
                            </div>
                            <input
                                type="text"
                                value={formData[`${fieldId}.postalCode`] || ""}
                                onChange={(e) => handleElementChange(`${fieldId}.postalCode`, e.target.value)}
                                className="w-full p-2 border rounded"
                                placeholder="Postal/Zip Code"
                            />
                        </div>
                        {renderDescription(element)}
                        {renderError(fieldId)}
                    </div>
                );

            case "download-document":
                return (
                    <div style={style}>
                        {element.label && (
                            <label className="block mb-1 font-medium">
                                {element.label}
                            </label>
                        )}
                        {element.document ? (
                            <a
                                href={element.document.url}
                                download={element.document.name}
                                className="inline-block bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded"
                            >
                                {element.buttonText || "Download"}
                            </a>
                        ) : (
                            <div className="text-gray-500 italic">No document uploaded</div>
                        )}
                        {renderDescription(element)}
                    </div>
                );

            case "aadhar":
                return (
                    <div style={style}>
                        <label className="block mb-1 font-medium">
                            {element.label}
                            {element.required && <span className="text-red-500 ml-1">*</span>}
                        </label>
                        <div className="space-y-2">
                            <input
                                type="text"
                                value={formData[`${fieldId}.aadharNumber`] || ""}
                                onChange={(e) => handleElementChange(`${fieldId}.aadharNumber`, e.target.value)}
                                className="w-full p-2 border rounded"
                                placeholder="Aadhar Number (12 digits)"
                                maxLength="12"
                            />
                            
                            <div className="grid grid-cols-2 gap-2">
                                <div>
                                    <label className="block text-sm font-medium mb-1">First Name</label>
                                    <input
                                        type="text"
                                        value={formData[`${fieldId}.firstName`] || ""}
                                        onChange={(e) => handleElementChange(`${fieldId}.firstName`, e.target.value)}
                                        className="w-full p-2 border rounded"
                                        placeholder="First Name"
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium mb-1">Last Name</label>
                                    <input
                                        type="text"
                                        value={formData[`${fieldId}.lastName`] || ""}
                                        onChange={(e) => handleElementChange(`${fieldId}.lastName`, e.target.value)}
                                        className="w-full p-2 border rounded"
                                        placeholder="Last Name"
                                    />
                                </div>
                            </div>

                            <input
                                type="date"
                                value={formData[`${fieldId}.dob`] || ""}
                                onChange={(e) => handleElementChange(`${fieldId}.dob`, e.target.value)}
                                className="w-full p-2 border rounded"
                                placeholder="Date of Birth"
                            />
                            <select
                                value={formData[`${fieldId}.gender`] || ""}
                                onChange={(e) => handleElementChange(`${fieldId}.gender`, e.target.value)}
                                className="w-full p-2 border rounded"
                            >
                                <option value="">Select Gender</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                                <option value="Other">Other</option>
                            </select>
                            <textarea
                                value={formData[`${fieldId}.address`] || ""}
                                onChange={(e) => handleElementChange(`${fieldId}.address`, e.target.value)}
                                className="w-full p-2 border rounded"
                                rows={3}
                                placeholder="Address as on Aadhar"
                            />

                            <div className="grid grid-cols-2 gap-4 mt-4">
                                <div>
                                    <div className="font-medium mb-2">Front Image</div>
                                    {previewUrls[`${fieldId}.frontImage`] || formData[`${fieldId}.frontImage`] ? (
                                        <img
                                            src={previewUrls[`${fieldId}.frontImage`] || formData[`${fieldId}.frontImage`]}
                                            alt="Aadhar Front"
                                            className="w-full h-40 object-contain border rounded-lg"
                                        />
                                    ) : (
                                        <div
                                            className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center text-gray-500 cursor-pointer"
                                            onClick={() => handleUploadButtonClick(`${fieldId}.frontImage`, 'image')}
                                        >
                                            Click to upload front image
                                        </div>
                                    )}
                                </div>

                                <div>
                                    <div className="font-medium mb-2">Back Image</div>
                                    {previewUrls[`${fieldId}.backImage`] || formData[`${fieldId}.backImage`] ? (
                                        <img
                                            src={previewUrls[`${fieldId}.backImage`] || formData[`${fieldId}.backImage`]}
                                            alt="Aadhar Back"
                                            className="w-full h-40 object-contain border rounded-lg"
                                        />
                                    ) : (
                                        <div
                                            className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center text-gray-500 cursor-pointer"
                                            onClick={() => handleUploadButtonClick(`${fieldId}.backImage`, 'image')}
                                        >
                                            Click to upload back image
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>
                        {renderDescription(element)}
                        {renderError(fieldId)}
                    </div>
                );

            case "passport":
                return (
                    <div style={style}>
                        <label className="block mb-1 font-medium">
                            {element.label}
                            {element.required && <span className="text-red-500 ml-1">*</span>}
                        </label>
                        <div className="space-y-2">
                            <input
                                type="text"
                                value={formData[`${fieldId}.passportNumber`] || ""}
                                onChange={(e) => handleElementChange(`${fieldId}.passportNumber`, e.target.value)}
                                className="w-full p-2 border rounded"
                                placeholder="Passport Number"
                            />
                            
                            <div className="grid grid-cols-2 gap-2">
                                <div>
                                    <label className="block text-sm font-medium mb-1">First Name</label>
                                    <input
                                        type="text"
                                        value={formData[`${fieldId}.firstName`] || ""}
                                        onChange={(e) => handleElementChange(`${fieldId}.firstName`, e.target.value)}
                                        className="w-full p-2 border rounded"
                                        placeholder="First Name"
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium mb-1">Last Name</label>
                                    <input
                                        type="text"
                                        value={formData[`${fieldId}.lastName`] || ""}
                                        onChange={(e) => handleElementChange(`${fieldId}.lastName`, e.target.value)}
                                        className="w-full p-2 border rounded"
                                        placeholder="Last Name"
                                    />
                                </div>
                            </div>

                            <input
                                type="text"
                                value={formData[`${fieldId}.nationality`] || ""}
                                onChange={(e) => handleElementChange(`${fieldId}.nationality`, e.target.value)}
                                className="w-full p-2 border rounded"
                                placeholder="Nationality"
                            />
                            <div className="grid grid-cols-2 gap-2">
                                <div>
                                         <label className="block text-sm font-medium mb-1">DOB</label>
                                <input
                                    type="date"
                                    value={formData[`${fieldId}.dob`] || ""}
                                    onChange={(e) => handleElementChange(`${fieldId}.dob`, e.target.value)}
                                    className="p-2 border rounded w-full"
                                    placeholder="Date of Birth"
                                />
                                </div>
                               
                                <div>
                                     <label className="block text-sm font-medium mb-1">PlaceOfBirth</label>
                                <input
                                    type="text"
                                    value={formData[`${fieldId}.placeOfBirth`] || ""}
                                    onChange={(e) => handleElementChange(`${fieldId}.placeOfBirth`, e.target.value)}
                                    className="p-2 border rounded w-full"
                                    placeholder="Place of Birth"
                                />
                                </div>
                                
                            </div>
                            <div className="grid grid-cols-2 gap-2">
                                    <div>
                                         <label className="block text-sm font-medium mb-1">IssueDate</label>
                                           <input
                                    type="date"
                                    value={formData[`${fieldId}.issueDate`] || ""}
                                    onChange={(e) => handleElementChange(`${fieldId}.issueDate`, e.target.value)}
                                    className="p-2 border rounded w-full"
                                    placeholder="Issue Date"
                                />
                                    </div>
                                
                                <div className=''>
                                     <label className="block text-sm font-medium mb-1">ExpiryDate</label>
                                         <input
                                    type="date"
                                    value={formData[`${fieldId}.expiryDate`] || ""}
                                    onChange={(e) => handleElementChange(`${fieldId}.expiryDate`, e.target.value)}
                                    className="p-2 border rounded w-full"
                                    placeholder="Expiry Date"
                                />
                                </div>
                               
                            </div>

                            <div className="grid grid-cols-2 gap-4 mt-4">
                                <div>
                                    <div className="font-medium mb-2">Front Image</div>
                                    {previewUrls[`${fieldId}.frontImage`] || formData[`${fieldId}.frontImage`] ? (
                                        <img
                                            src={previewUrls[`${fieldId}.frontImage`] || formData[`${fieldId}.frontImage`]}
                                            alt="Passport Front"
                                            className="w-full h-40 object-contain border rounded-lg"
                                        />
                                    ) : (
                                        <div
                                            className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center text-gray-500 cursor-pointer"
                                            onClick={() => handleUploadButtonClick(`${fieldId}.frontImage`, 'image')}
                                        >
                                            Click to upload front image
                                        </div>
                                    )}
                                </div>

                                <div>
                                    <div className="font-medium mb-2">Back Image</div>
                                    {previewUrls[`${fieldId}.backImage`] || formData[`${fieldId}.backImage`] ? (
                                        <img
                                            src={previewUrls[`${fieldId}.backImage`] || formData[`${fieldId}.backImage`]}
                                            alt="Passport Back"
                                            className="w-full h-40 object-contain border rounded-lg"
                                        />
                                    ) : (
                                        <div
                                            className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center text-gray-500 cursor-pointer"
                                            onClick={() => handleUploadButtonClick(`${fieldId}.backImage`, 'image')}
                                        >
                                            Click to upload back image
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>
                        {renderDescription(element)}
                        {renderError(fieldId)}
                    </div>
                );

            case "dropdown":
                return (
                    <div style={style}>
                        <label className="block mb-1 font-medium">
                            {element.label}
                            {element.required && <span className="text-red-500 ml-1">*</span>}
                        </label>
                        <select
                            className="w-full p-2 border rounded"
                            value={formData[fieldId] || ""}
                            onChange={(e) => handleElementChange(fieldId, e.target.value)}
                        >
                            <option value="">Select an option</option>
                            {element.options?.map((option, idx) => (
                                <option key={idx} value={option}>{option}</option>
                            ))}
                        </select>
                        {renderDescription(element)}
                        {renderError(fieldId)}
                    </div>
                );

            case "single-choice":
                return (
                    <div style={style}>
                        <label className="block mb-1 font-medium">
                            {element.label}
                            {element.required && <span className="text-red-500 ml-1">*</span>}
                        </label>
                        <div className="space-y-2">
                            {element.options?.map((option, idx) => (
                                <div key={idx} className="flex items-center">
                                    <input
                                        type="radio"
                                        name={`radio-${fieldId}`}
                                        className="mr-2"
                                        checked={formData[fieldId] === option}
                                        onChange={() => handleElementChange(fieldId, option)}
                                    />
                                    <span>{option}</span>
                                </div>
                            ))}
                        </div>
                        {renderDescription(element)}
                        {renderError(fieldId)}
                    </div>
                );

            case "multiple-choice":
                return (
                    <div style={style}>
                        <label className="block mb-1 font-medium">
                            {element.label}
                            {element.required && <span className="text-red-500 ml-1">*</span>}
                        </label>
                        <div className="space-y-2">
                            {element.options?.map((option, idx) => (
                                <div key={idx} className="flex items-center">
                                    <input
                                        type="checkbox"
                                        className="mr-2"
                                        checked={formData[fieldId]?.includes(option) || false}
                                        onChange={(e) => {
                                            const selected = formData[fieldId] || [];
                                            const newSelected = e.target.checked
                                                ? [...selected, option]
                                                : selected.filter(opt => opt !== option);
                                            handleElementChange(fieldId, newSelected);
                                        }}
                                    />
                                    <span>{option}</span>
                                </div>
                            ))}
                        </div>
                        {renderDescription(element)}
                        {renderError(fieldId)}
                    </div>
                );

            case "paragraph":
                return (
                    <div style={style}>
                        <p className="text-gray-700">{element.content}</p>
                        {renderDescription(element)}
                    </div>
                );

            case "date":
                return (
                    <div style={style}>
                        <label className="block mb-1 font-medium">
                            {element.label}
                            {element.required && <span className="text-red-500 ml-1">*</span>}
                        </label>
                        <input
                            type="date"
                            value={formData[fieldId] || ""}
                            onChange={(e) => handleElementChange(fieldId, e.target.value)}
                            className="w-full p-2 border rounded"
                        />
                        {renderDescription(element)}
                        {renderError(fieldId)}
                    </div>
                );

            case "time":
                return (
                    <div style={style}>
                        <label className="block mb-1 font-medium">
                            {element.label}
                            {element.required && <span className="text-red-500 ml-1">*</span>}
                        </label>
                        <input
                            type="time"
                            value={formData[fieldId] || ""}
                            onChange={(e) => handleElementChange(fieldId, e.target.value)}
                            className="w-full p-2 border rounded"
                        />
                        {renderDescription(element)}
                        {renderError(fieldId)}
                    </div>
                );

            case "signature":
                return (
                    <div style={style}>
                        <label className="block mb-1 font-medium">
                            {element.label}
                            {element.required && <span className="text-red-500 ml-1">*</span>}
                        </label>
                        <SignaturePad 
                            fieldId={fieldId}
                            onSave={(signatureData) => handleElementChange(fieldId, signatureData)}
                            currentSignature={formData[fieldId]}
                        />
                        {renderDescription(element)}
                        {renderError(fieldId)}
                    </div>
                );

            case "file-upload":
                return (
                    <div style={style}>
                        <label className="block mb-1 font-medium">
                            {element.label}
                            {element.required && <span className="text-red-500 ml-1">*</span>}
                        </label>
                        <input
                            type="file"
                            ref={fileInputRef}
                            onChange={(e) => handleFileUpload(e, fieldId, 'file')}
                            className="hidden"
                        />
                        {formData[fieldId] ? (
                            <div className="border-2 border-dashed border-gray-300 rounded-lg p-4">
                                <div className="flex items-center justify-between">
                                    <span className="truncate">
                                        {formData[fieldId].name || 'Uploaded file'}
                                    </span>
                                    <span className="text-green-500 ml-2">✓</span>
                                </div>
                                <button
                                    onClick={() => handleElementChange(fieldId, null)}
                                    className="mt-2 w-full bg-red-500 hover:bg-red-600 text-white py-1 rounded"
                                >
                                    Remove File
                                </button>
                        </div>
                        ) : (
                            <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center">
                                <div className="text-gray-500 mb-2">No file chosen</div>
                                <button
                                    className="bg-gray-100 hover:bg-gray-200 px-4 py-2 rounded text-sm"
                                    onClick={() => handleUploadButtonClick(fieldId, 'file')}
                                >
                                    Choose File
                                </button>
                            </div>
                        )}
                        {renderDescription(element)}
                        {renderError(fieldId)}
                    </div>
                );

            case "star-rating":
                return (
                    <div style={style}>
                        <label className="block mb-1 font-medium">
                            {element.label}
                            {element.required && <span className="text-red-500 ml-1">*</span>}
                        </label>
                        <div className="flex items-center">
                            {[...Array(element.maxRating || 5)].map((_, i) => (
                                <button
                                    key={i}
                                    onClick={() => handleElementChange(fieldId, { rating: i + 1 })}
                                    className="text-2xl mr-1 cursor-pointer"
                                >
                                    {i < (formData[fieldId]?.rating || 0) ? "★" : "☆"}
                                </button>
                            ))}
                        </div>
                        {renderDescription(element)}
                        {renderError(fieldId)}
                    </div>
                );

            case "scale-rating":
                return (
                    <div style={style}>
                        <label className="block mb-1 font-medium">
                            {element.label}
                            {element.required && <span className="text-red-500 ml-1">*</span>}
                        </label>
                        <div className="flex items-center justify-between">
                            <span>{element.min || 1}</span>
                            <input
                                type="range"
                                min={element.min || 1}
                                max={element.max || 10}
                                value={formData[fieldId]?.value || 5}
                                onChange={(e) =>
                                    handleElementChange(fieldId, { value: parseInt(e.target.value) })
                                }
                                className="w-full mx-2"
                            />
                            <span>{element.max || 10}</span>
                        </div>
                        <div className="text-center mt-1">{formData[fieldId]?.value || 5}</div>
                        {renderDescription(element)}
                        {renderError(fieldId)}
                    </div>
                );

            case "banner":
                return (
                    <div style={style}>
                        <label className="block mb-1 font-medium">{element.label}</label>
                        {previewUrls[fieldId] || formData[fieldId] ? (
                            <div className="relative">
                                <img
                                    src={previewUrls[fieldId] || formData[fieldId]}
                                    alt="Banner"
                                    className="w-full object-cover rounded-lg"
                                    style={{ height: `${element.height}px` }}
                                />
                            </div>
                        ) : (
                            <div
                                className="border-2 border-dashed border-gray-300 rounded-lg flex items-center justify-center cursor-pointer"
                                style={{ height: `${element.height}px` }}
                                onClick={() => handleUploadButtonClick(fieldId, 'image')}
                            >
                                <span className="text-gray-500">Upload banner</span>
                            </div>
                        )}
                        {renderDescription(element)}
                    </div>
                );

            case "hyperlink":
                return (
                    <div style={style}>
                        <a
                            href={element.url}
                            target={element.openInNewTab ? "_blank" : "_self"}
                            rel="noopener noreferrer"
                            className="text-blue-600 hover:text-blue-800 hover:underline"
                        >
                            {element.text}
                        </a>
                        {renderDescription(element)}
                    </div>
                );

            case "image-gallery":
                return (
                    <div style={style}>
                        {element.label && (
                            <label className="block mb-1 font-medium">
                                {element.label}
                            </label>
                        )}

                        {element.layout === "grid" ? (
                            <div className={`grid gap-4`} style={{ gridTemplateColumns: `repeat(${element.columns}, 1fr)` }}>
                                {element.images?.map((img, idx) => (
                                    <img
                                        key={idx}
                                        src={img.url}
                                        alt={img.name}
                                        className="w-full h-auto object-contain rounded"
                                    />
                                ))}
                            </div>
                        ) : (
                            <div className="relative overflow-hidden">
                                <div className="flex overflow-x-auto space-x-4 py-2 scrollbar-hide">
                                    {element.images?.map((img, idx) => (
                                        <img
                                            key={idx}
                                            src={img.url}
                                            alt={img.name}
                                            className="h-48 w-auto object-contain rounded"
                                        />
                                    ))}
                                </div>
                            </div>
                        )}
                        {renderDescription(element)}
                    </div>
                );

            case "divider":
                return (
                    <div className="relative my-6" style={style}>
                        <hr className="border-t-2 border-gray-300" />
                        {element.description && (
                            <div className="text-xs text-gray-500 mt-1 text-center">
                                {element.description}
                            </div>
                        )}
                    </div>
                );

            case "nearest-airport":
                return (
                    <div style={style}>
                        <label className="block mb-1 font-medium">
                            {element.label}
                            {element.required && <span className="text-red-500 ml-1">*</span>}
                        </label>

                        <div className="mb-3">
                            <label className="block text-sm font-medium mb-1">Enter Location</label>
                            <div className="flex gap-2">
                                <input
                                    type="text"
                                    value={formData[`${fieldId}.address`] || ""}
                                    onChange={(e) => handleElementChange(`${fieldId}.address`, e.target.value)}
                                    className="flex-1 p-2 border rounded"
                                    placeholder="Enter city, address, or landmark"
                                />
                                <button
                                    type="button"
                                    onClick={() => handleSearch(formData[`${fieldId}.address`], fieldId)}
                                    disabled={searchingAirport || !formData[`${fieldId}.address`]}
                                    className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:bg-gray-400"
                                >
                                    {searchingAirport ? 'Searching...' : 'Find Airport'}
                                </button>
                            </div>
                            {airportError && (
                                <p className="mt-1 text-sm text-red-600">{airportError}</p>
                            )}
                        </div>

                        <div className="mb-3">
                            <label className="block text-sm font-medium mb-1">Nearest Airport</label>
                            <input
                                type="text"
                                value={formData[`${fieldId}.selectedAirport`] || ""}
                                onChange={(e) => handleElementChange(`${fieldId}.selectedAirport`, e.target.value)}
                                className="w-full p-2 border rounded"
                                placeholder="Airport will be auto-filled"
                                readOnly={!!formData[`${fieldId}.selectedAirport`]}
                            />
                        </div>

                        <div className="mb-3">
                            <label className="block text-sm font-medium mb-1">Airport Code</label>
                            <input
                                type="text"
                                value={formData[`${fieldId}.airportCode`] || ""}
                                onChange={(e) => handleElementChange(`${fieldId}.airportCode`, e.target.value)}
                                className="w-full p-2 border rounded"
                                placeholder="Code will be auto-filled"
                                readOnly={!!formData[`${fieldId}.airportCode`]}
                            />
                        </div>

                        <div className="mb-3">
                            <label className="block text-sm font-medium mb-1">Distance (KM)</label>
                            <input
                                type="number"
                                value={formData[`${fieldId}.distanceKm`] || ""}
                                onChange={(e) => handleElementChange(`${fieldId}.distanceKm`, e.target.value)}
                                className="w-full p-2 border rounded"
                                placeholder="Distance will be calculated"
                                readOnly={!!formData[`${fieldId}.distanceKm`]}
                            />
                        </div>

                        {/* {nearestAirportData[fieldId] && (
                            <div className="mt-4 p-3 bg-gray-50 rounded-lg">
                                <h4 className="font-medium text-sm mb-2">Airport Details:</h4>
                                <p className="text-sm">
                                    <strong>Name:</strong> {nearestAirportData[fieldId].name}<br/>
                                    <strong>IATA:</strong> {nearestAirportData[fieldId].iataCode}<br/>
                                    <strong>City:</strong> {nearestAirportData[fieldId].municipality}<br/>
                                    <strong>Country:</strong> {nearestAirportData[fieldId].countryCode}
                                </p>
                            </div>
                        )} */}

                        {renderDescription(element)}
                        {renderError(fieldId)}
                    </div>
                );

            case "ocr-aadhar":
                return (
                    <div style={style}>
                        <label className="block mb-1 font-medium">
                            {element.label}
                            {element.required && <span className="text-red-500 ml-1">*</span>}
                        </label>

                        <div className="grid grid-cols-2 gap-4 mt-4">
                            <div>
                                <div className="font-medium mb-2">Front Image (OCR)</div>
                                {previewUrls[`${fieldId}.frontImage`] || formData[`${fieldId}.frontImage`] ? (
                                    <div className="relative">
                                        <img
                                            src={previewUrls[`${fieldId}.frontImage`] || formData[`${fieldId}.frontImage`]}
                                            alt="Aadhar Front"
                                            className="w-full h-40 object-contain border rounded-lg"
                                        />
                                        {ocrProcessing[`${fieldId}.frontImage`] && (
                                            <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
                                                <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-white"></div>
                                                <span className="ml-3 text-white">Processing...</span>
                                            </div>
                                        )}
                                    </div>
                                ) : (
                                    <div
                                        className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center text-gray-500 cursor-pointer"
                                        onClick={() => handleUploadButtonClick(`${fieldId}.frontImage`, 'image')}
                                    >
                                        Click to upload front image
                                    </div>
                                )}
                            </div>

                            <div>
                                <div className="font-medium mb-2">Back Image (OCR)</div>
                                {previewUrls[`${fieldId}.backImage`] || formData[`${fieldId}.backImage`] ? (
                                    <div className="relative">
                                        <img
                                            src={previewUrls[`${fieldId}.backImage`] || formData[`${fieldId}.backImage`]}
                                            alt="Aadhar Back"
                                            className="w-full h-40 object-contain border rounded-lg"
                                        />
                                        {ocrProcessing[`${fieldId}.backImage`] && (
                                            <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
                                                <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-white"></div>
                                                <span className="ml-3 text-white">Processing...</span>
                                            </div>
                                        )}
                                    </div>
                                ) : (
                                    <div
                                        className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center text-gray-500 cursor-pointer"
                                        onClick={() => handleUploadButtonClick(`${fieldId}.backImage`, 'image')}
                                    >
                                        Click to upload back image
                                    </div>
                                )}
                            </div>
                        </div>

                        <div className="mt-4 space-y-2">
                            <input
                                type="text"
                                value={formData[`${fieldId}.aadharNumber`] || ""}
                                onChange={(e) => handleElementChange(`${fieldId}.aadharNumber`, e.target.value)}
                                className="w-full p-2 border rounded"
                                placeholder="Aadhar Number (auto-filled by OCR)"
                            />
                            <input
                                type="text"
                                value={formData[`${fieldId}.name`] || ""}
                                onChange={(e) => handleElementChange(`${fieldId}.name`, e.target.value)}
                                className="w-full p-2 border rounded"
                                placeholder="Name (auto-filled by OCR)"
                            />
                            <input
                                type="date"
                                value={formData[`${fieldId}.dob`] || ""}
                                onChange={(e) => handleElementChange(`${fieldId}.dob`, e.target.value)}
                                className="w-full p-2 border rounded"
                                placeholder="Date of Birth (auto-filled by OCR)"
                            />
                            <input
                                type="text"
                                value={formData[`${fieldId}.gender`] || ""}
                                onChange={(e) => handleElementChange(`${fieldId}.gender`, e.target.value)}
                                className="w-full p-2 border rounded"
                                placeholder="Gender (auto-filled by OCR)"
                            />
                            <textarea
                                value={formData[`${fieldId}.address`] || ""}
                                onChange={(e) => handleElementChange(`${fieldId}.address`, e.target.value)}
                                className="w-full p-2 border rounded"
                                rows={3}
                                placeholder="Address (auto-filled by OCR)"
                            />

                            <div className="border-t pt-4 mt-4">
                                <h4 className="font-medium text-gray-700 mb-3">Back Side Details (Optional)</h4>
                                <input
                                    type="text"
                                    value={formData[`${fieldId}.relativeName`] || ""}
                                    onChange={(e) => handleElementChange(`${fieldId}.relativeName`, e.target.value)}
                                    className="w-full p-2 border rounded"
                                    placeholder="Father's/Husband's Name (auto-filled by OCR)"
                                />
                                <input
                                    type="text"
                                    value={formData[`${fieldId}.pinCode`] || ""}
                                    onChange={(e) => handleElementChange(`${fieldId}.pinCode`, e.target.value)}
                                    className="w-full p-2 border rounded"
                                    placeholder="PIN Code (auto-filled by OCR)"
                                />
                                <input
                                    type="text"
                                    value={formData[`${fieldId}.houseNumber`] || ""}
                                    onChange={(e) => handleElementChange(`${fieldId}.houseNumber`, e.target.value)}
                                    className="w-full p-2 border rounded"
                                    placeholder="House Number (auto-filled by OCR)"
                                />
                                <input
                                    type="text"
                                    value={formData[`${fieldId}.area`] || ""}
                                    onChange={(e) => handleElementChange(`${fieldId}.area`, e.target.value)}
                                    className="w-full p-2 border rounded"
                                    placeholder="Area/Locality (auto-filled by OCR)"
                                />
                                <input
                                    type="text"
                                    value={formData[`${fieldId}.city`] || ""}
                                    onChange={(e) => handleElementChange(`${fieldId}.city`, e.target.value)}
                                    className="w-full p-2 border rounded"
                                    placeholder="City/District (auto-filled by OCR)"
                                />
                                <input
                                    type="text"
                                    value={formData[`${fieldId}.state`] || ""}
                                    onChange={(e) => handleElementChange(`${fieldId}.state`, e.target.value)}
                                    className="w-full p-2 border rounded"
                                    placeholder="State (auto-filled by OCR)"
                                />
                            </div>
                        </div>

                        {renderDescription(element)}
                        {renderError(fieldId)}
                    </div>
                );

            case "ocr-passport":
            case "ocr-password":
                return (
                    <div style={style}>
                        <label className="block mb-1 font-medium">
                            {element.label}
                            {element.required && <span className="text-red-500 ml-1">*</span>}
                        </label>

                        <div className="mb-4 p-3 bg-blue-50 rounded-lg">
                            <p className="text-sm text-blue-700">
                                <strong>Tip:</strong> Upload clear images of both front and back pages
                            </p>
                        </div>

                        <div className="grid grid-cols-2 gap-4 mt-4">
                            <div>
                                <div className="font-medium mb-2">Front Page (Photo Page)</div>
                                {previewUrls[`${fieldId}.frontImage`] || formData[`${fieldId}.frontImage`] ? (
                                    <div className="relative">
                                        <img
                                            src={previewUrls[`${fieldId}.frontImage`] || formData[`${fieldId}.frontImage`]}
                                            alt="Document Front"
                                            className="w-full h-40 object-contain border rounded-lg"
                                        />
                                        {ocrProcessing[`${fieldId}.frontImage`] && (
                                            <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
                                                <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-white"></div>
                                                <span className="ml-3 text-white">Processing...</span>
                                            </div>
                                        )}
                                    </div>
                                ) : (
                                    <div
                                        className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center text-gray-500 cursor-pointer hover:border-blue-400 hover:bg-blue-50 transition-colors"
                                        onClick={() => handleUploadButtonClick(`${fieldId}.frontImage`, 'image')}
                                    >
                                        <div className="text-2xl mb-2">📷</div>
                                        <div className="text-sm">Click to upload front page</div>
                                    </div>
                                )}
                            </div>

                            <div>
                                <div className="font-medium mb-2">Back Page (Family Details)</div>
                                {previewUrls[`${fieldId}.backImage`] || formData[`${fieldId}.backImage`] ? (
                                    <div className="relative">
                                        <img
                                            src={previewUrls[`${fieldId}.backImage`] || formData[`${fieldId}.backImage`]}
                                            alt="Document Back"
                                            className="w-full h-40 object-contain border rounded-lg"
                                        />
                                        {ocrProcessing[`${fieldId}.backImage`] && (
                                            <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
                                                <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-white"></div>
                                                <span className="ml-3 text-white">Processing...</span>
                                            </div>
                                        )}
                                    </div>
                                ) : (
                                    <div
                                        className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center text-gray-500 cursor-pointer hover:border-blue-400 hover:bg-blue-50 transition-colors"
                                        onClick={() => handleUploadButtonClick(`${fieldId}.backImage`, 'image')}
                                    >
                                        <div className="text-2xl mb-2">📷</div>
                                        <div className="text-sm">Click to upload back page</div>
                                    </div>
                                )}
                            </div>
                        </div>

                        {/* FRONT SIDE FIELDS */}
                        <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label className="block text-sm font-medium mb-1">Passport Number</label>
                                <input
                                    type="text"
                                    value={formData[`${fieldId}.passportNumber`] || ""}
                                    onChange={(e) => handleElementChange(`${fieldId}.passportNumber`, e.target.value)}
                                    className="w-full p-2 border rounded"
                                    placeholder="Auto-filled from OCR"
                                />
                            </div>

                            <div>
                                <label className="block text-sm font-medium mb-1">Full Name</label>
                                <input
                                    type="text"
                                    value={formData[`${fieldId}.fullName`] || ""}
                                    onChange={(e) => handleElementChange(`${fieldId}.fullName`, e.target.value)}
                                    className="w-full p-2 border rounded"
                                    placeholder="Auto-filled from OCR"
                                />
                            </div>

                            <div>
                                <label className="block text-sm font-medium mb-1">Nationality</label>
                                <input
                                    type="text"
                                    value={formData[`${fieldId}.nationality`] || ""}
                                    onChange={(e) => handleElementChange(`${fieldId}.nationality`, e.target.value)}
                                    className="w-full p-2 border rounded"
                                    placeholder="Auto-filled from OCR"
                                />
                            </div>

                            <div>
                                <label className="block text-sm font-medium mb-1">Date of Birth</label>
                                <input
                                    type="date"
                                    value={formData[`${fieldId}.dob`] || ""}
                                    onChange={(e) => handleElementChange(`${fieldId}.dob`, e.target.value)}
                                    className="w-full p-2 border rounded"
                                    placeholder="Auto-filled from OCR"
                                />
                            </div>

                            <div>
                                <label className="block text-sm font-medium mb-1">Place of Birth</label>
                                <input
                                    type="text"
                                    value={formData[`${fieldId}.placeOfBirth`] || ""}
                                    onChange={(e) => handleElementChange(`${fieldId}.placeOfBirth`, e.target.value)}
                                    className="w-full p-2 border rounded"
                                    placeholder="Auto-filled from OCR"
                                />
                            </div>

                            <div>
                                <label className="block text-sm font-medium mb-1">Gender</label>
                                <select
                                    value={formData[`${fieldId}.gender`] || ""}
                                    onChange={(e) => handleElementChange(`${fieldId}.gender`, e.target.value)}
                                    className="w-full p-2 border rounded"
                                >
                                    <option value="">Select Gender</option>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                    <option value="Other">Other</option>
                                </select>
                            </div>

                            <div>
                                <label className="block text-sm font-medium mb-1">Place of Issue</label>
                                <input
                                    type="text"
                                    value={formData[`${fieldId}.placeOfIssue`] || ""}
                                    onChange={(e) => handleElementChange(`${fieldId}.placeOfIssue`, e.target.value)}
                                    className="w-full p-2 border rounded"
                                    placeholder="Auto-filled from OCR"
                                />
                            </div>

                            <div>
                                <label className="block text-sm font-medium mb-1">Date of Issue</label>
                                <input
                                    type="date"
                                    value={formData[`${fieldId}.issueDate`] || ""}
                                    onChange={(e) => handleElementChange(`${fieldId}.issueDate`, e.target.value)}
                                    className="w-full p-2 border rounded"
                                    placeholder="Auto-filled from OCR"
                                />
                            </div>

                            <div>
                                <label className="block text-sm font-medium mb-1">Date of Expiry</label>
                                <input
                                    type="date"
                                    value={formData[`${fieldId}.expiryDate`] || ""}
                                    onChange={(e) => handleElementChange(`${fieldId}.expiryDate`, e.target.value)}
                                    className="w-full p-2 border rounded"
                                    placeholder="Auto-filled from OCR"
                                />
                            </div>
                        </div>

                        {/* BACK SIDE FIELDS */}
                        <div className="mt-8 pt-6 border-t">
                            <h3 className="text-lg font-medium mb-4">Family Details (Back Page)</h3>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-sm font-medium mb-1">Father's Name</label>
                                    <input
                                        type="text"
                                        value={formData[`${fieldId}.fatherName`] || ""}
                                        onChange={(e) => handleElementChange(`${fieldId}.fatherName`, e.target.value)}
                                        className="w-full p-2 border rounded"
                                        placeholder="Auto-filled from OCR"
                                    />
                                </div>

                                <div>
                                    <label className="block text-sm font-medium mb-1">Mother's Name</label>
                                    <input
                                        type="text"
                                        value={formData[`${fieldId}.motherName`] || ""}
                                        onChange={(e) => handleElementChange(`${fieldId}.motherName`, e.target.value)}
                                        className="w-full p-2 border rounded"
                                        placeholder="Auto-filled from OCR"
                                    />
                                </div>

                                <div>
                                    <label className="block text-sm font-medium mb-1">Spouse Name</label>
                                    <input
                                        type="text"
                                        value={formData[`${fieldId}.spouseName`] || ""}
                                        onChange={(e) => handleElementChange(`${fieldId}.spouseName`, e.target.value)}
                                        className="w-full p-2 border rounded"
                                        placeholder="Auto-filled from OCR"
                                    />
                                </div>

                                <div>
                                    <label className="block text-sm font-medium mb-1">PIN Code</label>
                                    <input
                                        type="text"
                                        value={formData[`${fieldId}.pinCode`] || ""}
                                        onChange={(e) => handleElementChange(`${fieldId}.pinCode`, e.target.value)}
                                        className="w-full p-2 border rounded"
                                        placeholder="Auto-filled from OCR"
                                        maxLength="6"
                                    />
                                </div>

                                <div className="md:col-span-2">
                                    <label className="block text-sm font-medium mb-1">Address</label>
                                    <textarea
                                        value={formData[`${fieldId}.address`] || ""}
                                        onChange={(e) => handleElementChange(`${fieldId}.address`, e.target.value)}
                                        className="w-full p-2 border rounded"
                                        rows="3"
                                        placeholder="Auto-filled from OCR"
                                    />
                                </div>

                                <div>
                                    <label className="block text-sm font-medium mb-1">Old Passport Number</label>
                                    <input
                                        type="text"
                                        value={formData[`${fieldId}.oldPassportNumber`] || ""}
                                        onChange={(e) => handleElementChange(`${fieldId}.oldPassportNumber`, e.target.value)}
                                        className="w-full p-2 border rounded"
                                        placeholder="Auto-filled from OCR"
                                    />
                                </div>
                            </div>
                        </div>

                        {renderDescription(element)}
                        {renderError(fieldId)}
                    </div>
                );

            default:
                return (
                    <div style={style}>
                        <div>{element.label}</div>
                        {renderDescription(element)}
                    </div>
                );
        }
    };

    if (loading) return (
        <div className="flex justify-center items-center h-screen">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
        </div>
    );

    if (error) return (
        <div className="max-w-md mx-auto mt-10 p-4 bg-red-100 border-l-4 border-red-500 text-red-700">
            <p className="font-bold">Error</p>
            <p>{error}</p>
        </div>
    );

    if (!form) return (
        <div className="max-w-md mx-auto mt-10 p-4 bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700">
            <p>Form not found</p>
        </div>
    );

    return (
        <>
            <div 
                ref={formContainerRef}
                className="max-w-2xl mx-auto p-4 md:p-6 lg:p-8"
            >
                <div className="text-center mb-8">
                    <h1 className="text-2xl md:text-3xl font-bold text-gray-900">{form.name}</h1>
                </div>

                {/* Stepper */}
                <div className="relative mb-8">
                    <div className="flex items-center justify-between">
                        {stepsWithReview.map((step, index) => (
                            <React.Fragment key={step.id}>
                                <div className="flex flex-col items-center">
                                    <div
                                        className={`flex items-center justify-center w-10 h-10 rounded-full border-2 
                                                ${index < currentStep ? 'bg-green-500 border-green-500 text-white' :
                                                index === currentStep ? 'border-blue-500 bg-white text-blue-500' :
                                                    'border-gray-300 bg-white text-gray-400'}`}
                                    >
                                        {index + 1}
                                    </div>
                                    <div
                                        className={`mt-2 text-xs font-medium text-center max-w-20
                                                ${index <= currentStep ? 'text-gray-900' : 'text-gray-400'}`}
                                    >
                                        {step.type === 'review' ? 'Review' : step.name}
                                    </div>
                                </div>
                                {index < stepsWithReview.length - 1 && (
                                    <div className={`flex-auto border-t-2 ${index < currentStep ? 'border-green-500' : 'border-gray-300'}`}></div>
                                )}
                            </React.Fragment>
                        ))}
                    </div>
                </div>

                {/* Current Step Content */}
                {currentStep === stepsWithReview.length - 1 ? (
                    renderReviewStep()
                ) : (
                    <div className="bg-white shadow rounded-lg p-6 mb-6">
                        <div className="space-y-4">
                            {form.steps[currentStep].elements.map(renderField)}
                        </div>

                        {/* Navigation Buttons */}
                        <div className="flex justify-between mt-8">
                            {currentStep > 0 && (
                                <button
                                    type="button"
                                    onClick={handlePrevStep}
                                    className="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300 focus:outline-none focus:ring-2 focus:ring-gray-500"
                                >
                                    Previous
                                </button>
                            )}

                            <button
                                type="button"
                                onClick={handleNextStep}
                                className="ml-auto px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                            >
                                {currentStep === form.steps.length - 1 ? 'Review' : 'Next'}
                            </button>
                        </div>
                    </div>
                )}
            </div>

            {/* Thank You Modal */}
            <ThankYouModal />
        </>
    );
};

export default SharedFormViewer;