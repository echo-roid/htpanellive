// src/pages/LeadPage.jsx
import React, { useState } from "react";
import Tabs from "./Tabs";

const InsideLeadPage = () => {
     const [activeTab, setActiveTab] = useState("");

   

  const tabs = [
    { value: "Dashboard", label: "Dashboard" },
    { value: "Cost Sheet", label: "Cost Sheet" },
    { value: "Profile", label: "Profile" },
    { value: "Itinerary", label: "Itinerary" },
    { value: "Conversation", label: "Conversation" },
    { value: "Task", label: "Task" },
    { value: "Activity", label: "Activity" },
       { value: "Documents", label: "Documents" },
    { value: "Guest List", label: "Guest List" },
    { value: "Master Data", label: "Master Data" },
   
  ];

  return (
    <>
          <h2 className="text-2xl font-bold mb-6 text-[#3f8cff]">Lead Page</h2>
           <div className="p-6 bg-white min-h-screen">
       <div className="bg-white rounded-md shadow overflow-hidden">
        <div className="flex flex-wrap">
          {tabs.map(tab => (
            <button
              key={tab.value}
              className={`flex-1 py-3 text-sm font-medium text-center ${
                activeTab === tab.value ? 'bg-blue-600 text-white' : 'text-gray-700 hover:bg-gray-100'
              }`}
              onClick={() => setActiveTab(tab.value)}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

    </div>
    </>
   
  );
};

export default InsideLeadPage;
