import React, { useState, useEffect } from "react";
import { MoreVertical, Edit, Trash2, Search, Filter, Plus } from "lucide-react";
import * as api from "../../api/Companie";
import { Link } from "react-router-dom";
import { v4 as uuidv4 } from 'uuid';
import * as apii from "../../api/services";

const COMPANY_API_URL = "http://localhost:5000/api/contacts";

const CompaniesPage = () => {
  const [companies, setCompanies] = useState([]);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  
  // Form data with all possible fields
  const [formData, setFormData] = useState({
    clientName: "",
    email: "",
    panNumber: "",
    address: "",
    pinCode: "",
    state: "",
    clientType: "",
    contactPerson: "",
    contactNumber: "",
    // Company-specific fields (initially empty)
    cinNumber: "",
    website: "",
    industryType: "",
    businessType: "",
    contracts: "",
    relationManager: "",
    client_code: "",
    status: "Active"
  });
  
  const [editingId, setEditingId] = useState(null);
  
  // States for contact person dropdown
  const [contactsList, setContactsList] = useState([]);
  const [filteredContacts, setFilteredContacts] = useState([]);
  const [showContactDropdown, setShowContactDropdown] = useState(false);
  const [contactSearch, setContactSearch] = useState("");
  const [loadingContacts, setLoadingContacts] = useState(false);
  const [contactError, setContactError] = useState(null);

  // States for relation manager dropdown
  const [relationManagersList, setRelationManagersList] = useState([]);
  const [filteredRelationManagers, setFilteredRelationManagers] = useState([]);
  const [showRelationManagerDropdown, setShowRelationManagerDropdown] = useState(false);
  const [relationManagerSearch, setRelationManagerSearch] = useState("");
  const [loadingRelationManagers, setLoadingRelationManagers] = useState(false);
  const [relationManagerError, setRelationManagerError] = useState(null);

  // Check if client type is Individual
  const isIndividualClient = formData.clientType === "Individual";

  // Fetch companies from API
  const fetchCompanies = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const { data } = await api.getCompanies();
      setCompanies(data.companies);
    } catch (err) {
      setError("Failed to load companies. Please try again later.");
      console.error("Failed to fetch companies:", err);
    } finally {
      setIsLoading(false);
    }
  };

  // Fetch contacts for dropdown
  const fetchContactsList = async () => {
    setLoadingContacts(true);
    setContactError(null);
    try {
      const response = await fetch(COMPANY_API_URL);
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const result = await response.json();
      
      // Store full contact objects instead of just names
      const contacts = result?.data?.contacts || [];
      setContactsList(contacts);
      setFilteredContacts(contacts);
    } catch (err) {
      console.error('Error fetching contacts:', err);
      setContactError(err.message);
      setContactsList([]);
      setFilteredContacts([]);
    } finally {
      setLoadingContacts(false);
    }
  };

  // Fetch relation managers for dropdown
  const fetchRelationManagersList = async () => {
    setLoadingRelationManagers(true);
    setRelationManagerError(null);
    try {
      // Assuming you have an API endpoint for relation managers
      // If not, you can reuse the contacts list or create a separate one
      const response = await fetch(COMPANY_API_URL);
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const result = await response.json();
      
      // Store full contact objects instead of just names
      const managers = result?.data?.contacts || [];
      setRelationManagersList(managers);
      setFilteredRelationManagers(managers);
    } catch (err) {
      console.error('Error fetching relation managers:', err);
      setRelationManagerError(err.message);
      setRelationManagersList([]);
      setFilteredRelationManagers([]);
    } finally {
      setLoadingRelationManagers(false);
    }
  };

  // Generate UUID for client code
  const generateClientCode = () => {
    return uuidv4().substring(0, 8).toUpperCase(); // Using first 8 characters of UUID
  };

  // Filter contacts based on search input
  useEffect(() => {
    if (contactSearch) {
      const filtered = contactsList.filter(contact => 
        contact.name.toLowerCase().includes(contactSearch.toLowerCase())
      );
      setFilteredContacts(filtered);
    } else {
      setFilteredContacts(contactsList);
    }
  }, [contactSearch, contactsList]);

  // Filter relation managers based on search input
  useEffect(() => {
    if (relationManagerSearch) {
      const filtered = relationManagersList.filter(manager => 
        manager.name.toLowerCase().includes(relationManagerSearch.toLowerCase())
      );
      setFilteredRelationManagers(filtered);
    } else {
      setFilteredRelationManagers(relationManagersList);
    }
  }, [relationManagerSearch, relationManagersList]);

  // Handle contact selection from dropdown
  const handleContactSelect = (contact) => {
    setFormData(prev => ({ 
      ...prev, 
      contactPerson: contact.name,
      contactNumber: contact.phone || contact.mobile || contact.contact_number || "",
      email: contact.email || prev.email // Auto-fill email if available
    }));
    setShowContactDropdown(false);
  };

  // Handle relation manager selection from dropdown
  const handleRelationManagerSelect = (manager) => {
    setFormData(prev => ({ 
      ...prev, 
      relationManager: manager.name
    }));
    setShowRelationManagerDropdown(false);
  };

  // Handle manual addition of contact
  const handleAddManualContact = () => {
    if (contactSearch.trim()) {
      setFormData(prev => ({ 
        ...prev, 
        contactPerson: contactSearch,
        contactNumber: "", // Reset contact number for manual entry
        // Keep the existing email value
      }));
      setShowContactDropdown(false);
      setContactSearch("");
    }
  };

  // Handle manual addition of relation manager
  const handleAddManualRelationManager = () => {
    if (relationManagerSearch.trim()) {
      setFormData(prev => ({ 
        ...prev, 
        relationManager: relationManagerSearch
      }));
      setShowRelationManagerDropdown(false);
      setRelationManagerSearch("");
    }
  };

  // Search companies
  const handleSearch = async (e) => {
    e.preventDefault();
    if (!searchQuery.trim()) {
      fetchCompanies();
      return;
    }

    setIsLoading(true);
    setError(null);
    try {
      const { data } = await api.searchCompanies(searchQuery);
      setCompanies(data.companies);
    } catch (err) {
      setError("Search failed. Please try again.");
      console.error("Search failed:", err);
    } finally {
      setIsLoading(false);
    }
  };

  // Handle input changes in form
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // If client type changes to Individual, clear company-specific fields
    if (name === "clientType" && value === "Individual") {
      setFormData(prev => ({
        ...prev,
        cinNumber: "",
        website: "",
        industryType: "",
        businessType: "",
        contracts: "",
        relationManager: ""
      }));
    }
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);

    try {
      // Generate client code if not already set
      const finalClientCode = formData.client_code || generateClientCode();

      // Prepare data based on client type
      const submitData = {
        clientName: formData.clientName,
        email: formData.email,
        panNumber: formData.panNumber,
        address: formData.address,
        pinCode: formData.pinCode,
        state: formData.state,
        clientType: formData.clientType,
        contactPerson: formData.contactPerson,
        contactNumber: formData.contactNumber,
        client_code: finalClientCode,
        status: formData.status,
        // Company-specific fields (will be empty for Individual clients)
        cinNumber: formData.cinNumber,
        website: formData.website,
        industryType: formData.industryType,
        businessType: formData.businessType,
        contracts: formData.contracts,
        relationManager: formData.relationManager
      };

      if (editingId) {
        await api.updateCompany(editingId, submitData);
      } else {
        await api.createCompany(submitData);
      }

      await fetchCompanies();
      setIsDrawerOpen(false);
      resetForm();
    } catch (err) {
      setError("Failed to save client. Please check your data and try again.");
      console.error("Failed to save client:", err);
    } finally {
      setIsLoading(false);
    }
  };

  // Edit company
  const handleEdit = (company) => {
    setFormData({
      clientName: company.client_name || company.name,
      email: company.email,
      panNumber: company.pan_number,
      address: company.address,
      pinCode: company.pin_code,
      state: company.state,
      clientType: company.client_type,
      contactPerson: company.contact_person,
      contactNumber: company.contact_number,
      // Company-specific fields
      cinNumber: company.cin_number || "",
      website: company.website || "",
      industryType: company.industry_type || "",
      businessType: company.business_type || "",
      contracts: company.contracts || "",
      relationManager: company.relation_manager || "",
      client_code: company.client_code || "",
      status: company.status || "Active"
    });
    setEditingId(company.id);
    setIsDrawerOpen(true);
  };

  // Delete company
  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this client?")) return;

    setIsLoading(true);
    setError(null);
    try {
      await api.deleteCompany(id);
      await fetchCompanies();
    } catch (err) {
      setError("Failed to delete client. Please try again.");
      console.error("Failed to delete client:", err);
    } finally {
      setIsLoading(false);
    }
  };

  // Reset form
  const resetForm = () => {
    setFormData({
      clientName: "",
      email: "",
      panNumber: "",
      address: "",
      pinCode: "",
      state: "",
      clientType: "",
      contactPerson: "",
      contactNumber: "",
      // Company-specific fields
      cinNumber: "",
      website: "",
      industryType: "",
      businessType: "",
      contracts: "",
      relationManager: "",
      client_code: "",
      status: "Active"
    });
    setEditingId(null);
    setContactSearch("");
    setRelationManagerSearch("");
    setShowContactDropdown(false);
    setShowRelationManagerDropdown(false);
  };

  // Fetch companies on component mount
  useEffect(() => {
    fetchCompanies();
  }, []);

  async function createEmptyContact(val) {
    const obj = {
      name: val,
      phone: "NA",
      email: "NA",
      additionalNumber: "NA",
      companies: ["NA"],
      status: "Active"
    };

    await apii.createContact(obj);
  }

  return (
    <>
      <div className="bg-white p-4 rounded-md shadow">
        {/* Error message */}
        {error && (
          <div className="mb-4 p-3 bg-red-100 text-red-700 rounded">
            {error}
          </div>
        )}

        {/* Search and action bar */}
        <div className="flex justify-between items-center mb-4">
          <form onSubmit={handleSearch} className="flex items-center w-1/3">
            <input
              type="text"
              placeholder="Search clients..."
              className="border rounded-l px-4 py-2 w-full"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <button 
              type="submit" 
              className="bg-gray-100 border border-l-0 rounded-r px-4 py-2"
              disabled={isLoading}
            >
              <Search size={18} />
            </button>
          </form>
          <div className="flex items-center gap-2">
            <button 
              className="border px-3 py-2 rounded flex items-center gap-1"
              disabled={isLoading}
            >
              <Filter size={16} /> Sort
            </button>
            <button 
              className="bg-purple-100 text-purple-700 px-4 py-2 rounded font-medium"
              disabled={isLoading}
            >
              Manage Columns
            </button>
            <button
              className="bg-red-500 text-white px-4 py-2 rounded flex items-center gap-1"
              onClick={() => {
                resetForm();
                setIsDrawerOpen(true);
              }}
              disabled={isLoading}
            >
              <Plus size={18} /> Add Client
            </button>
          </div>
        </div>

        {/* Loading state */}
        {isLoading && (
          <div className="p-4 text-center text-gray-500">Loading clients...</div>
        )}

        {/* Companies table */}
        {!isLoading && (
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
              <thead className="bg-gray-100">
                <tr>
                  <th className="px-3 py-2 whitespace-nowrap">Client Name</th>
                  <th className="px-3 py-2 whitespace-nowrap">Email</th>
                  <th className="px-3 py-2 whitespace-nowrap">PAN Number</th>
                  <th className="px-3 py-2 whitespace-nowrap">Address</th>
                  <th className="px-3 py-2 whitespace-nowrap">Pin Code</th>
                  <th className="px-3 py-2 whitespace-nowrap">State</th>
                  <th className="px-3 py-2 whitespace-nowrap">Client Type</th>
                  <th className="px-3 py-2 whitespace-nowrap">Contact Person</th>
                  <th className="px-3 py-2 whitespace-nowrap">Contact Number</th>
                  <th className="px-3 py-2 whitespace-nowrap">CIN Number</th>
                  <th className="px-3 py-2 whitespace-nowrap">Website</th>
                  <th className="px-3 py-2 whitespace-nowrap">Industry Type</th>
                  <th className="px-3 py-2 whitespace-nowrap">Business Type</th>
                  <th className="px-3 py-2 whitespace-nowrap">Contracts</th>
                  <th className="px-3 py-2 whitespace-nowrap">Relation Manager</th>
                  <th className="px-3 py-2 whitespace-nowrap">Client Code</th>
                  <th className="px-3 py-2 whitespace-nowrap">Status</th>
                  <th className="px-3 py-2 whitespace-nowrap">Created At</th>
                  <th className="px-3 py-2 whitespace-nowrap">Updated At</th>
                  <th className="px-3 py-2 whitespace-nowrap">Actions</th>
                </tr>
              </thead>
              <tbody>
                {companies.length > 0 ? (
                  companies.map((company) => (
                    <tr key={company.id} className="border-b hover:bg-gray-50">
                      <td className="px-3 py-3 font-semibold whitespace-nowrap"><Link
  to={{
    pathname: `/InsideClientPage/${company.client_code}`,
  }}
  state={{ "client_type": company.client_type, "cin_number": company.client_code ,"client_name":company.client_name || company.name, "parent_clinte_code":company.client_code}}
>
 {company.client_name || company.name}   
</Link></td>
                      <td className="px-3 py-3 whitespace-nowrap">{company.email}</td>
                      <td className="px-3 py-3 whitespace-nowrap">{company.pan_number || '-'}</td>
                      <td className="px-3 py-3 whitespace-nowrap">{company.address || '-'}</td>
                      <td className="px-3 py-3 whitespace-nowrap">{company.pin_code || '-'}</td>
                      <td className="px-3 py-3 whitespace-nowrap">{company.state || '-'}</td>
                      <td className="px-3 py-3 whitespace-nowrap">{company.client_type || '-'}</td>
                      <td className="px-3 py-3 whitespace-nowrap">{company.contact_person || '-'}</td>
                      <td className="px-3 py-3 whitespace-nowrap">{company.contact_number || '-'}</td>
                      <td className="px-3 py-3 whitespace-nowrap">{company.cin_number || '-'}</td>
                      <td className="px-3 py-3 whitespace-nowrap">
                        {company.website ? (
                          <a 
                            href={company.website} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="text-blue-600 hover:underline"
                          >
                            {company.website}
                          </a>
                        ) : '-'}
                      </td>
                      <td className="px-3 py-3 whitespace-nowrap">{company.industry_type || '-'}</td>
                      <td className="px-3 py-3 whitespace-nowrap">{company.business_type || '-'}</td>
                      <td className="px-3 py-3 whitespace-nowrap max-w-xs truncate">{company.contracts || '-'}</td>
                      <td className="px-3 py-3 whitespace-nowrap">{company.relation_manager || '-'}</td>
                      <td className="px-3 py-3 whitespace-nowrap">{company.client_code || '-'}</td>
                      <td className="px-3 py-3 whitespace-nowrap">
                        <span
                          className={`px-2 py-1 rounded text-xs font-semibold text-white whitespace-nowrap ${
                            company.status === "Active"
                              ? "bg-green-500"
                              : company.status === "Inactive"
                              ? "bg-gray-500"
                              : "bg-yellow-500"
                          }`}
                        >
                          {company.status}
                        </span>
                      </td>
                      <td className="px-3 py-3 whitespace-nowrap">
                        {new Date(company.created_at).toLocaleDateString()}
                      </td>
                      <td className="px-3 py-3 whitespace-nowrap">
                        {new Date(company.updated_at).toLocaleDateString()}
                      </td>
                      <td className="px-3 py-3 whitespace-nowrap flex gap-2">
                        <button 
                          onClick={() => handleEdit(company)}
                          className="text-blue-500 hover:text-blue-700"
                          disabled={isLoading}
                        >
                          <Edit size={16} />
                        </button>
                        <button 
                          onClick={() => handleDelete(company.id)}
                          className="text-red-500 hover:text-red-700"
                          disabled={isLoading}
                        >
                          <Trash2 size={16} />
                        </button>
                        <button
                          className="text-gray-500 hover:text-gray-700"
                        >
                          <MoreVertical size={16} />
                        </button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="20" className="px-3 py-4 text-center text-gray-500">
                      No clients found
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Add/Edit Client Drawer */}
      {isDrawerOpen && (
        <div className="fixed inset-0 z-50 bg-black bg-opacity-40 flex justify-end">
          <div className="bg-white h-full w-full max-w-4xl p-6 overflow-y-auto shadow-xl">
            <div className="flex justify-between items-center border-b pb-3">
              <h2 className="text-xl font-semibold">
                {editingId ? "Edit Client" : "Add New Client"}
              </h2>
              <button 
                onClick={() => {
                  setIsDrawerOpen(false);
                  resetForm();
                }} 
                className="text-gray-600 hover:text-black text-2xl"
                disabled={isLoading}
              >
                &times;
              </button>
            </div>

            <form onSubmit={handleSubmit} className="mt-4 space-y-5">
              {/* Common fields for all client types */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block font-medium">Client Name *</label>
                  <input
                    type="text"
                    name="clientName"
                    className="w-full border rounded px-3 py-2 mt-1"
                    value={formData.clientName}
                    onChange={handleInputChange}
                    required
                    disabled={isLoading}
                  />
                </div>
                <div>
                  <label className="block font-medium">Email *</label>
                  <input
                    type="email"
                    name="email"
                    className="w-full border rounded px-3 py-2 mt-1"
                    value={formData.email}
                    onChange={handleInputChange}
                    required
                    disabled={isLoading}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block font-medium">PAN Number</label>
                  <input
                    type="text"
                    name="panNumber"
                    className="w-full border rounded px-3 py-2 mt-1"
                    value={formData.panNumber}
                    onChange={handleInputChange}
                    disabled={isLoading}
                  />
                </div>
                <div>
                  <label className="block font-medium">Client Type *</label>
                  <select
                    name="clientType"
                    className="w-full border rounded px-3 py-2 mt-1"
                    value={formData.clientType}
                    onChange={handleInputChange}
                    required
                    disabled={isLoading}
                  >
                    <option value="">Select Client Type</option>
                    <option value="Individual">Individual</option>
                    <option value="Corporate">Corporate</option>
                    <option value="Government">Government</option>
                    <option value="Non-Profit">Non-Profit</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-medium">Address</label>
                <textarea
                  name="address"
                  className="w-full border rounded px-3 py-2 mt-1"
                  rows="2"
                  value={formData.address}
                  onChange={handleInputChange}
                  disabled={isLoading}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block font-medium">Pin Code</label>
                  <input
                    type="text"
                    name="pinCode"
                    className="w-full border rounded px-3 py-2 mt-1"
                    value={formData.pinCode}
                    onChange={handleInputChange}
                    disabled={isLoading}
                  />
                  <span className="text-xs text-gray-500">API</span>
                </div>
                <div>
                  <label className="block font-medium">State</label>
                  <input
                    type="text"
                    name="state"
                    className="w-full border rounded px-3 py-2 mt-1"
                    value={formData.state}
                    onChange={handleInputChange}
                    disabled={isLoading}
                  />
                  <span className="text-xs text-gray-500">API</span>
                </div>
              </div>

              {/* Conditional fields based on client type */}
              {!isIndividualClient && (
                <>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block font-medium">CIN Number</label>
                      <input
                        type="text"
                        name="cinNumber"
                        className="w-full border rounded px-3 py-2 mt-1"
                        value={formData.cinNumber}
                        onChange={handleInputChange}
                        disabled={isLoading}
                      />
                    </div>
                    <div>
                      <label className="block font-medium">Website</label>
                      <input
                        type="url"
                        name="website"
                        className="w-full border rounded px-3 py-2 mt-1"
                        value={formData.website}
                        onChange={handleInputChange}
                        disabled={isLoading}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block font-medium">Industry Type</label>
                      <select
                        name="industryType"
                        className="w-full border rounded px-3 py-2 mt-1"
                        value={formData.industryType}
                        onChange={handleInputChange}
                        disabled={isLoading}
                      >
                        <option value="">Select Industry</option>
                        <option value="IT">Information Technology</option>
                        <option value="Finance">Finance</option>
                        <option value="Healthcare">Healthcare</option>
                        <option value="Manufacturing">Manufacturing</option>
                        <option value="Retail">Retail</option>
                        <option value="Education">Education</option>
                      </select>
                    </div>
                    <div>
                      <label className="block font-medium">Business Type</label>
                      <select
                        name="businessType"
                        className="w-full border rounded px-3 py-2 mt-1"
                        value={formData.businessType}
                        onChange={handleInputChange}
                        disabled={isLoading}
                      >
                        <option value="">Select Business Type</option>
                        <option value="B2B">B2B</option>
                        <option value="B2C">B2C</option>
                        <option value="B2G">B2G</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block font-medium">Contracts</label>
                    <textarea
                      name="contracts"
                      className="w-full border rounded px-3 py-2 mt-1"
                      rows="2"
                      value={formData.contracts}
                      onChange={handleInputChange}
                      disabled={isLoading}
                      placeholder="Enter contract details"
                    />
                  </div>

                  <div>
                    <label className="block font-medium">Relation Manager</label>
                    <div className="relative">
                      <input
                        type="text"
                        name="relationManager"
                        className="w-full border rounded px-3 py-2 mt-1"
                        value={formData.relationManager}
                        onChange={(e) => {
                          setFormData(prev => ({ ...prev, relationManager: e.target.value }));
                          setRelationManagerSearch(e.target.value);
                        }}
                        onFocus={() => {
                          setShowRelationManagerDropdown(true);
                          if (relationManagersList.length === 0) {
                            fetchRelationManagersList();
                          }
                        }}
                        disabled={isLoading}
                      />
                      
                      {/* Relation Manager Dropdown */}
                      {showRelationManagerDropdown && (
                        <div className="absolute z-10 w-full mt-1 bg-white border rounded-md shadow-lg max-h-60 overflow-auto">
                          {/* Search input inside dropdown */}
                          <div className="p-2 border-b">
                            <input
                              type="text"
                              placeholder="Search relation managers..."
                              className="w-full px-3 py-2 border rounded"
                              value={relationManagerSearch}
                              onChange={(e) => setRelationManagerSearch(e.target.value)}
                              autoFocus
                            />
                          </div>
                          
                          {/* Loading state */}
                          {loadingRelationManagers && (
                            <div className="px-4 py-2 text-gray-500">Loading relation managers...</div>
                          )}
                          
                          {/* Error state */}
                          {relationManagerError && (
                            <div className="px-4 py-2 text-red-500">{relationManagerError}</div>
                          )}
                          
                          {/* Relation managers list */}
                          {!loadingRelationManagers && !relationManagerError && (
                            <>
                              {filteredRelationManagers.length > 0 ? (
                                filteredRelationManagers.map((manager, index) => (
                                  <div
                                    key={index}
                                    className="px-4 py-2 cursor-pointer hover:bg-gray-100"
                                    onClick={() => handleRelationManagerSelect(manager)}
                                  >
                                    <div className="font-medium">{manager.name}</div>
                                    <div className="text-sm text-gray-500">
                                      {manager.phone && `${manager.phone} • `}
                                      {manager.email}
                                    </div>
                                  </div>
                                ))
                              ) : relationManagerSearch ? (
                                <div className="px-4 py-2 text-gray-500">No relation managers found</div>
                              ) : (
                                <div className="px-4 py-2 text-gray-500">No relation managers available</div>
                              )}
                              
                              {/* Add manual relation manager button */}
                              {relationManagerSearch && (
                                <div
                                  className="px-4 py-2 cursor-pointer hover:bg-gray-100 bg-blue-50 border-t"
                                  onClick={handleAddManualRelationManager}
                                >
                                  + Add "{relationManagerSearch}" as new relation manager
                                </div>
                              )}
                            </>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                </>
              )}

              {/* Contact fields with conditional rendering note */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block font-medium">Contact Person</label>
                  <div className="relative">
                    <input
                      type="text"
                      name="contactPerson"
                      className="w-full border rounded px-3 py-2 mt-1"
                      value={formData.contactPerson}
                      onChange={(e) => {
                        setFormData(prev => ({ ...prev, contactPerson: e.target.value }));
                        setContactSearch(e.target.value);
                      }}
                      onFocus={() => {
                        setShowContactDropdown(true);
                        if (contactsList.length === 0) {
                          fetchContactsList();
                        }
                      }}
                      disabled={isLoading}
                    />
                    
                    {/* Contact Person Dropdown */}
                    {showContactDropdown && (
                      <div className="absolute z-10 w-full mt-1 bg-white border rounded-md shadow-lg max-h-60 overflow-auto">
                        {/* Search input inside dropdown */}
                        <div className="p-2 border-b">
                          <input
                            type="text"
                            placeholder="Search contacts..."
                            className="w-full px-3 py-2 border rounded"
                            value={contactSearch}
                            onChange={(e) => setContactSearch(e.target.value)}
                            autoFocus
                          />
                        </div>
                        
                        {/* Loading state */}
                        {loadingContacts && (
                          <div className="px-4 py-2 text-gray-500">Loading contacts...</div>
                        )}
                        
                        {/* Error state */}
                        {contactError && (
                          <div className="px-4 py-2 text-red-500">{contactError}</div>
                        )}
                        
                        {/* Contacts list */}
                        {!loadingContacts && !contactError && (
                          <>
                            {filteredContacts.length > 0 ? (
                              filteredContacts.map((contact, index) => (
                                <div
                                  key={index}
                                  className="px-4 py-2 cursor-pointer hover:bg-gray-100"
                                  onClick={() => handleContactSelect(contact)}
                                >
                                  <div className="font-medium">{contact.name}</div>
                                  <div className="text-sm text-gray-500">
                                    {contact.phone && `${contact.phone} • `}
                                    {contact.email}
                                  </div>
                                </div>
                              ))
                            ) : contactSearch ? (
                              <div className="px-4 py-2 text-gray-500">No contacts found</div>
                            ) : (
                              <div className="px-4 py-2 text-gray-500">No contacts available</div>
                            )}
                            
                            {/* Add manual contact button */}
                            {contactSearch && (
                              <div
                                className="px-4 py-2 cursor-pointer hover:bg-gray-100 bg-blue-50 border-t"
                                onClick={()=>{
                                  handleAddManualContact()
                                  createEmptyContact(contactSearch)
                                }}
                              >
                                + Add "{contactSearch}" as new contact
                              </div>
                            )}
                          </>
                        )}
                      </div>
                    )}
                  </div>
                  <p className="text-xs text-gray-500 mt-1">
                    {isIndividualClient 
                      ? "Required for Individual clients" 
                      : "In Case of Company it's not required there"}
                  </p>
                </div>
                <div>
                  <label className="block font-medium">Contact Number</label>
                  <input
                    type="tel"
                    name="contactNumber"
                    className="w-full border rounded px-3 py-2 mt-1"
                    value={formData.contactNumber}
                    onChange={handleInputChange}
                    disabled={isLoading}
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    {isIndividualClient 
                      ? "Required for Individual clients" 
                      : "In Case of Company it's not required there"}
                  </p>
                </div>
              </div>

              <div>
                <label className="block font-medium">Status *</label>
                <select
                  name="status"
                  className="w-full border rounded px-3 py-2 mt-1"
                  value={formData.status}
                  onChange={handleInputChange}
                  required
                  disabled={isLoading}
                >
                  <option value="Active">Active</option>
                  <option value="Inactive">Inactive</option>
                  <option value="Pending">Pending</option>
                </select>
              </div>

              {error && (
                <div className="p-3 bg-red-100 text-red-700 rounded">
                  {error}
                </div>
              )}

              <div className="flex justify-end space-x-3 pt-4 border-t mt-6">
                <button
                  type="button"
                  onClick={() => {
                    setIsDrawerOpen(false);
                    resetForm();
                  }}
                  className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
                  disabled={isLoading}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 flex items-center gap-2"
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <>
                      <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 极速12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 极速0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Processing...
                    </>
                  ) : editingId ? (
                    "Update Client"
                  ) : (
                    "Create Client"
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
};

export default CompaniesPage;