import React, { useEffect, useState } from "react";
import { ChevronLeft, ChevronRight, Plus, Video, Cake, CalendarHeart, Briefcase, Building2, Check, AlertTriangle, Clock, Mail, Phone } from "lucide-react";
import AddEventModal from "./modals/AddEventModal";
import { useSelector } from "react-redux";

const getMonthName = (month) =>
  new Date(2000, month).toLocaleString("default", { month: "long" });

const ErrorDisplay = ({ error, onRetry }) => {
  if (!error) return null;

  return (
    <div className="fixed top-4 right-4 bg-red-100 border-l-4 border-red-500 text-red-700 p-4 max-w-md">
      <div className="flex justify-between">
        <div>
          <p className="font-bold">Error</p>
          <p>{error}</p>
        </div>
        <button
          onClick={onRetry}
          className="ml-4 bg-red-500 text-white px-3 py-1 rounded"
        >
          Retry
        </button>
      </div>
    </div>
  );
};

const Calendar = () => {
  const [open, setOpen] = useState(false);
  const [events, setEvents] = useState([]);
  const [leaveEvents, setLeaveEvents] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [currentDate, setCurrentDate] = useState(new Date());
  const user = useSelector((state) => state.auth.user);
  const userEmail = user?.employee?.email;
  const id = user?.employee?.id;

  const startOfMonth = new Date(
    currentDate.getFullYear(),
    currentDate.getMonth(),
    1
  );
  // const endOfMonth = new Date(
  //   currentDate.getFullYear(),
  //   currentDate.getMonth() + 1,
  //   0
  // );
  const startDay = startOfMonth.getDay() || 7;

  const prevMonth = () => {
    setCurrentDate(
      new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1)
    );
  };

  const nextMonth = () => {
    setCurrentDate(
      new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1)
    );
  };

  const buildCalendar = () => {
    const calendar = [];
    let dayCount = 1 - (startDay - 1);
    for (let week = 0; week < 6; week++) {
      const days = [];
      for (let day = 0; day < 7; day++) {
        const current = new Date(
          currentDate.getFullYear(),
          currentDate.getMonth(),
          dayCount
        );
        days.push(current);
        dayCount++;
      }
      calendar.push(days);
    }
    return calendar;
  };

  const formatDate = (date) => {
    const d = new Date(date);
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, "0");
    const dd = String(d.getDate()).padStart(2, "0");
    return `${yyyy}-${mm}-${dd}`;
  };

  const getTimeFromDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  };

  const fetchCalendarEvents = async () => {
    const month = currentDate.getMonth() + 1;
    const year = currentDate.getFullYear();
    try {
      const response = await fetch(
        `http://localhost:5000/api/calendar?month=${month}&year=${year}&userEmail=${userEmail}&userId=${id}`
      );

      if (!response.ok) {
        throw new Error("Failed to fetch calendar events");
      }

      const data = await response.json();
      setEvents(Array.isArray(data.data) ? data.data : []);
      setError("");
    } catch (err) {
      console.error("Fetch calendar error:", err);
      setError(err.message);
      setEvents([]);
    }
  };

  const fetchLeaveHistory = async () => {
    try {
      const response = await fetch(`http://localhost:5000/api/leave/history/${id}`);
      if (!response.ok) {
        throw new Error("Failed to fetch leave history");
      }
      const data = await response.json();
      
      const approvedLeaves = Array.isArray(data)
        ? data
            .filter(leave => leave.status === "approved")
            .map(leave => ({
              event_id: `leave_${leave.id}`,
              title: `Leave: ${leave.leave_type}`,
              start_date: leave.start_date,
              end_date: leave.end_date,
              event_type: "leave",
              leave_type: leave.leave_type,
              days: leave.days
            }))
        : [];
      
      setLeaveEvents(approvedLeaves);
    } catch (err) {
      console.error("Fetch leave history error:", err);
      setLeaveEvents([]);
    }
  };

  const fetchTasks = async () => {
    try {
      setLoading(true);
      const res = await fetch(`http://localhost:5000/api/tasks/tasks?userId=${id}`);
      
      if (!res.ok) {
        throw new Error("Failed to fetch tasks");
      }
      
      const data = await res.json();
      
      // Handle different response structures
      const tasksData = Array.isArray(data)
        ? data
        : (data.data && Array.isArray(data.data))
          ? data.data
          : (data.tasks && Array.isArray(data.tasks))
            ? data.tasks
            : [];
            
      setTasks(tasksData);
      setError("");
    } catch (err) {
      console.error("Fetch tasks error:", err);
      setError(err.message);
      setTasks([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const fetchData = async () => {
      await Promise.all([
        fetchCalendarEvents(),
        fetchLeaveHistory(),
        fetchTasks()
      ]);
    };
    
    fetchData();
  }, [currentDate]);

  const getEventsForDay = (day) => {
    const dayStr = formatDate(day);
    
    const formattedTasks = tasks.map(task => ({
      event_id: `task_${task.id}`,
      title: task.task_name,
      start_date: task.assign_datetime,
      end_date: task.end_datetime,
      event_type: "task",
      priority: task.priority,
      status: task.status,
      description: task.description,
      tag_label: task.tag_label,
      participants: task.participants || []
    }));

    const allEvents = [...events, ...leaveEvents, ...formattedTasks];
    
    return allEvents.filter((e) => {
      try {
        return formatDate(e.start_date) === dayStr;
      } catch (err) {
        console.error("Invalid event date:", e.start_date);
        return false;
      }
    });
  };

  const handleEventAdded = (newEvent) => {
    setEvents(prev => [...prev, newEvent]);
  };

  const isToday = (day) => day.toDateString() === new Date().toDateString();

  const getStatusIcon = (status) => {
    switch (status) {
      case "Completed":
        return <Check size={14} className="text-green-500" />;
      case "Inprogress":
        return <Clock size={14} className="text-blue-500" />;
      case "pending":
        return <AlertTriangle size={14} className="text-yellow-500" />;
      default:
        return null;
    }
  };

  const getTagIcon = (tag) => {
    switch (tag) {
      case "Email":
        return <Mail size={14} className="text-gray-500" />;
      case "Calls":
        return <Phone size={14} className="text-blue-500" />;
      case "Task":
        return <Check size={14} className="text-green-500" />;
      default:
        return <Briefcase size={14} className="text-gray-500" />;
    }
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case "high":
        return "bg-red-50 border-red-400";
      case "medium":
        return "bg-yellow-50 border-yellow-400";
      case "low":
        return "bg-green-50 border-green-400";
      default:
        return "bg-gray-50 border-gray-400";
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="p-6 bg-[#f4f9fd] min-h-screen">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-[36px]">Calendar</h2>
        <button
          className="bg-[#3F8CFF] text-white rounded-lg px-4 py-2 flex items-center gap-1 shadow-md"
          onClick={() => setOpen(true)}
        >
          <Plus size={16} /> Add Event
        </button>
      </div>

      <div className="bg-white rounded-xl p-4 shadow-md">
        <div className="flex items-center justify-between mb-4">
          <button
            onClick={prevMonth}
            className="p-2 rounded-full hover:bg-gray-100"
          >
            <ChevronLeft />
          </button>
          <h3 className="text-lg font-semibold">
            {getMonthName(currentDate.getMonth())} {currentDate.getFullYear()}
          </h3>
          <button
            onClick={nextMonth}
            className="p-2 rounded-full hover:bg-gray-100"
          >
            <ChevronRight />
          </button>
        </div>

        <div className="grid grid-cols-7 text-center text-sm text-gray-500">
          {["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((day) => (
            <div key={day} className="py-2 font-medium">
              {day}
            </div>
          ))}
        </div>

        {buildCalendar().map((week, i) => (
          <div key={i} className="grid grid-cols-7">
            {week.map((day, idx) => {
              const isCurrentMonth = day.getMonth() === currentDate.getMonth();
              const isDayToday = isToday(day);
              const dayEvents = getEventsForDay(day);

              return (
                <div
                  key={idx}
                  className={`min-h-[100px] border p-1 relative ${!isCurrentMonth ? "bg-gray-50 text-gray-400" : ""
                    } ${isDayToday ? "bg-blue-100 border-2 border-blue-500" : ""}`}
                >
                  <div
                    className={`text-xs text-right pr-1 ${isDayToday
                      ? "bg-blue-500 text-white rounded-full w-5 h-5 flex items-center justify-center ml-auto"
                      : ""
                      }`}
                  >
                    {day.getDate()}
                  </div>

                  {dayEvents.map((event) => {
                    // Task events
                    if (event.event_type === "task") {
                      return (
                        <div
                          key={event.event_id}
                          className={`mt-1 rounded-lg px-2 py-1 shadow-sm text-xs ${getPriorityColor(event.priority)} border-l-4`}
                        >
                          <div className="font-medium truncate flex items-center justify-between">
                            <div className="flex items-center gap-1">
                              {getTagIcon(event.tag_label)}
                              {event.title.length > 10 ? `${event.title.slice(0, 10)}...` : event.title}
                            </div>
                            {getStatusIcon(event.status)}
                          </div>
                          {event.start_date && (
                            <div className="text-gray-500 text-[10px]">
                              {getTimeFromDate(event.start_date)}
                              {event.end_date && ` - ${getTimeFromDate(event.end_date)}`}
                            </div>
                          )}
                          {event.participants && event.participants.length > 0 && (
                            <div className="flex mt-1">
                              {event.participants.slice(0, 3).map((participant, i) => (
                                <img
                                  key={i}
                                  src={participant.photo}
                                  alt={participant.name}
                                  className="w-4 h-4 rounded-full -mr-1 border border-white"
                                  title={participant.name}
                                />
                              ))}
                              {event.participants.length > 3 && (
                                <div className="w-4 h-4 rounded-full bg-gray-200 text-[8px] flex items-center justify-center -mr-1 border border-white">
                                  +{event.participants.length - 3}
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                      );
                    }

                    // Leave events
                    if (event.event_type === "leave") {
                      return (
                        <div
                          key={event.event_id}
                          className="mt-1 rounded-lg px-2 py-1 shadow-sm text-xs bg-green-50 border-l-4 border-green-400"
                        >
                          <div className="font-medium truncate flex items-center justify-between">
                            <div className="flex flex-col">
                              {event.title.length > 10 ? `${event.title.slice(0, 10)}...` : event.title}
                            </div>
                            <CalendarHeart size={14} className="text-green-500" />
                          </div>
                          <div className="text-gray-500 text-[10px]">
                            {event.days} day{event.days > 1 ? 's' : ''} • Approved
                          </div>
                        </div>
                      );
                    }

                    // Corporate events
                    if (event.event_type === "corporate_event") {
                      return (
                        <div
                          key={event.event_id || event.id}
                          className="mt-1 rounded-lg px-2 py-1 shadow-sm text-xs bg-purple-50 border-l-4 border-purple-400"
                        >
                          <div className="font-medium truncate flex items-center justify-between">
                            <div className="flex flex-col">
                              {event.title.length > 10 ? `${event.title.slice(0, 10)}...` : event.title}
                            </div>
                            <Building2 size={14} className="text-purple-500" />
                          </div>
                          {event.start_date && (
                            <div className="text-gray-500 text-[10px]">
                              {getTimeFromDate(event.start_date)}
                              {event.end_date && ` - ${getTimeFromDate(event.end_date)}`}
                            </div>
                          )}
                        </div>
                      );
                    }

                    // Other events
                    return (
                      <div
                        key={event.event_id || event.id}
                        className={`mt-1 rounded-lg px-2 py-1 shadow-sm text-xs ${event.event_type === "meeting"
                            ? "bg-blue-50 border-l-4 border-blue-400"
                            : event.event_type === "birthday"
                              ? "bg-pink-50 border-l-4 border-pink-400"
                              : "bg-gray-50 border-l-4 border-gray-400"
                          }`}
                      >
                        <div className="font-medium truncate flex items-center justify-between">
                          <div className="flex flex-col">
                            {event.title.length > 10 ? `${event.title.slice(0, 10)}...` : event.title}
                          </div>

                          {event.event_type === "meeting" ? (
                            <a
                              href={event.google_meet_link || event.manual_meet_link}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="ml-auto"
                            >
                              <Video size={14} className="text-blue-500" />
                            </a>
                          ) : event.event_type === "birthday" ? (
                            <div>
                              <Cake size={14} className="text-pink-500" />
                            </div>
                          ) : (
                            <div>
                              <Briefcase size={14} className="text-gray-500" />
                            </div>
                          )}
                        </div>

                        {event.event_type === "meeting" && (
                          <div className="text-gray-500 text-[10px]">
                            {event.start_time} - {event.end_time}
                          </div>
                        )}

                        {event.event_type !== "meeting" && event.start_date && (
                          <div className="text-gray-500 text-[10px]">
                            {getTimeFromDate(event.start_date)}
                            {event.end_date && ` - ${getTimeFromDate(event.end_date)}`}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              );
            })}
          </div>
        ))}
      </div>

      {open && (
        <AddEventModal
          onClose={() => setOpen(false)}
          onEventAdded={handleEventAdded}
          currentDate={currentDate}
        />
      )}

      <ErrorDisplay error={error} onRetry={() => {
        fetchCalendarEvents();
        fetchLeaveHistory();
        fetchTasks();
      }} />
    </div>
  );
};

export default Calendar;